from django.db import models
import datetime

# Create your models here.
class Competitor(models.Model):
    name = models.CharField('Competitor', max_length=100, unique=True)
    website = models.CharField(max_length=100)
    last_scrap = models.DateField('date last scraped', default=datetime.date.today)

    def __unicode__(self):
        return self.name


class Brand(models.Model):
    name = models.CharField('Brand', max_length=100)
    competitor = models.ManyToManyField(Competitor)

    def __unicode__(self):
        return self.name


class Product(models.Model):
    brand = models.ForeignKey(Brand)
    mro_id = models.IntegerField(unique=True)
    part_number = models.CharField(max_length=100)
    mro_price = models.DecimalField(max_digits=9, decimal_places=2, default=0)
    updated = models.DateField('date last updated', default=datetime.date.today)
    is_cheaper = models.NullBooleanField()

    def __unicode__(self):
        return self.part_number

    class Meta:
        ordering = ['mro_id']
        unique_together = (('mro_id', 'part_number'))

    def cheaper(self):
        mro_price = self.mro_price
        results = Result.objects.filter(product=self.id)
        for result in results:
            try:
                if float(result.price) < float(mro_price):
                    return True
            except:
                continue

        return False

    def temco(self):
        temco = Competitor.objects.get(name='temco')
        product = Product.objects.get(mro_id=self.mro_id)
        result = Result.objects.get(product=product.pk, competitor=temco.pk)
        return result.price

    def walkeremd(self):
        temco = Competitor.objects.get(name='walkeremd')
        product = Product.objects.get(mro_id=self.mro_id)
        result = Result.objects.get(product=product.pk, competitor=temco.pk)
        return result.price

    def globalindustrial(self):
        temco = Competitor.objects.get(name='globalindustrial')
        product = Product.objects.get(mro_id=self.mro_id)
        result = Result.objects.get(product=product.pk, competitor=temco.pk)
        return result.price

    def motoragents(self):
        temco = Competitor.objects.get(name='motoragents')
        product = Product.objects.get(mro_id=self.mro_id)
        result = Result.objects.get(product=product.pk, competitor=temco.pk)
        return result.price

    def sqone(self):
        temco = Competitor.objects.get(name='sqone')
        product = Product.objects.get(mro_id=self.mro_id)
        result = Result.objects.get(product=product.pk, competitor=temco.pk)
        return result.price

    def electricmotorwholesale(self):
        temco = Competitor.objects.get(name='electricmotorwholesale')
        product = Product.objects.get(mro_id=self.mro_id)
        result = Result.objects.get(product=product.pk, competitor=temco.pk)
        return result.price

    '''
    competitors = Competitor.objects.all()
    for competitor in competitors:
        exec("""def %s(self):
                    competitor = Competitor.objects.get(name='%s')
                    result = Result.objects.get(product=self.pk, competitor=competitor.pk)
                    return result.price""" % (competitor.name, competitor.name))
    '''

class Result(models.Model):
    product = models.ForeignKey(Product)
    competitor = models.ForeignKey(Competitor)
    price = models.DecimalField(max_digits=9, decimal_places=2, default=0)
    scraped = models.DateField('date last scraped', default=datetime.date.today)
    is_cheaper = models.BooleanField()
    changed = models.BooleanField()

    def __unicode__(self):
        return unicode(self.price)

    def cheaper(self):
        price = self.price
        # mro_price = Product.objects.get(self.product).mro_price
        mro_price = self.product.mro_price

        if price < mro_price:
            return True
        return False


class Archive(models.Model):
    product = models.ForeignKey(Product)
    competitor = models.ForeignKey(Competitor)
    price = models.DecimalField(max_digits=9, decimal_places=2, default=0)
    scraped = models.DateField('date last scraped', default=datetime.date.today)

    def __unicode__(self):
        return unicode(self.price)


class LeesonReport(Product):
    readonly_fields = ('brand', 'mro_id', 'part_number', 'mro_price', 'updated')
    class Meta:
        proxy = True

    brand1 = ''

    def __init__(self, *args, **kwargs):
        brand_name = type(self).__name__.split('Report')[0]
        super(LeesonReport, self).__init__(*args, **kwargs)
        self.brand1 = Brand.objects.filter(name=brand_name)
        self.list_display_links = (None,)

    competitors = Competitor.objects.filter(brand__in=brand1)

    for competitor in competitors:
        exec("""def %s(self):
                    competitor = Competitor.objects.get(name='%s')
                    result = Result.objects.get(product=self.pk, competitor=competitor.pk)
                    return result.price""" % (competitor.name, competitor.name))


class BaldorReport(Product):
    readonly_fields = ('brand', 'mro_id', 'part_number', 'mro_price', 'updated')
    class Meta:
        proxy = True

    # brand1 = Brand.objects.filter(name='Baldor')
    brand1 = ''

    def __init__(self, *args, **kwargs):
        brand_name = 'Baldor'
        super(BaldorReport, self).__init__(*args, **kwargs)
        self.brand1 = Brand.objects.filter(name=brand_name)
        self.list_display_links = (None,)


    competitors = Competitor.objects.filter(brand__in=brand1)

    for competitor in competitors:
        exec("""def %s(self):
                    competitor = Competitor.objects.get(name='%s')
                    result = Result.objects.get(product=self.pk, competitor=competitor.pk)
                    return result.price""" % (competitor.name, competitor.name))









