from django.core.management.base import BaseCommand, CommandError
from prices.models import Product, Brand, Competitor, Result
from scrapers import TemcoScraper, SqoneScraper, GlobalindustrialScraper, WalkeremdScraper, ElectricmotorwholesaleScraper, MotoragentsScraper
from scrapers import AlliedelecScraper, DigikeyScraper
from time import sleep

class Command(BaseCommand):
    args = '<poll_id poll_id ...>'
    help = 'Closes the specified poll for voting'

    def handle(self, brand_name, competitor_name, *args, **options):
        competitor = Competitor.objects.get(name=competitor_name)
        brand = Brand.objects.get(name=brand_name)
        all_products = Product.objects.select_related().filter(brand=brand)
        print 'scrapers.' + str(competitor.name.capitalize()) + 'Scraper()'
        scraper = eval(str(competitor.name.capitalize()) + 'Scraper()')
        for product in all_products:
            sleep(2)
            price = scraper.get_price(product.part_number)
            self.stdout.write('%s with price %s' % (product.part_number, price))
            if price != 0:
                result = Result()
                result.product = product
                result.competitor = competitor
                result.price = price
                if product.mro_price < price:
                    result.is_cheaper = False
                else:
                    result.is_cheaper = True
                    product.is_cheaper = True
                result.save()

        self.stdout.write('Successfully finished')
