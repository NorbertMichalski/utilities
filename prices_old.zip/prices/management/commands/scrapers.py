# -*- coding: utf-8 -*-

import requests
import re
import json
from lxml import html
from datetime import datetime, timedelta
from prices.tools.models import ProxyRotator
# import prices.settings.models



class Scraper(object):

    HEADERS = {'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.73 Safari/537.36',
                'Accept':'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                'Accept-Charset':'utf-8;q=0.7,*;q=0.3',
                'Accept-Encoding':'gzip,deflate,sdch',
                'Accept-Language':'it-IT,it;q=0.8,en-US;q=0.6,en;q=0.4',
                'Connection':'keep-alive',
                'Content-Type':'application/x-www-form-urlencoded',
                # 'Referer': '',
                # 'Origin': '',
                # 'Host': ''
                }

    # PROXY = {'http':'http://notherhalo:green444@38.78.197.196:60099'}
    PROXY = ''
    proxy_obj = ''

    def __init__(self, *args, **kwargs):
        self.proxy_obj = ProxyRotator()
        self.PROXY = eval(json.loads(self.proxy_obj.rotate_proxy()))
        print self.PROXY
        self.session = requests
        self.session.headers = self.HEADERS

    def clean_results(self, price):
        try:
            return float(re.search('[\d\.,]+', price).group(0).replace(',', ''))
        except AttributeError:
            return 0

class ElectricmotorwholesaleScraper(Scraper):

    def get_price(self, part_num):
        part_num = part_num.strip()
        self.PROXY = eval(json.loads(self.proxy_obj.rotate_proxy()))
        url = 'http://www.electricmotorwholesale.com/index.cfm?fuseaction=catalog.search'
        try:
            resp = self.session.post(url, proxies=self.PROXY, data={'searchQuery': part_num,
                                                                    'submitSearch':'Search'
                                                                    })
        except Exception as e:
            return 0
        x = html.fromstring(resp.content)
        try:
            price = x.xpath(".//div[contains(@class,'listCatalogProductSalePrice')]/text()")[0].strip()
        except IndexError:
            return 0
        return self.clean_results(price)

    def scrap(self, brand):
        pass



class GlobalindustrialScraper(Scraper):

    def get_price(self, part_num):
        part_num = part_num.strip()
        self.PROXY = eval(json.loads(self.proxy_obj.rotate_proxy()))
        url = 'http://www.globalindustrial.com/searchResult?ref=h%2Fsearch&q=' + part_num + '&x=31&y=15'
        try:
            resp = self.session.get(url, proxies=self.PROXY)
        except Exception as e:
            return 0
        x = html.fromstring(resp.content)
        try:
            price = x.xpath(".//div[contains(@style,'font-size:14px; padding-top: 5px;') and contains(text(),'$')]/text()")[0].strip()
        except IndexError:
            return 0
        return self.clean_results(price)

    def scrap(self, brand):
        pass



class SqoneScraper(Scraper):

    def get_price(self, part_num):
        part_num = part_num.strip()
        self.PROXY = eval(json.loads(self.proxy_obj.rotate_proxy()))
        url = 'http://www.sqone.com/index.cfm?fuseaction=catalog.search'
        try:
            resp = self.session.post(url, proxies=self.PROXY, data={'searchQuery': part_num,
                                                                    'submitSearch.x':'0',
                                                                    'submitSearch.y':'0',
                                                                    'submitSearch':'Search',
                                                                    })
        except Exception as e:
            return 0
        x = html.fromstring(resp.content)
        try:
            price = x.xpath(".//div[contains(@class,'listCatalogProductSalePrice')]/text()")[0].strip()
        except IndexError:
            return 0
        return self.clean_results(price)

    def scrap(self, brand):
        pass


class TemcoScraper(Scraper):

    def get_price(self, part_num):
        part_num = part_num.strip()
        self.PROXY = eval(json.loads(self.proxy_obj.rotate_proxy()))
        url = 'http://www.temcoindustrialpower.com/search.html?t1=%s' % part_num
        try:
            resp = self.session.get(url, proxies=self.PROXY)
        except Exception as e:
            return 0
        x = html.fromstring(resp.content)
        try:
            price = x.xpath(".//h3[contains(@class,'price')]/text()")[0]
        except IndexError:
            return 0
        return self.clean_results(price)

    def scrap(self, brand):
        pass


class MotoragentsScraper(Scraper):

    def get_price(self, part_num):
        brand = 'Baldor'
        part_num = part_num.strip()
        self.PROXY = eval(json.loads(self.proxy_obj.rotate_proxy()))
        url = 'http://www.motoragents.com/%sMotors/%s.html' % (brand.capitalize(), part_num)
        try:
            resp = self.session.get(url, proxies=self.PROXY)
        except Exception as e:
            return 0
        x = html.fromstring(resp.content)
        try:
            price = x.xpath(".//b/font[contains(text(),'$')]/text()")[0].strip()
        except IndexError as e:
            print e
            return 0
        return self.clean_results(price)

    def scrap(self, brand):
        pass


class WalkeremdScraper(Scraper):

    def get_price(self, part_num):
        part_num = part_num.strip()
        self.PROXY = eval(json.loads(self.proxy_obj.rotate_proxy()))
        url = 'http://www.walkeremd.com/SearchResults.asp?Search=%s' % part_num
        try:
            resp = self.session.get(url, proxies=self.PROXY)
        except Exception as e:
            print e
            return 0
        x = html.fromstring(resp.content)

        try:
            not_found = x.xpath(".//div[contains(@class,'additional_search_phrases') and contains(text(),'No exact matches found')] | .//td[contains(text(),'No products match your search criteria')]")[0]
            return 0
        except IndexError as e:
            pass

        try:
            price = x.xpath(".//font[contains(@class,'pricecolor colors_productprice')]/text()")[0].strip()
        except IndexError as e:
            print url
            return 0
        return self.clean_results(price)

    def scrap(self, brand):
        pass


class AlliedelecScraper(Scraper):

    def get_price(self, part_num):
        part_num = part_num.strip()
        self.PROXY = eval(json.loads(self.proxy_obj.rotate_proxy()))
        resp = self.session.get('https://www.alliedelec.com/')
        x = html.fromstring(resp.text)
        event_validation = x.xpath(".//input[@name='__EVENTVALIDATION']/@value")
        view_state = x.xpath(".//input[@name='__VIEWSTATE']/@value")
        previous_page = x.xpath(".//input[@name='__PREVIOUSPAGE']/@value")
        previous_page = x.xpath(".//input[@name='__PREVIOUSPAGE']/@value")
        try:
            resp = self.session.post('https://www.alliedelec.com/', proxies=self.PROXY, data={'__LASTFOCUS':'',
                                                                    '__EVENTTARGET':'',
                                                                    '__EVENTARGUMENT':'',
                                                                    '__VIEWSTATE': view_state,
                                                                    '__PREVIOUSPAGE': previous_page,
                                                                    '__EVENTVALIDATION': event_validation,
                                                                    'ctl00$txtSearch': part_num,
                                                                    'ctl00$btnSearch.x':'44',
                                                                    'ctl00$btnSearch.y':'6',
                                                                    'ctl00$contentMain$txtUserName':'',
                                                                    'ctl00$contentMain$txtPassword':'',
                                                                    'ctl00$contentMain$txtEmail':'your email address',
                                                                    })
        except:
            return e
        x = html.fromstring(resp.content)
        try:
            price = x.xpath(".//b[contains(text(),'$')]/text()")[0].strip()
        except IndexError:
            return ''
        return self.clean_results(price)

    def scrap(self, brand):
        pass


class DigikeyScraper(Scraper):

    def get_price(self, part_num):
        part_num = part_num.strip()
        self.PROXY = eval(json.loads(self.proxy_obj.rotate_proxy()))
        url = 'http://www.digikey.com/product-search/en?x=16&y=16&lang=en&site=us&KeyWords=%s' % part_num
        try:
            resp = self.session.get(url, proxies=self.PROXY)
            # print resp.text
        except:
            return e
        x = html.fromstring(resp.content)

        try:
            # price = x.xpath(".//th[contains(text(),'Price')]/ancestor::tr/following::tr/text()")[0].strip()
            price = x.xpath(".//td[re:match(text(), '\d+\.\d+')]/text()", namespaces={"re": "http://exslt.org/regular-expressions"})[1].strip()
            print price
        except IndexError as e:
            print e
            print url
            return ''
        return self.clean_results(price)

    def scrap(self, brand):
        pass




if __name__ == '__main__':
    scraper = WalkerScraper()
    print scraper.get_price('mumu')
    scraper = WholesaleScraper()
    print scraper.get_price('AEM2238-4')
    scraper = GlobalindustrialScraper()
    print scraper.get_price('AEM2238-4')
    scraper = SqoneScraper()
    print scraper.get_price('AEM2238-4')
    scraper = TemcoScraper()
    print scraper.get_price('AEM2238-4')
    scraper = MotoragentScraper()
    print scraper.get_price('CL1301', 'baldor')
