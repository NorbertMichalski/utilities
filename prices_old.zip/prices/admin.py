from django.contrib import admin
from models import Competitor, Brand, Product, Result, LeesonReport, BaldorReport
from django.utils.translation import ugettext_lazy as _
import csv
from django.db.models.loading import get_model
from django.http import HttpResponse
from django.core.exceptions import PermissionDenied

def download_csv(modeladmin, request, queryset):
    if not request.user.is_staff:
        raise PermissionDenied
    # opts = modeladmin.model._meta
    opts = queryset.model._meta
    model = queryset.model
    response = HttpResponse(mimetype='text/csv')
    # force download.
    response['Content-Disposition'] = 'attachment;filename=export.csv'
    # the csv writer
    writer = csv.writer(response)
    field_names = [field.name for field in opts.fields]
    # Write a first row with header information
    writer.writerow(field_names)
    # Write data rows
    for obj in queryset:
        writer.writerow([getattr(obj, field) for field in field_names])
    return response
download_csv.short_description = "Download selected as csv"


class CheaperListFilter(admin.SimpleListFilter):
    # Human-readable title which will be displayed in the
    # right admin sidebar just above the filter options.
    title = _('Prices lower than ours')

    # Parameter for the filter that will be used in the URL query.
    parameter_name = 'cheaper'

    def lookups(self, request, model_admin):
        """
        Returns a list of tuples. The first element in each
        tuple is the coded value for the option that will
        appear in the URL query. The second element is the
        human-readable name for the option that will appear
        in the right sidebar.
        """
        return (
                (True, 'Yes'),
                (False, 'No'),
            )

    def queryset(self, request, queryset):
        """
        Returns the filtered queryset based on the value
        provided in the query string and retrievable via
        `self.value()`.
        """
        # Compare the requested value (either '80s' or '90s')
        # to decide how to filter the queryset.
        if self.value() is None:
            return queryset
        elif self.value() == 'True':
            q = queryset
            q_ids = [o.id for o in q if o.cheaper()]
            q = q.filter(id__in=q_ids)
            return q
        else:
            q = queryset
            q_ids = [o.id for o in q if not o.cheaper()]
            q = q.filter(id__in=q_ids)
            return q


class CompetitorAdmin(admin.ModelAdmin):
    list_display = ('name', 'website', 'last_scrap')

class BrandAdmin(admin.ModelAdmin):
    list_display = ('name',)

class ProductAdmin(admin.ModelAdmin):
    list_display = ('mro_id', 'part_number', 'brand', 'mro_price', 'updated')
    list_filter = ('brand__name', 'updated')
    search_fields = ['mro_id', 'part_number', 'brand__name']
    actions = [download_csv]

class ResultAdmin(admin.ModelAdmin):
    list_display = ('competitor', 'product', 'price', 'scraped')
    list_filter = ('competitor__name', 'product__brand__name', CheaperListFilter, 'scraped')
    search_fields = ['competitor__name', 'product__part_number', 'product__brand__name']
    actions = [download_csv]


class ReportAdmin(admin.ModelAdmin):
    brand = Brand.objects.filter(name='Baldor')
    # brand_competitors = Competitor.objects.filter(brand__in=brand)
    brand_competitors = Competitor.objects.all()
    competitors = [str(competitor.name) for competitor in brand_competitors]
    list_display1 = ['mro_id', 'part_number', 'brand', 'mro_price']
    list_display1.extend(competitors)
    list_display = list_display1
    list_filter = ('brand__name', 'updated', CheaperListFilter)
    search_fields = ['mro_id', 'part_number']
    actions = [download_csv]


admin.site.register(Competitor, CompetitorAdmin)
admin.site.register(Brand, BrandAdmin)
admin.site.register(Product, ProductAdmin)
admin.site.register(Result, ResultAdmin)
# admin.site.register(LeesonReport, ReportAdmin)
admin.site.register(BaldorReport, ReportAdmin)

