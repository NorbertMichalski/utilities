from django.db import models
from prices.scrapers.temco import TemcoScraper
from prices.models import Brand, Competitor, Product
import json



# Create your models here.

class Proxy(models.Model):
    address = models.IPAddressField()
    port = models.PositiveIntegerField()
    username = models.CharField(max_length=200)
    password = models.CharField(max_length=200)

    def __unicode__(self):
        pass
        data = '{"http": ("http://%s:%s@%s:%s")}' % (self.username, self.password, self.address, self.port)
        return data


class ProxyRotator(object):

    def __init__(self, *args, **kwargs):
        self.PROXY_TOTAL = Proxy.objects.count()
        self.PROXY_INDEX = 0
        self.PROXIES = Proxy.objects.all()

    def rotate_proxy(self):
        self.PROXY_INDEX += 1
        if self.PROXY_INDEX > self.PROXY_TOTAL - 1:
            self.PROXY_INDEX = 0
            print self.PROXY_INDEX
        current_proxy = self.PROXIES[self.PROXY_INDEX].__unicode__()
        print current_proxy
        return json.dumps(current_proxy)




class QuickScan(models.Model):
    search_brand = models.ForeignKey(Brand)
    search_product = models.CharField(max_length=100)

    def __unicode__(self):
        return self.search_product


    def temco_price(self):
        # part_number = self.scan
        part_number = 'self.scan'
        scraper = TemcoScraper()
        price = scraper.get_price(part_number)
        return price


'''
    fields = ['field_a', 'field_b', 'field_c']
    for field in fields:
        eval('%s = models.DecimalField(decimal_places=4, max_digits=10)' % field)

    def create_fields(self):
        competitors = []
        all_brand_objects = Brand.objects.filter(name=brand)
        for current_object in all_brand_objects:
            competitors.append(current_object.competitor)

        for competitor in competitors:
            pass

    # price1 = temco_price()
    
    # temco_price.admin_order_field = 'price'
    # temco_price.boolean = True
    # temco_price.short_description = 'Temco Price'
'''
