from django.contrib import admin
from models import Proxy, QuickScan
from django.forms import ModelForm
import django.forms as forms

'''
def my_view(request, *args, **kwargs):
    print 'mumu'
    pass

admin.site.register_view('temco', my_view)
'''

class ProxyAdmin(admin.ModelAdmin):
    list_display = ('address', 'port', 'username')



class QuickScanForm(ModelForm):
    schedule_toggle = forms.BooleanField(required=False)
    class Meta:
        model = QuickScan
        fields = ['search_brand', 'search_product']


class QuickScanAdmin(admin.ModelAdmin):
    form = QuickScanForm



admin.site.register(Proxy, ProxyAdmin)
admin.site.register(QuickScan, QuickScanAdmin)



