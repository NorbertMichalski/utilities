import os
from distutils.command.sdist import sdist
from setuptools import setup, find_packages

class sdist_hg(sdist):
    user_options = sdist.user_options + [
            ('dev', None, "Add a dev marker")
            ]

    def initialize_options(self):
        sdist.initialize_options(self)
        self.dev = 0

    def run(self):
        if self.dev:
            suffix = '.dev%d' % self.get_tip_revision()
            self.distribution.metadata.version += suffix
        sdist.run(self)

    def get_tip_revision(self, path=os.getcwd()):
        from mercurial.hg import repository
        from mercurial.ui import ui
        from mercurial import node
        repo = repository(ui(), path)
        tip = repo.changelog.tip()
        return repo.changelog.rev(tip)

setup(
    name = 'peach3-core',
    version = '2.0a1',
    author = 'Erik Scheffers',
    author_email = 'e.t.j.scheffers@tue.nl',
    description = "Core Django app for peach3",
    url = 'http://hg.peach3.nl/public/peach3-core/',
    install_requires = [
        'south!=0.8.3,<1.0',
        'docutils',
        'pygments',
        'unipath',
        'chardet',
        'pyCrypto',
        'pytz',
        'django-mptt',
        'django-classy-tags',
        'django-pdfviewer',
        'celery-with-redis<3.1',
        'django-celery<3.1',
    ],
    extras_require = {
        'compare': ['peach3-compare'],
        'daemon2': ['peach3-daemon2-compat'],
    },
    packages = find_packages('src'),
    package_dir = {'': 'src'},
    package_data = {'': [
        #'locale/en/LC_MESSAGES/*.mo',
        #'locale/nl/LC_MESSAGES/*.mo',
        #'templates/pwreset/help/*.html',
        #'templates/registration/help/*.html',
        #'xsd/*.xsd',
    ]},
    zip_safe = False,
    classifiers = [
        'Development Status :: 4 - Beta',
        'Intended Audience :: System Administrators',
        'Programming Language :: Python :: 2.6',
        'License :: Other/Proprietary License',
    ],
    cmdclass = {'sdist': sdist_hg}
)
