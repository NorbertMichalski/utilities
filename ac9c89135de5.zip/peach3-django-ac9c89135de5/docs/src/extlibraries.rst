******************
External Libraries
******************

Backend (Django/Python)
-----------------------

The following Python frameworks and libraries are currently used by peach³:

==============================  =======================================================================================
Name                            Description
==============================  =======================================================================================
`Chardet`_                      Character set detection
`Django`_                       Web Framework
`Django Celery`_                Django interface to `Celery`_, a Distributed Task Queue
`Django Classy Tags`_           Library to create class based template tags
`Django Extensions`_            Management extensions
`Django MPTT`_                  Tree Traversable Models
`Django Pipeline`_              Javascript and CSS management
`Docutils`_                     reStructuredText tools
`Mimeparse`_                    Parsing mime types
`pyCrypto`_                     Cryptograpy library
`Pygments`_                     Syntax highlighting
`pyPdf2`_                       PDF utilities
`Python DateUtil`_              Date and time utilities
`Python Redis`_                 Python interface to `Redis`_, an in-memory key-value store
`Tastypie`_                     RESTful APIs
`Unipath`_                      Object-oriented alternative to `os`/`os.path`/`shutil`
==============================  =======================================================================================

.. _Celery: http://celeryproject.org/
.. _Chardet: https://github.com/erikrose/chardet
.. _Django: https://djangoproject.org/
.. _Django Celery: http://docs.celeryproject.org/en/latest/django/index.html
.. _Django Classy Tags: http://django-classy-tags.readthedocs.org/en/latest/
.. _Django Debug Toolbar: https://github.com/django-debug-toolbar/django-debug-toolbar
.. _Django Extensions: https://github.com/django-extensions/django-extensions
.. _Django MPTT: https://github.com/django-mptt/django-mptt/
.. _Django Pipeline: http://django-pipeline.readthedocs.org/en/latest/
.. _Docutils: http://docutils.sourceforge.net/
.. _Mimeparse: https://code.google.com/p/mimeparse/
.. _pyCrypto: https://www.dlitz.net/software/pycrypto/
.. _Pygments: http://pygments.org/
.. _pyPdf2: http://knowah.github.io/PyPDF2/
.. _Python DateUtil: http://labix.org/python-dateutil
.. _Python Redis: https://pypi.python.org/pypi/redis/
.. _Redis: http://redis.io/
.. _Tastypie: http://django-tastypie.readthedocs.org/en/latest/toc.html
.. _Unipath: https://github.com/mikeorr/Unipath

Frontend (HTML/Javascript)
--------------------------

The following frameworks and libraries are currently used by the peach³ frontend web client (the new UI):

========================================  =============================================================================
Name                                      Description
========================================  =============================================================================
`Backbone`_                               `MVC`_ Framework
`Backbone-relational`_                    Model relations plugin for Backbone
`Backbone-tastypie`_                      Backbone and Tastypie compatibility layer
`Bootstrap`_                              CSS framework and UI widgets
`Django Javascript translation catalog`_  Django provided translation utilities
`Font Awesome`_                           Scalabe vector icons for Bootstrap
`jQuery`_                                 DOM traversal/manipulation
`jQuery BBQ`_                             Back Button & Query library
`jQuery File Upload`_                     File upload widget
`jQuery pjax`_                            Ajax based page loads
`jQuery ScrollIntoView`_                  Scrolling content into the viewport
`jQuery Sortable`_                        HTML5 Sortable jQuery Plugin
`JSON2`_                                  JSON fallback library
`Select2`_                                Select box replacement widget
`SpinJS`_                                 Imageless spinners
`Underscore`_                             Utility-belt library
========================================  =============================================================================

.. _Backbone: http://documentcloud.github.io/backbone/
.. _Backbone-relational: http://backbonerelational.org/
.. _Backbone-tastypie: https://github.com/PaulUithol/backbone-tastypie
.. _Bootstrap: http://twitter.github.io/bootstrap/
.. _Django JavaScript translation catalog: https://docs.djangoproject.com/en/1.5/topics/i18n/translation/#internationalization-in-javascript-code
.. _Font Awesome: http://fortawesome.github.io/Font-Awesome/
.. _jQuery: http://jquery.org/
.. _jQuery BBQ: http://benalman.com/projects/jquery-bbq-plugin/
.. _jQuery File Upload: http://blueimp.github.io/jQuery-File-Upload/
.. _jQuery Pjax: http://pjax.heroku.com/
.. _jQuery ScrollIntoView: http://erraticdev.blogspot.com/2011/02/jquery-scroll-into-view-plugin-with.html
.. _jQuery Sortable: http://farhadi.ir/projects/html5sortable
.. _JSON2: http://www.JSON.org/js.html
.. _MVC: https://en.wikipedia.org/wiki/Model%E2%80%93view%E2%80%93controller
.. _Select2: http://ivaynberg.github.io/select2/
.. _SpinJS: http://fgnass.github.io/spin.js/
.. _Underscore: http://documentcloud.github.io/underscore/
