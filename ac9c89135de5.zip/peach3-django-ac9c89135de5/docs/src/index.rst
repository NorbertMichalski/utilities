
====================
Peach³ documentation
====================

This document describes Peach³.

.. toctree::
   :maxdepth: 2
   :numbered:

   codingstd.rst
   extlibraries.rst
   uidesign.rst


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
