***************
Coding standard
***************

.. highlight:: python

This document describes the coding standard and style of peach³.

Python
======

Code style and layout should conform to PEP8_, the standard Python style guide [#]_.

All modules, functions, classes and methods should be documented using docstrings
readable by Sphinx_ for automatic document generation. Although most existing code is currently
lacking Sphinx readable documention, this should be considered a bug to be fixed, and new code
should be properly documented.

Unittests should be added to classes and functions where appropriate.

String constants in Python can either use single (``'``) or double quotes (``"``).
Use double quotes for human readable strings. These should most likely also be wrapped using
gettext_ or one of its variants, eg. returning a human readable string would look like::

   return ugettext(u"This string is human readable and translated")

As Django consistently uses Unicode strings for all internal use, all human readable
strings should most likely be defined as unicode strings (by using the ``u`` prefix to the string constant).

String constants that are not shown to users use single quotes::

   MONTHS = 'JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'

When both Django_ and the Python standard library provide similar functionality, the Django
functions should be preferred. For example, :py:func:`django.utils.http.urlquote` should be used
instead of :py:func:`urllib.quote`. See the `django.utils`_ documentation for the Django provided
replacements of the Python standard library.

Using a well documented and supported open source library that implements required
functionality is preferred over writing the functionality from scratch.

When a compatible open source library does not exist, but the functionality that should
be provided is not tightly coupled with peach³ features, the functionality should be
implemented as a separate library. An example of this is the `django-pdfviewer` library
that was created to render PDF documents to PNG images.

.. [#] Most (if not all) Python IDEs have tools to automatically check for PEP8_ conformance.

.. _Django: https://djangoproject.org/
.. _gettext: http://django.readthedocs.org/en/1.5.x/topics/i18n/translation.html#internationalization-in-python-code
.. _django.utils: http://django.readthedocs.org/en/1.5.x/ref/utils.html
.. _PEP8: http://www.python.org/dev/peps/pep-0008/
.. _Sphinx: http://sphinx-doc.org/

JavaScript
==========

JavaScript code style and layout should conform to the `jQuery JavaScript style guide`_, with the following exceptions:

* (Section 2) Spaces should be used for indentation instead of tabs. This is to keep editor settings for Python
  and JavaScript identical.
* (Section 5) The Underscore_ library provides functions for type-checking, those should be used instead.

Ideally, a JavaScript function has a single ``var`` definition at the top of the function. However, if by using
another ``var`` definition later creates more compact, or even better readable code, this should be prefered.

Closures_ should be used wherever possible. For example, all private methods of a class should be part of a
closure wrapping the class definition, and not part of the class prototype.

Normally, JavaScript files should use the following skeleton format:

.. code-block:: javascript

   /**! directory/filename.js */

   !function($, _, View){

       // all code goes here

   }(this.jQuery, this._, this.Backbone.View);

The parameters for the closure function should be the most often used global variables,
where :js:data:`$` and :js:data:`_` are most likely included.
The :js:data:`this` in the function call will resolve to the :js:data:`window` global variable.
The :js:data:`peach3` global variable does not have to be
included here, as it already is in a closure that wraps all JavaScript static files.

Every JavaScript source file should start with a comment containing the file name, like shown above.
This comment is not removed during minification because of the special syntax ``/**! … */``,
allowing the separate files to be identified within the minified version.

All JavaScript should be written with minification in mind, that is, variable names and function names can be verbose,
they will be minified anyway. Assigning (constant) values, global functions or classes that are used more than once or
twice to variables also keeps the code more compact because of the minification that will be applied. Sometimes, the
``this`` variable needs to be assigned to a local variable because it needs to be used in an unbound closure inside the
current scope. In that case, assign the ``this`` variable to a local variable named ``dit``, and use ``dit``
everywhere ``this`` would be used inside the function, not only inside the closure. For example:

.. code-block:: javascript

   function closure_example(){
       var dit = this;

       function done(){
           // Because done() is unbound, this === window

           // Call callback() on `this` of the enclosing function, which was assigned to `dit`.
           dit.callback();
       }

       // Call another_function() with the closure that was just defined as a parameter
       dit.another_function(done);
   }

All modules, functions, classes and methods should be documented using comments readable by
`Sphinx (JavaScript domain)`_ for automatic document generation.
Although most existing code is currently lacking Sphinx readable documention, this should be
considered a bug to be fixed, and new code should be properly documented.

Underscore_ and jQuery_ have some overlap in the utility functions they provide.
When both Underscore and jQuery provide the same functionality, Underscore is prefered over jQuery.

Using a well documented and supported open source library that implements required
functionality is preferred over writing the functionality from scratch.

.. _jQuery: http://jquery.org/
.. _jQuery JavaScript style guide: http://contribute.jquery.org/style-guide/js/
.. _Closures: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide/Closures
.. _Sphinx (JavaScript domain): http://sphinx-doc.org/domains.html#the-javascript-domain
.. _Underscore: http://documentcloud.github.io/underscore/
