*********************
User Interface Design
*********************

This document describes the design descisions behind the 'new' web-based user interface to peach³.

The core components on which the interface is built are `jQuery`_, `Backbone`_ and `Bootstrap`_.

Single page interface
---------------------

The interface (with a few exceptions) is a `Single-page application`_ (SPA) using HTML5 pushState_
functionality to provide full browser history support.

The switching of page content and updating the Browser's history is handled by Pjax_. This, together
with some server-side logic, will automatically handle the correct loading of new content into the page,
and updating the content when the user uses the browser back or forward buttons to navigate.

Pjax will also automatically fall back to reloading the full page when a timeout occurs or when the
a version mismatch is detected between the currently running JavaScript code and the server-side
JavaScript code.

On the Django side, url handling and the creation of views is mostly unchanged, as all Pjax related
handling is done by a context processor which sets a context variable ``pjaxbasetemplate`` containing the
base template to extend. A Pjax enabled template therefore looks like:

.. code-block:: django

    {% extends pjaxbasetemplate %}
    {% load ... %}

    {% block subtitle %} - some page{% endblock %}

    {% block content %}
        content
    {% endblock %}

The content of the web page (ie. everything below the top navbar) will be replaced with the contents
of the ``content`` block.

The title of the webpage (ie. the title that appears in a browser's tab) will be updated with the provided
``subtitle``. It will be appended to the fixed ``peach³`` title, so in order to separate the title from the subtitle,
a subtitle must start with a dash.

Pjax will detect a template that does not start with the ``{% extends pjaxbasetemplate %}`` command,
and will show the entire content like a normal page.

Page scaffolding
----------------

Most view templates only contain a scaffold for the content. The content itself is created using
Backbone_ views.

For example, lets look at (a part of) the Django template ``/templates/peach3/ui_2012/course/home.html``.
For more information about this syntax, see the `Django template language documentation`_.

The template is used to create the 'home' view of a course, the view that contains the list of
assignments for the specified course.


.. code-block:: html+django

    {% extends pjaxbasetemplate %}
    {% load i18n collect %}

    {% block content %}

        <div id="content-course-home">
            <div class="page-header">
                <h1 class="course-label"></h1>
            </div>

            <div id="course-home-content"></div>
        </div>

        <script type="text/x-backbone-template" id="course-home-member-view">
            <div id="about" class="hidden">
                <h2>{% trans "About" %}</h2>
                <div></div>
            </div>

            <div id="assignments">
                <h2>{% trans "Assignments" %}</h2>
                <div></div>
            </div>
        </script>

.. code-block:: javascript+django

        {% collect into global_script_afterload %}
          !function(){
              $('#content-course-home').coursehome({course:{{ course_json|safe }}, subcode:"{{ subcode }}"});
          }();
        {% endcollect %}

        {% collect into global_script_beforeunload %}
          $('#content-course-home').coursehome('destroy');
        {% endcollect %}

        {% collect into global_sourceurl %}
          //@ sourceURL=/pjax/peach3/ui_2012/course/home-{{course.period.slug}}-{{course.code}}.html
        {% endcollect %}

    {% endblock %}{# end of content #}

The only 'content' on this page is the ``<div>`` at the top. This ``<div>`` is the page skeleton.
All the other content on this page is either a Bootstrap template or JavaScript snippets.

The ``{% collect %}`` blocks are used to include snippets of JavaScript in the pages. The ``global_script_afterload``
snippet is executed right after the page was loaded, either as a normal page view or a Pjax update.

The ``global_script_beforeunload`` snippet is executed just before Pjax replaces the page content. Any cleanup should
be done in this snippet. In the example above, the script that was initialized in the first snippet is told
to destroy itself. Because Pjax only replaces content and not fully reloads the page,
if objects are not destroyed this way, they will remain active altough their page content is removed.
For example, their event handlers will still be attached to the
removed elements. This will result in these elements, although not visible anymore, remaining in memory,
resulting in memory leaks.

The ``global_sourceurl`` snippet is only used for debugging: it gives the dynamic scripts
on this page a name which Chrome and Firebug will use.

The ``<script type="text/x-backbone-template" id="course-home-member-view">`` section (and there are a few more
on the actual template itself that are not shown here) defines a Bootstrap template that is used by the scripts.
The ``type="text/x-backbone-template"`` attribute forces the browser to ignore this script tag during page rendering,
as the browser does not know how to interpret it.

So, now we have the scaffolding in place for this page, but how is the actual content loaded into it?

This is done in the ``global_script_afterload`` snippet. This snippet will be executed as soon
as the page has finished loading. It will either be called in a jQuery `DOM ready`_ event (for a full page load), or a
`pjax\:end`_ event (for a Pjax update). It uses jQuery (through the ``$`` object) to locate the scaffolding div (named
``content-course-home``) and it applies the ``$.fn.coursehome()`` function on it. This function is provided with
some arguments, so it will know which course to actually fetch from the server and show.

The ``$.fn.coursehome()`` function is not included on the page itself. It is part of the 'big' JavaScript that is
loaded when the user first accesses the site. The actual function is defined in
``/static/peach3/ui_2012/js/pages/course-home.js``.

The ``$.fn.coursehome()`` function initializes a Backbone View_ which will build the rest of the content for the page.

Models, Views and Controllers
-----------------------------

.. admonition:: note

    This section assumes you are familiar with `Object Orientation`_ and the use of closures_ in JavaScript.

Backbone_ is used as the MVC_ framework. Backbone defines base classes for models and views.
Backbone leaves the details of how the models and views interact free. Backbone does not define a
base class for controllers.

In peach³ views are nested. A top-level view is built using other views, which in turn can again include
other views. In a sense, the views act as a controller for the views they contain.

Most views in peach³ are defined similar to this:

.. code-block:: javascript
   :linenos:

    var ThingView = (function(){
        // Create the view for one item and insert it into the DOM
        function addOne(item){
            var cid = item.cid,
                viewId = 'item'+cid,
                view = this.$('#'+viewId).first().data('view');

            // If the view does not yet exist, create it and add it
            if (!view){
                view = new ItemView({
                    id: viewId,
                    item: item
                });
                this.$list.append(view.render().data('view', view));
            }

            return view;
        }

        // Create views for all models
        function addAll(callback){
            var dit = this,
                items = dit.thing.get('items'),
                rendering = items.length+1;

            function done(){
                // as soon as all items have rendered, fire the callback
                if (!(rendering -= 1)){
                    dit.rendered.fire(dit);
                }
            }

            items.each(function(item){
                addOne.call(dit).rendered.add(done);
            });

            // make sure done() is called even if there was nothing to add
            done();
        }

        // Fetch the items from the thing
        function fetchItems(){
            var dit = this,
                jqxhrs = dit.thing.fetchRelated('utems'),
                fetching = jqxhrs.length+1;

            function done(){
                // as soon as all items have been fetched, resolve the fetched Deferred
                if (!(fetching -= 1)){
                    dit.fetched.resolve();
                }
            };

            // add done() as a callback to each jqxhr deferred
            _.each(jqxhrs, function(jqxhr){
                jqxhr.done(done);
            });

            // make sure done() is called even if there was nothing to fetch
            done();
        }

        return View.extend({
            initialize: function(){
                _.extend(this, {
                    thing: options.thing,
                    fetched: $.Deferred(),
                    rendered: $.Callbacks('once memory')
                });

                fetchItems.call(this);
            },

            destroy: function(){
                if (this.$list){
                    this.$list.children('li').each(function(){
                        $(this).data('view').destroy();
                    });
                }
            },

            render: function(){
                this.$list = $('<ul/>').appendTo(this.$el);
                this.fetched.done(_.bind(addAll, this));
                return this.$el;
            }
        });
    })();

In this code ``$`` (the dollar sign) refers to the jQuery_ object
and ``_`` (the underscore) refers to the Underscore_ object.

When this view is created like this:

.. code-block:: javascript

   var theThing = new Thing({items:['thing1', 'thing2', 'thing3']}),
       view = new ThingView({thing:theThing});

the ``initialize()`` method is called by Backbone as part of the view object construction with ``options`` set to the
javascript Object provided to the constructor.
In our example, we assume that the thing has a list of items (with ids ``thing1``, ``thing2``, and ``thing3``),
that still need to be fetched from the server.

This fetch is initiated from within the ``initialize()`` method  with the call to the ``fetchItems()`` function.
This ``fetchItems()`` function (along with the ``addOne`` and ``addAll`` functions) is defined in a closure making
these functions private to our ``ThingView``. Because these functions are not part of ``ThingView.prototype``,
they must be called as ``fetchItems.call(this)`` instead of ``this.fetchItems()``.

Because the fetching of the items is done asynchronously the view must know when the objects have been fetched
before it can render them.

This is done using a jQuery Deferred_. A Deferred registers callbacks that will be called when the deferred's
``done()`` or ``fail()`` methods are called.

``fetchItems`` asks Bootstrap to fetch the items of the thing. The call to ``fetchRelated`` returns a list of
Deferreds. Once all those deferreds are resolved, all items have been fetched, and the views ``fetched`` deferred
can resolve.

When the view was created and initialized using ``new ThingView({thing:theThing})``, the view object
was created immediately and returned by the new operator. The items were most likely not yet fetched. 
This will be done in the background.

Besides fetching the items, nothing else happens. Until the view is requested to render itself that is:

.. code-block:: javascript

    var $el = view.render();
    $('#thing').append($el);

The call to the ``view()`` method of the ThingView returns a jQuery DOM element for the rendered view. This element is
created but not inserted into the DOM yet, ie. it is still not visible. The insertion of a view into the DOM is always
the view's parents concern.

The ``render()`` method adds a ``<li>`` to the view's ``<div>`` (which by the way was created for us by Bootstrap
as part of the view construction). The ``render()`` method then adds a callback to the ``fetched`` deferred that was
created during the initialization.

As soon as the ``fetched`` deferred resolves (and therefore, as soon as the items have been fetched
from the server), the ``addAll`` method is called. ``addAll`` loops over all the items to be added to the view,
calls ``addOne`` to create the views and fires the ``rendered`` Callback_ as soon as all the item views
have finished rendering.

When the view is no longer needed, its ``destroy()`` method should be called, which will find all the child views
and calls their ``destroy()`` method.

.. _Backbone: http://documentcloud.github.io/backbone/
.. _Bootstrap: http://twitter.github.io/bootstrap/
.. _Callback: http://api.jquery.com/category/callbacks-object/
.. _closures: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide/Closures
.. _Deferred: http://api.jquery.com/category/deferred-object/
.. _Django template language documentation: https://docs.djangoproject.com/en/1.5/topics/templates/
.. _jQuery: http://jquery.org/
.. _DOM ready: http://api.jquery.com/jQuery/#jQuery3
.. _MVC: https://en.wikipedia.org/wiki/Model%E2%80%93view%E2%80%93controller
.. _Object orientation: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Introduction_to_Object-Oriented_JavaScript
.. _Pjax: http://pjax.heroku.com/
.. _pjax\:end: https://github.com/defunkt/jquery-pjax#start-and-end
.. _pushState: http://www.w3.org/TR/2011/WD-html5-20110113/history.html#the-history-interface
.. _Single-page application: https://en.wikipedia.org/wiki/Single-page_application
.. _Twitter: https://twitter.com/
.. _Underscore: http://documentcloud.github.io/underscore/
.. _View: http://documentcloud.github.io/backbone/#View
