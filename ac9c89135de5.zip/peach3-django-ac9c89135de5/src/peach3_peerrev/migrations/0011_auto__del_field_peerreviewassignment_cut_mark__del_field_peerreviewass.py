# -*- coding: utf-8 -*-
import datetime
from south.db import db
from south.v2 import SchemaMigration
from django.db import models


class Migration(SchemaMigration):

    def forwards(self, orm):
        # Deleting field 'PeerReviewAssignment.cut_mark'
        db.delete_column('peach3_peerreview_assignment', 'cut_mark')

        # Deleting field 'PeerReviewAssignment.scrubbing'
        db.delete_column('peach3_peerreview_assignment', 'scrubbing')

    def backwards(self, orm):
        # Adding field 'PeerReviewAssignment.cut_mark'
        db.add_column('peach3_peerreview_assignment', 'cut_mark',
                      self.gf('django.db.models.fields.CharField')(default='-----8<-----  -----8<-----', max_length=256),
                      keep_default=False)

        # Adding field 'PeerReviewAssignment.scrubbing'
        db.add_column('peach3_peerreview_assignment', 'scrubbing',
                      self.gf('django.db.models.fields.BooleanField')(default=True),
                      keep_default=False)

    models = {
        'auth.group': {
            'Meta': {'object_name': 'Group'},
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'name': ('django.db.models.fields.CharField', [], {'unique': 'True', 'max_length': '80'}),
            'permissions': ('django.db.models.fields.related.ManyToManyField', [], {'to': "orm['auth.Permission']", 'symmetrical': 'False', 'blank': 'True'})
        },
        'auth.permission': {
            'Meta': {'ordering': "('content_type__app_label', 'content_type__model', 'codename')", 'unique_together': "(('content_type', 'codename'),)", 'object_name': 'Permission'},
            'codename': ('django.db.models.fields.CharField', [], {'max_length': '100'}),
            'content_type': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['contenttypes.ContentType']"}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '50'})
        },
        'auth.user': {
            'Meta': {'object_name': 'User'},
            'date_joined': ('django.db.models.fields.DateTimeField', [], {'default': 'datetime.datetime.now'}),
            'email': ('django.db.models.fields.EmailField', [], {'max_length': '75', 'blank': 'True'}),
            'first_name': ('django.db.models.fields.CharField', [], {'max_length': '30', 'blank': 'True'}),
            'groups': ('django.db.models.fields.related.ManyToManyField', [], {'to': "orm['auth.Group']", 'symmetrical': 'False', 'blank': 'True'}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'is_active': ('django.db.models.fields.BooleanField', [], {'default': 'True'}),
            'is_staff': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'is_superuser': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'last_login': ('django.db.models.fields.DateTimeField', [], {'default': 'datetime.datetime.now'}),
            'last_name': ('django.db.models.fields.CharField', [], {'max_length': '30', 'blank': 'True'}),
            'password': ('django.db.models.fields.CharField', [], {'max_length': '128'}),
            'user_permissions': ('django.db.models.fields.related.ManyToManyField', [], {'to': "orm['auth.Permission']", 'symmetrical': 'False', 'blank': 'True'}),
            'username': ('django.db.models.fields.CharField', [], {'unique': 'True', 'max_length': '30'})
        },
        'contenttypes.contenttype': {
            'Meta': {'ordering': "('name',)", 'unique_together': "(('app_label', 'model'),)", 'object_name': 'ContentType', 'db_table': "'django_content_type'"},
            'app_label': ('django.db.models.fields.CharField', [], {'max_length': '100'}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'model': ('django.db.models.fields.CharField', [], {'max_length': '100'}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '100'})
        },
        'peach3.assignmentedition': {
            'Meta': {'ordering': "('order',)", 'unique_together': "(('courseedition', 'slug'),)", 'object_name': 'AssignmentEdition'},
            'assignmentset': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['peach3.AssignmentSet']", 'null': 'True', 'blank': 'True'}),
            'courseedition': ('mptt.fields.TreeForeignKey', [], {'to': "orm['peach3.CourseEdition']"}),
            'created': ('django.db.models.fields.DateTimeField', [], {'default': 'datetime.datetime.now'}),
            'default_language': ('django.db.models.fields.CharField', [], {'default': "'en'", 'max_length': '16'}),
            'default_name': ('django.db.models.fields.CharField', [], {'max_length': '100'}),
            'gradingsystems': ('django.db.models.fields.related.ManyToManyField', [], {'to': "orm['peach3.GradingSystem']", 'symmetrical': 'False', 'blank': 'True'}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'languages': ('django.db.models.fields.related.ManyToManyField', [], {'to': "orm['peach3.ProgrammingLanguage']", 'symmetrical': 'False', 'blank': 'True'}),
            'layout': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['peach3.AssignmentLayout']", 'null': 'True', 'blank': 'True'}),
            'level': ('django.db.models.fields.PositiveIntegerField', [], {'db_index': 'True'}),
            'lft': ('django.db.models.fields.PositiveIntegerField', [], {'db_index': 'True'}),
            'observelevel': ('django.db.models.fields.PositiveSmallIntegerField', [], {'default': '1'}),
            'order': ('django.db.models.fields.PositiveIntegerField', [], {'null': 'True', 'blank': 'True'}),
            'parent': ('mptt.fields.TreeForeignKey', [], {'blank': 'True', 'related_name': "'children'", 'null': 'True', 'to': "orm['peach3.AssignmentEdition']"}),
            'reviewlevel': ('django.db.models.fields.PositiveSmallIntegerField', [], {'default': '1'}),
            'reviewpublishlevel': ('django.db.models.fields.PositiveSmallIntegerField', [], {'default': '1'}),
            'rght': ('django.db.models.fields.PositiveIntegerField', [], {'db_index': 'True'}),
            'slug': ('django.db.models.fields.SlugField', [], {'max_length': '32'}),
            'tree_id': ('django.db.models.fields.PositiveIntegerField', [], {'db_index': 'True'})
        },
        'peach3.assignmentlayout': {
            'Meta': {'object_name': 'AssignmentLayout'},
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'name': ('django.db.models.fields.CharField', [], {'unique': 'True', 'max_length': '80'})
        },
        'peach3.assignmentset': {
            'Meta': {'ordering': "('order',)", 'object_name': 'AssignmentSet'},
            'courseedition': ('mptt.fields.TreeForeignKey', [], {'to': "orm['peach3.CourseEdition']"}),
            'default_language': ('django.db.models.fields.CharField', [], {'default': "'en'", 'max_length': '16'}),
            'default_name': ('django.db.models.fields.CharField', [], {'max_length': '100'}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'order': ('django.db.models.fields.PositiveIntegerField', [], {'null': 'True', 'blank': 'True'})
        },
        'peach3.assignmentslot': {
            'Meta': {'object_name': 'AssignmentSlot'},
            'allowedTypes': ('django.db.models.fields.related.ManyToManyField', [], {'to': "orm['peach3.FileType']", 'symmetrical': 'False', 'blank': 'True'}),
            'assignmentsubmlayout': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['peach3.AssignmentLayout']"}),
            'default_language': ('django.db.models.fields.CharField', [], {'default': "'en'", 'max_length': '16'}),
            'default_name': ('django.db.models.fields.CharField', [], {'max_length': '100'}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'namePattern': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'order': ('django.db.models.fields.PositiveIntegerField', [], {}),
            'required': ('django.db.models.fields.BooleanField', [], {'default': 'False'})
        },
        'peach3.comment': {
            'Meta': {'object_name': 'Comment'},
            'author': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['auth.User']"}),
            'created': ('django.db.models.fields.DateTimeField', [], {'default': 'datetime.datetime.now'}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'parent_content_type': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['contenttypes.ContentType']"}),
            'parent_id': ('django.db.models.fields.PositiveIntegerField', [], {}),
            'response_to': ('django.db.models.fields.related.ForeignKey', [], {'blank': 'True', 'related_name': "'response_set'", 'null': 'True', 'to': "orm['peach3.Comment']"})
        },
        'peach3.courseedition': {
            'Meta': {'unique_together': "(('code', 'period'),)", 'object_name': 'CourseEdition'},
            'cluster_selection': ('django.db.models.fields.CharField', [], {'default': "'M'", 'max_length': '1'}),
            'code': ('django.db.models.fields.SlugField', [], {'max_length': '16'}),
            'created': ('django.db.models.fields.DateTimeField', [], {'default': 'datetime.datetime.now'}),
            'created_by': ('django.db.models.fields.related.ForeignKey', [], {'default': 'None', 'to': "orm['auth.User']"}),
            'default_language': ('django.db.models.fields.CharField', [], {'default': "'en'", 'max_length': '16'}),
            'default_name': ('django.db.models.fields.CharField', [], {'max_length': '100'}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'level': ('django.db.models.fields.PositiveIntegerField', [], {'db_index': 'True'}),
            'lft': ('django.db.models.fields.PositiveIntegerField', [], {'db_index': 'True'}),
            'managers': ('django.db.models.fields.related.ManyToManyField', [], {'symmetrical': 'False', 'related_name': "'courseedition_manager_set'", 'blank': 'True', 'to': "orm['auth.User']"}),
            'parent': ('mptt.fields.TreeForeignKey', [], {'blank': 'True', 'related_name': "'children'", 'null': 'True', 'to': "orm['peach3.CourseEdition']"}),
            'period': ('mptt.fields.TreeForeignKey', [], {'to': "orm['peach3.Period']"}),
            'rght': ('django.db.models.fields.PositiveIntegerField', [], {'db_index': 'True'}),
            'scoreboard': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'tree_id': ('django.db.models.fields.PositiveIntegerField', [], {'db_index': 'True'})
        },
        'peach3.filerevision': {
            'Meta': {'object_name': 'FileRevision'},
            'charset': ('django.db.models.fields.CharField', [], {'max_length': '32', 'blank': 'True'}),
            'created': ('django.db.models.fields.DateTimeField', [], {'default': 'datetime.datetime.now'}),
            'file': ('django.db.models.fields.files.FileField', [], {'max_length': '300', 'null': 'True'}),
            'filetype': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['peach3.FileType']", 'null': 'True', 'blank': 'True'}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'sha1': ('django.db.models.fields.CharField', [], {'max_length': '40'})
        },
        'peach3.filetype': {
            'Meta': {'object_name': 'FileType'},
            'base_type': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'binary_content': ('django.db.models.fields.NullBooleanField', [], {'null': 'True', 'blank': 'True'}),
            'default_language': ('django.db.models.fields.CharField', [], {'default': "'en'", 'max_length': '16'}),
            'default_name': ('django.db.models.fields.CharField', [], {'unique': 'True', 'max_length': '100'}),
            'iconcls': ('django.db.models.fields.CharField', [], {'max_length': '30', 'blank': 'True'}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'lexer': ('django.db.models.fields.CharField', [], {'default': "''", 'max_length': '80', 'blank': 'True'}),
            'lexer_parameters': ('django.db.models.fields.TextField', [], {'blank': 'True'}),
            'mimetypes': ('django.db.models.fields.TextField', [], {'default': "''", 'blank': 'True'}),
            'namepatterns': ('django.db.models.fields.TextField', [], {'default': "''", 'blank': 'True'})
        },
        'peach3.gradingsystem': {
            'Meta': {'object_name': 'GradingSystem'},
            'default_language': ('django.db.models.fields.CharField', [], {'default': "'en'", 'max_length': '16'}),
            'default_name': ('django.db.models.fields.CharField', [], {'unique': 'True', 'max_length': '100'}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'})
        },
        'peach3.period': {
            'Meta': {'ordering': "('_begin', '_end')", 'unique_together': "(('_begin', '_end'),)", 'object_name': 'Period'},
            '_begin': ('django.db.models.fields.DateTimeField', [], {'default': 'datetime.datetime(1899, 1, 1, 0, 0)', 'db_column': "'begin'", 'db_index': 'True'}),
            '_end': ('django.db.models.fields.DateTimeField', [], {'default': 'datetime.datetime(3001, 1, 1, 0, 0)', 'db_column': "'end'", 'db_index': 'True'}),
            'default_language': ('django.db.models.fields.CharField', [], {'default': "'en'", 'max_length': '16'}),
            'default_name': ('django.db.models.fields.CharField', [], {'max_length': '100'}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'level': ('django.db.models.fields.PositiveIntegerField', [], {'db_index': 'True'}),
            'lft': ('django.db.models.fields.PositiveIntegerField', [], {'db_index': 'True'}),
            'parent': ('mptt.fields.TreeForeignKey', [], {'blank': 'True', 'related_name': "'children'", 'null': 'True', 'to': "orm['peach3.Period']"}),
            'rght': ('django.db.models.fields.PositiveIntegerField', [], {'db_index': 'True'}),
            'slug': ('django.db.models.fields.CharField', [], {'unique': 'True', 'max_length': '8'}),
            'tree_id': ('django.db.models.fields.PositiveIntegerField', [], {'db_index': 'True'})
        },
        'peach3.programminglanguage': {
            'Meta': {'object_name': 'ProgrammingLanguage', 'db_table': "'peach3_proglang'"},
            'code': ('django.db.models.fields.CharField', [], {'max_length': '16'}),
            'default_language': ('django.db.models.fields.CharField', [], {'default': "'en'", 'max_length': '16'}),
            'default_name': ('django.db.models.fields.CharField', [], {'unique': 'True', 'max_length': '100'}),
            'enabled': ('django.db.models.fields.BooleanField', [], {'default': 'True'}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'})
        },
        'peach3.submission': {
            'Meta': {'object_name': 'Submission'},
            'assignmentedition': ('mptt.fields.TreeForeignKey', [], {'to': "orm['peach3.AssignmentEdition']"}),
            'authors': ('django.db.models.fields.related.ManyToManyField', [], {'to': "orm['auth.User']", 'symmetrical': 'False'}),
            'courseedition': ('mptt.fields.TreeForeignKey', [], {'to': "orm['peach3.CourseEdition']"}),
            'created': ('django.db.models.fields.DateTimeField', [], {'default': 'datetime.datetime.now', 'db_index': 'True'}),
            'created_by': ('django.db.models.fields.related.ForeignKey', [], {'default': 'None', 'related_name': "'submission_created_set'", 'to': "orm['auth.User']"}),
            'files': ('django.db.models.fields.related.ManyToManyField', [], {'to': "orm['peach3.FileRevision']", 'through': "orm['peach3.SubmissionFile']", 'symmetrical': 'False'}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'is_group': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'language': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['peach3.ProgrammingLanguage']", 'null': 'True', 'blank': 'True'}),
            'modified': ('django.db.models.fields.DateTimeField', [], {'db_index': 'True', 'null': 'True', 'blank': 'True'}),
            'submitted': ('django.db.models.fields.DateTimeField', [], {'null': 'True', 'blank': 'True'}),
            'submitted_by': ('django.db.models.fields.related.ForeignKey', [], {'blank': 'True', 'related_name': "'submission_submitted_set'", 'null': 'True', 'to': "orm['auth.User']"})
        },
        'peach3.submissionfile': {
            'Meta': {'object_name': 'SubmissionFile'},
            'created': ('django.db.models.fields.DateTimeField', [], {'default': 'datetime.datetime.now'}),
            'created_by': ('django.db.models.fields.related.ForeignKey', [], {'default': 'None', 'to': "orm['auth.User']"}),
            'file': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['peach3.FileRevision']"}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '300'}),
            'provided_mimetype': ('django.db.models.fields.CharField', [], {'max_length': '256', 'blank': 'True'}),
            'slot': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['peach3.AssignmentSlot']", 'null': 'True', 'blank': 'True'}),
            'submission': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['peach3.Submission']"})
        },
        'peach3_peerrev.peerreview': {
            'Meta': {'object_name': 'PeerReview', 'db_table': "'peach3_peerreview'"},
            'assignment': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['peach3_peerrev.PeerReviewAssignment']"}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'identifier': ('django.db.models.fields.CharField', [], {'max_length': '16'}),
            'order': ('django.db.models.fields.related.ForeignKey', [], {'blank': 'True', 'related_name': "'order'", 'null': 'True', 'to': "orm['peach3.SubmissionFile']"}),
            'review': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['peach3.SubmissionFile']", 'null': 'True', 'blank': 'True'}),
            'reviewer': ('django.db.models.fields.related.ManyToManyField', [], {'to': "orm['auth.User']", 'symmetrical': 'False'}),
            'submission': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['peach3.Submission']"})
        },
        'peach3_peerrev.peerreviewassignment': {
            'Meta': {'object_name': 'PeerReviewAssignment', 'db_table': "'peach3_peerreview_assignment'"},
            'distribution_spread': ('django.db.models.fields.IntegerField', [], {'default': '3'}),
            'feedback_release': ('django.db.models.fields.DateTimeField', [], {'default': 'datetime.datetime.now'}),
            'original_assignment': ('django.db.models.fields.related.ForeignKey', [], {'related_name': "'peerreviewed_via_set'", 'to': "orm['peach3.AssignmentEdition']"}),
            'original_submitter_feedback': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'ranking': ('django.db.models.fields.IntegerField', [], {'default': '0'}),
            'review_assignment': ('django.db.models.fields.related.OneToOneField', [], {'to': "orm['peach3.AssignmentEdition']", 'unique': 'True', 'primary_key': 'True'}),
            'reviewed_by_group': ('django.db.models.fields.BooleanField', [], {'default': 'True'}),
            'reviewing': ('django.db.models.fields.IntegerField', [], {'default': '2'})
        }
    }

    complete_apps = ['peach3_peerrev']