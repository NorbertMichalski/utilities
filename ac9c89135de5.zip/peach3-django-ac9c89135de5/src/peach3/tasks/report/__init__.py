from celery import Task

class ReportGeneratorBaseTask(Task): #pylint: disable=W0223
    abstract = True
    track_started = True
