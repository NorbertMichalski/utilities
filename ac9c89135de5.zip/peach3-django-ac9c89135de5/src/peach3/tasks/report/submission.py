from django.contrib.auth import get_user_model
from django.utils.encoding import smart_str
from django.utils.timezone import localtime

from peach3.models import Submission, AssignmentEdition
from peach3.tasks.report import ReportGeneratorBaseTask
from peach3.utils.files import create_filename, create_path

import celery

from unipath import Path

from zipfile import ZipFile, ZIP_DEFLATED

@celery.task(base=ReportGeneratorBaseTask) #pylint: disable=E1102
def multi_submission_download_task(full_path, sb_pks, author_pk, ae_pk): #pylint: disable=E0213
    def format_date(ts):
        return localtime(ts).strftime('%Y%m%d%H%M%S')

    current_task = celery.current_task

    sbs = Submission.objects.filter(pk__in=sb_pks)
    author = get_user_model().objects.get(pk=author_pk) if author_pk else None
    ae = AssignmentEdition.objects.get(pk=ae_pk) if ae_pk else None

    zf = ZipFile(full_path, 'w', ZIP_DEFLATED, False)

    num_sbs = len(sbs)
    for sbi, sb in enumerate(sbs):
        #if self.cancel:
        #    break
        current_task.update_state(
            state='PROGRESS',
            meta={'progress': (sbi*99) / num_sbs}
        )

        if ae is None:
            aepath = sb.assignmentedition.slug
        else:
            aepath = ''

        arcpathparts = []
        if author is None:
            arcpathparts.append(create_filename('', *[au.username for au in sb.get_authors()]))
        if num_sbs>1:
            arcpathparts.append(format_date(sb.submitted))

        sbfs = sb.submissionfile_set.all()
        num_sbfs = len(sbfs)

        sbi2 = sbi*num_sbfs
        num_sbssbfs = num_sbs*num_sbfs

        for sbfi, sbf in enumerate(sbfs):
            #if self.cancel:
            #    break
            current_task.update_state(
                state='PROGRESS',
                meta={'progress': (sbi2+sbfi)*99 / num_sbssbfs}
            )

            filepath = Path(sbf.file.file.path)
            if filepath.exists():
                sbfpathparts = arcpathparts[:]

                if hasattr(sbf, 'peerreview_set'):
                    pr = sbf.peerreview_set.all()
                    if len(pr)==1:
                        pr = pr[0]
                        rvsb = pr.submission
                        sbfpathparts[0:0]=[
                            create_filename('', *[au.username for au in rvsb.get_authors()]),
                            format_date(rvsb.submitted),
                            'peerreviews',
                        ]

                path = create_path(aepath, *sbfpathparts)
                arcname = smart_str('%s/%s' % (path, sbf.name))
                zf.write(smart_str(filepath), arcname)

    zf.close()
