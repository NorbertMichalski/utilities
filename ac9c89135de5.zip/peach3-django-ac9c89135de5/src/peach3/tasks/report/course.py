from django.contrib.auth import get_user_model
from django.utils.encoding import smart_str

from peach3.models import CourseEdition, SubmissionAuthor, Cluster
from peach3.tasks.report import ReportGeneratorBaseTask
from peach3.utils.submission import (filter_active_submission, visible_submission_state,
                                     get_submission_state)

import celery

import codecs

@celery.task(base=ReportGeneratorBaseTask) #pylint: disable=E1102
def course_overview_task(full_path, user_pk, ce_pk):
    current_task = celery.current_task

    user = get_user_model().objects.get(pk=user_pk)
    ce = CourseEdition.objects.get(pk=ce_pk)

    aes = ce.assignmentedition_set.order_by('id')

    sb_by_au = {}
    for sbau in SubmissionAuthor.objects.filter(submission__courseedition=ce, active=True)\
                                        .select_related('submission'):
        auid = sbau.author_id
        aeid = sbau.submission.assignmentedition_id
        if auid not in sb_by_au:
            sb_by_au[auid] = {}

        assert aeid not in sb_by_au[auid]

        sb_by_au[auid][aeid] = sbau.submission

    #noinspection PyPep8Naming
    User = get_user_model()

    clusters = ce.get_clusters(admin_cluster=False)
    members = User.objects.filter(clustermember__cluster__in = clusters).order_by('username')

    admin_cl = ce.get_admin_cluster()
    staff = User.objects.filter(clustermember__cluster = admin_cl).order_by('username')

    with open(full_path, 'w') as f:
        # Write UTF-8 BOM
        f.write(codecs.BOM_UTF8)

        header = ['"id"', '"name"', '"email"', '"cluster"']
        for ae in aes:
            header.extend(['"' + ae.get_display_name() + '"', ''"(score)"''])

        f.write(smart_str(';'.join(header) + "\n"))

        num_aus = len(members) + len(staff)
        aui = 0
        for users, is_staff in [(members, False), (staff, True)]:
            for au in users:
                current_task.update_state(
                    state='PROGRESS',
                    meta={'progress': (aui*100) / num_aus}
                )

                sb_by_ae = sb_by_au.get(au.id, {})
                if sb_by_ae or not is_staff:
                    cl = ce.get_user_cluster(au)

                    line = [
                        '"' + au.username + '"',
                        '"' + au.get_full_name_sortable() + '"',
                        '"' + au.email + '"',
                        '"' + (cl.name if cl else '') + '"',
                    ]

                    for ae in aes:
                        try:
                            sb = sb_by_ae[ae.id]
                        except KeyError:
                            line.extend(['"-"', ''])
                        else:
                            icon, msg, longmsg = visible_submission_state(
                                *get_submission_state(sb, user, au)
                            )

                            line.append('"' + msg + '"')

                            score = sb.get_score(user)
                            if score is not None:
                                line.append(str(score))
                            else:
                                line.append('')

                    f.write(smart_str(';'.join(line))+"\n")

                aui += 1

