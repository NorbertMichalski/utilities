# encoding: utf-8
import datetime
from south.db import db
from south.v2 import SchemaMigration
from django.db import models

class Migration(SchemaMigration):

    def forwards(self, orm):
        
        # Adding model 'TranslatedName'
        db.create_table('peach3_translatedname', (
            ('id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('content_type', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['contenttypes.ContentType'])),
            ('object_id', self.gf('django.db.models.fields.PositiveIntegerField')()),
            ('language', self.gf('django.db.models.fields.CharField')(max_length=16)),
            ('name', self.gf('django.db.models.fields.CharField')(max_length=100)),
        ))
        db.send_create_signal('peach3', ['TranslatedName'])

        # Adding unique constraint on 'TranslatedName', fields ['content_type', 'object_id', 'language']
        db.create_unique('peach3_translatedname', ['content_type_id', 'object_id', 'language'])

        # Adding model 'GradingSystem'
        db.create_table('peach3_gradingsystem', (
            ('id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('default_name', self.gf('django.db.models.fields.CharField')(unique=True, max_length=100)),
            ('default_language', self.gf('django.db.models.fields.CharField')(default='en', max_length=16)),
        ))
        db.send_create_signal('peach3', ['GradingSystem'])

        # Adding model 'Grade'
        db.create_table('peach3_grade', (
            ('id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('default_name', self.gf('django.db.models.fields.CharField')(max_length=100)),
            ('default_language', self.gf('django.db.models.fields.CharField')(default='en', max_length=16)),
            ('system', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['peach3.GradingSystem'])),
            ('icon', self.gf('django.db.models.fields.CharField')(max_length=80, blank=True)),
            ('value_low', self.gf('django.db.models.fields.DecimalField')(max_digits=7, decimal_places=2)),
            ('value_high', self.gf('django.db.models.fields.DecimalField')(null=True, max_digits=7, decimal_places=2, blank=True)),
            ('passing', self.gf('django.db.models.fields.NullBooleanField')(null=True, blank=True)),
        ))
        db.send_create_signal('peach3', ['Grade'])

        # Adding unique constraint on 'Grade', fields ['system', 'default_name']
        db.create_unique('peach3_grade', ['system_id', 'default_name'])

        # Adding model 'Realm'
        db.create_table('peach3_realm', (
            ('id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('default_name', self.gf('django.db.models.fields.CharField')(unique=True, max_length=100)),
            ('default_language', self.gf('django.db.models.fields.CharField')(default='en', max_length=16)),
            ('site', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['sites.Site'])),
        ))
        db.send_create_signal('peach3', ['Realm'])

        # Adding model 'Course'
        db.create_table('peach3_course', (
            ('id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
        ))
        db.send_create_signal('peach3', ['Course'])

        # Adding model 'Period'
        db.create_table('peach3_period', (
            ('id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('default_name', self.gf('django.db.models.fields.CharField')(max_length=100)),
            ('default_language', self.gf('django.db.models.fields.CharField')(default='en', max_length=16)),
            ('slug', self.gf('django.db.models.fields.CharField')(unique=True, max_length=8)),
            ('_begin', self.gf('django.db.models.fields.DateTimeField')(default=None, null=True, db_column='begin', blank=True)),
            ('_end', self.gf('django.db.models.fields.DateTimeField')(default=None, null=True, db_column='end', blank=True)),
        ))
        db.send_create_signal('peach3', ['Period'])

        # Adding model 'CourseEdition'
        db.create_table('peach3_courseedition', (
            ('id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('default_name', self.gf('django.db.models.fields.CharField')(max_length=100)),
            ('default_language', self.gf('django.db.models.fields.CharField')(default='en', max_length=16)),
            ('code', self.gf('django.db.models.fields.SlugField')(max_length=16, db_index=True)),
            ('course', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['peach3.Course'])),
            ('period', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['peach3.Period'])),
            ('created', self.gf('django.db.models.fields.DateTimeField')()),
            ('cluster_selection', self.gf('django.db.models.fields.CharField')(default='M', max_length=1)),
            ('scoreboard', self.gf('django.db.models.fields.BooleanField')(default=False)),
        ))
        db.send_create_signal('peach3', ['CourseEdition'])

        # Adding unique constraint on 'CourseEdition', fields ['course', 'period']
        db.create_unique('peach3_courseedition', ['course_id', 'period_id'])

        # Adding unique constraint on 'CourseEdition', fields ['code', 'period']
        db.create_unique('peach3_courseedition', ['code', 'period_id'])

        # Adding M2M table for field managers on 'CourseEdition'
        db.create_table('peach3_courseedition_managers', (
            ('id', models.AutoField(verbose_name='ID', primary_key=True, auto_created=True)),
            ('courseedition', models.ForeignKey(orm['peach3.courseedition'], null=False)),
            ('user', models.ForeignKey(orm['auth.user'], null=False))
        ))
        db.create_unique('peach3_courseedition_managers', ['courseedition_id', 'user_id'])

        # Adding model 'FinalGrade'
        db.create_table('peach3_finalgrade', (
            ('id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('courseedition', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['peach3.CourseEdition'])),
            ('user', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['auth.User'])),
            ('grade', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['peach3.Grade'])),
        ))
        db.send_create_signal('peach3', ['FinalGrade'])

        # Adding model 'Cluster'
        db.create_table('peach3_cluster', (
            ('id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('default_name', self.gf('django.db.models.fields.CharField')(max_length=100, blank=True)),
            ('default_language', self.gf('django.db.models.fields.CharField')(default='en', max_length=16)),
            ('courseedition', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['peach3.CourseEdition'])),
            ('joinable', self.gf('django.db.models.fields.NullBooleanField')(default=False, null=True, blank=True)),
            ('joinable_from', self.gf('django.db.models.fields.DateTimeField')(null=True, blank=True)),
            ('joinable_until', self.gf('django.db.models.fields.DateTimeField')(null=True, blank=True)),
            ('active', self.gf('django.db.models.fields.NullBooleanField')(default=False, null=True, blank=True)),
            ('active_from', self.gf('django.db.models.fields.DateTimeField')(null=True, blank=True)),
            ('active_until', self.gf('django.db.models.fields.DateTimeField')(null=True, blank=True)),
            ('admin_cluster', self.gf('django.db.models.fields.BooleanField')(default=False)),
            ('order', self.gf('django.db.models.fields.PositiveIntegerField')(null=True, blank=True)),
        ))
        db.send_create_signal('peach3', ['Cluster'])

        # Adding unique constraint on 'Cluster', fields ['courseedition', 'default_name']
        db.create_unique('peach3_cluster', ['courseedition_id', 'default_name'])

        # Adding M2M table for field realms on 'Cluster'
        db.create_table('peach3_cluster_realms', (
            ('id', models.AutoField(verbose_name='ID', primary_key=True, auto_created=True)),
            ('cluster', models.ForeignKey(orm['peach3.cluster'], null=False)),
            ('realm', models.ForeignKey(orm['peach3.realm'], null=False))
        ))
        db.create_unique('peach3_cluster_realms', ['cluster_id', 'realm_id'])

        # Adding model 'ClusterMember'
        db.create_table('peach3_clustermember', (
            ('id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('cluster', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['peach3.Cluster'])),
            ('realm', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['peach3.Realm'])),
            ('user', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['auth.User'])),
            ('favorite', self.gf('django.db.models.fields.BooleanField')(default=True)),
            ('active', self.gf('django.db.models.fields.BooleanField')(default=True)),
        ))
        db.send_create_signal('peach3', ['ClusterMember'])

        # Adding unique constraint on 'ClusterMember', fields ['cluster', 'user']
        db.create_unique('peach3_clustermember', ['cluster_id', 'user_id'])

        # Adding model 'ClusterStaff'
        db.create_table('peach3_clusterstaff', (
            ('id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('cluster', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['peach3.Cluster'])),
            ('user', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['auth.User'])),
            ('role', self.gf('django.db.models.fields.CharField')(max_length=8)),
            ('level', self.gf('django.db.models.fields.PositiveSmallIntegerField')()),
            ('extend_deadline', self.gf('django.db.models.fields.BooleanField')(default=False)),
        ))
        db.send_create_signal('peach3', ['ClusterStaff'])

        # Adding unique constraint on 'ClusterStaff', fields ['cluster', 'user']
        db.create_unique('peach3_clusterstaff', ['cluster_id', 'user_id'])

        # Adding model 'FileType'
        db.create_table('peach3_filetype', (
            ('id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('default_name', self.gf('django.db.models.fields.CharField')(unique=True, max_length=100)),
            ('default_language', self.gf('django.db.models.fields.CharField')(default='en', max_length=16)),
            ('lexer', self.gf('django.db.models.fields.CharField')(default='', max_length=80, blank=True)),
            ('lexer_parameters', self.gf('django.db.models.fields.TextField')(blank=True)),
            ('binary_content', self.gf('django.db.models.fields.NullBooleanField')(null=True, blank=True)),
            ('base_type', self.gf('django.db.models.fields.BooleanField')(default=False)),
            ('namepatterns', self.gf('django.db.models.fields.TextField')(default='', blank=True)),
            ('mimetypes', self.gf('django.db.models.fields.TextField')(default='', blank=True)),
            ('iconcls', self.gf('django.db.models.fields.CharField')(max_length=30, blank=True)),
        ))
        db.send_create_signal('peach3', ['FileType'])

        # Adding model 'File'
        db.create_table('peach3_file', (
            ('id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
        ))
        db.send_create_signal('peach3', ['File'])

        # Adding model 'FileRevision'
        db.create_table('peach3_filerevision', (
            ('id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('file', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['peach3.File'])),
            ('filepath', self.gf('django.db.models.fields.CharField')(max_length=300)),
            ('filename', self.gf('django.db.models.fields.CharField')(max_length=100)),
            ('filetype', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['peach3.FileType'], null=True, blank=True)),
            ('charset', self.gf('django.db.models.fields.CharField')(max_length=32, blank=True)),
            ('provided_mimetype', self.gf('django.db.models.fields.CharField')(max_length=32, blank=True)),
            ('sha1', self.gf('django.db.models.fields.CharField')(max_length=40)),
            ('created', self.gf('django.db.models.fields.DateTimeField')()),
            ('created_by', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['auth.User'])),
        ))
        db.send_create_signal('peach3', ['FileRevision'])

        # Adding model 'ProgrammingLanguage'
        db.create_table('peach3_proglang', (
            ('id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('default_name', self.gf('django.db.models.fields.CharField')(unique=True, max_length=100)),
            ('default_language', self.gf('django.db.models.fields.CharField')(default='en', max_length=16)),
            ('code', self.gf('django.db.models.fields.CharField')(max_length=16)),
        ))
        db.send_create_signal('peach3', ['ProgrammingLanguage'])

        # Adding model 'AssignmentSet'
        db.create_table('peach3_assignmentset', (
            ('id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('default_name', self.gf('django.db.models.fields.CharField')(max_length=100)),
            ('default_language', self.gf('django.db.models.fields.CharField')(default='en', max_length=16)),
            ('courseedition', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['peach3.CourseEdition'])),
            ('order', self.gf('django.db.models.fields.PositiveIntegerField')(null=True, blank=True)),
        ))
        db.send_create_signal('peach3', ['AssignmentSet'])

        # Adding model 'Assignment'
        db.create_table('peach3_assignment', (
            ('id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('course', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['peach3.Course'])),
        ))
        db.send_create_signal('peach3', ['Assignment'])

        # Adding model 'AssignmentEdition'
        db.create_table('peach3_assignmentedition', (
            ('id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('default_name', self.gf('django.db.models.fields.CharField')(max_length=100)),
            ('default_language', self.gf('django.db.models.fields.CharField')(default='en', max_length=16)),
            ('slug', self.gf('django.db.models.fields.SlugField')(max_length=32, db_index=True)),
            ('assignment', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['peach3.Assignment'])),
            ('assignmentset', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['peach3.AssignmentSet'], null=True, blank=True)),
            ('courseedition', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['peach3.CourseEdition'])),
            ('created', self.gf('django.db.models.fields.DateTimeField')()),
            ('layout', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['peach3.AssignmentLayout'], null=True, blank=True)),
            ('observelevel', self.gf('django.db.models.fields.PositiveSmallIntegerField')(default=1)),
            ('reviewlevel', self.gf('django.db.models.fields.PositiveSmallIntegerField')(default=1)),
            ('reviewpublishlevel', self.gf('django.db.models.fields.PositiveSmallIntegerField')(default=1)),
            ('order', self.gf('django.db.models.fields.PositiveIntegerField')(null=True, blank=True)),
        ))
        db.send_create_signal('peach3', ['AssignmentEdition'])

        # Adding unique constraint on 'AssignmentEdition', fields ['courseedition', 'slug']
        db.create_unique('peach3_assignmentedition', ['courseedition_id', 'slug'])

        # Adding M2M table for field gradingsystems on 'AssignmentEdition'
        db.create_table('peach3_assignmentedition_gradingsystems', (
            ('id', models.AutoField(verbose_name='ID', primary_key=True, auto_created=True)),
            ('assignmentedition', models.ForeignKey(orm['peach3.assignmentedition'], null=False)),
            ('gradingsystem', models.ForeignKey(orm['peach3.gradingsystem'], null=False))
        ))
        db.create_unique('peach3_assignmentedition_gradingsystems', ['assignmentedition_id', 'gradingsystem_id'])

        # Adding M2M table for field languages on 'AssignmentEdition'
        db.create_table('peach3_assignmentedition_languages', (
            ('id', models.AutoField(verbose_name='ID', primary_key=True, auto_created=True)),
            ('assignmentedition', models.ForeignKey(orm['peach3.assignmentedition'], null=False)),
            ('programminglanguage', models.ForeignKey(orm['peach3.programminglanguage'], null=False))
        ))
        db.create_unique('peach3_assignmentedition_languages', ['assignmentedition_id', 'programminglanguage_id'])

        # Adding model 'AssignmentEditionOption'
        db.create_table('peach3_asgnedoption', (
            ('id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('assignmentedition', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['peach3.AssignmentEdition'])),
            ('option', self.gf('django.db.models.fields.CharField')(max_length=16)),
            ('parameters', self.gf('django.db.models.fields.TextField')(blank=True)),
        ))
        db.send_create_signal('peach3', ['AssignmentEditionOption'])

        # Adding unique constraint on 'AssignmentEditionOption', fields ['assignmentedition', 'option']
        db.create_unique('peach3_asgnedoption', ['assignmentedition_id', 'option'])

        # Adding model 'AssignmentLayout'
        db.create_table('peach3_assignmentlayout', (
            ('id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('name', self.gf('django.db.models.fields.CharField')(unique=True, max_length=80)),
        ))
        db.send_create_signal('peach3', ['AssignmentLayout'])

        # Adding model 'AssignmentSlot'
        db.create_table('peach3_assignmentslot', (
            ('id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('default_name', self.gf('django.db.models.fields.CharField')(max_length=100)),
            ('default_language', self.gf('django.db.models.fields.CharField')(default='en', max_length=16)),
            ('assignmentsubmlayout', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['peach3.AssignmentLayout'])),
            ('order', self.gf('django.db.models.fields.PositiveIntegerField')()),
            ('namePattern', self.gf('django.db.models.fields.CharField')(max_length=200, blank=True)),
            ('required', self.gf('django.db.models.fields.BooleanField')(default=False)),
        ))
        db.send_create_signal('peach3', ['AssignmentSlot'])

        # Adding M2M table for field allowedTypes on 'AssignmentSlot'
        db.create_table('peach3_assignmentslot_allowedTypes', (
            ('id', models.AutoField(verbose_name='ID', primary_key=True, auto_created=True)),
            ('assignmentslot', models.ForeignKey(orm['peach3.assignmentslot'], null=False)),
            ('filetype', models.ForeignKey(orm['peach3.filetype'], null=False))
        ))
        db.create_unique('peach3_assignmentslot_allowedTypes', ['assignmentslot_id', 'filetype_id'])

        # Adding model 'ClusterTimeRange'
        db.create_table('peach3_clustertimerange', (
            ('id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('assignmentedition', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['peach3.AssignmentEdition'])),
            ('type', self.gf('django.db.models.fields.CharField')(max_length=1)),
            ('state_from', self.gf('django.db.models.fields.DateTimeField')(null=True, blank=True)),
            ('state_until', self.gf('django.db.models.fields.DateTimeField')(null=True, blank=True)),
            ('cluster', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['peach3.Cluster'])),
        ))
        db.send_create_signal('peach3', ['ClusterTimeRange'])

        # Adding unique constraint on 'ClusterTimeRange', fields ['cluster', 'assignmentedition', 'type']
        db.create_unique('peach3_clustertimerange', ['cluster_id', 'assignmentedition_id', 'type'])

        # Adding model 'IndividualTimeRange'
        db.create_table('peach3_individualtimerange', (
            ('id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('assignmentedition', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['peach3.AssignmentEdition'])),
            ('type', self.gf('django.db.models.fields.CharField')(max_length=1)),
            ('state_from', self.gf('django.db.models.fields.DateTimeField')(null=True, blank=True)),
            ('state_until', self.gf('django.db.models.fields.DateTimeField')(null=True, blank=True)),
            ('user', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['auth.User'])),
        ))
        db.send_create_signal('peach3', ['IndividualTimeRange'])

        # Adding unique constraint on 'IndividualTimeRange', fields ['user', 'assignmentedition', 'type']
        db.create_unique('peach3_individualtimerange', ['user_id', 'assignmentedition_id', 'type'])

        # Adding model 'Comment'
        db.create_table('peach3_comment', (
            ('id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('parent_content_type', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['contenttypes.ContentType'])),
            ('parent_id', self.gf('django.db.models.fields.PositiveIntegerField')()),
            ('author', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['auth.User'])),
            ('created', self.gf('django.db.models.fields.DateTimeField')()),
            ('response_to', self.gf('django.db.models.fields.related.ForeignKey')(blank=True, related_name='response_set', null=True, to=orm['peach3.Comment'])),
        ))
        db.send_create_signal('peach3', ['Comment'])

        # Adding model 'CommentRevision'
        db.create_table('peach3_commentrevision', (
            ('id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('comment', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['peach3.Comment'])),
            ('author', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['auth.User'])),
            ('created', self.gf('django.db.models.fields.DateTimeField')()),
            ('header', self.gf('django.db.models.fields.CharField')(max_length=255, blank=True)),
            ('markup', self.gf('django.db.models.fields.CharField')(default='plain', max_length=8)),
            ('message', self.gf('django.db.models.fields.TextField')(blank=True)),
        ))
        db.send_create_signal('peach3', ['CommentRevision'])

        # Adding model 'NewsItem'
        db.create_table('peach3_newsitem', (
            ('id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('courseedition', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['peach3.CourseEdition'], null=True, blank=True)),
            ('cluster', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['peach3.Cluster'], null=True, blank=True)),
            ('receipient', self.gf('django.db.models.fields.related.ForeignKey')(blank=True, related_name='newsitem_receipient', null=True, to=orm['auth.User'])),
            ('related_content_type', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['contenttypes.ContentType'], null=True, blank=True)),
            ('related_id', self.gf('django.db.models.fields.PositiveIntegerField')(null=True, blank=True)),
            ('created', self.gf('django.db.models.fields.DateTimeField')()),
            ('created_by', self.gf('django.db.models.fields.related.ForeignKey')(related_name='newsitem_creator', to=orm['auth.User'])),
            ('appears', self.gf('django.db.models.fields.DateTimeField')()),
            ('expires', self.gf('django.db.models.fields.DateTimeField')()),
            ('current', self.gf('django.db.models.fields.BooleanField')(default=True)),
            ('msgtype', self.gf('django.db.models.fields.SlugField')(db_index=True, max_length=50, blank=True)),
            ('msgparam', self.gf('django.db.models.fields.TextField')(blank=True)),
            ('text', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['peach3.NewsBody'], null=True, blank=True)),
        ))
        db.send_create_signal('peach3', ['NewsItem'])

        # Adding M2M table for field read on 'NewsItem'
        db.create_table('peach3_newsitem_read', (
            ('id', models.AutoField(verbose_name='ID', primary_key=True, auto_created=True)),
            ('newsitem', models.ForeignKey(orm['peach3.newsitem'], null=False)),
            ('user', models.ForeignKey(orm['auth.user'], null=False))
        ))
        db.create_unique('peach3_newsitem_read', ['newsitem_id', 'user_id'])

        # Adding model 'NewsBody'
        db.create_table('peach3_newsbody', (
            ('id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('subject', self.gf('django.db.models.fields.CharField')(max_length=80)),
            ('message', self.gf('django.db.models.fields.TextField')()),
            ('markup', self.gf('django.db.models.fields.SlugField')(default='plain', max_length=8, db_index=True)),
        ))
        db.send_create_signal('peach3', ['NewsBody'])

        # Adding model 'RefPDFInfo'
        db.create_table('peach3_refpdfinfo', (
            ('pdfinfo_ptr', self.gf('django.db.models.fields.related.OneToOneField')(to=orm['pdfviewer.PDFInfo'], unique=True, primary_key=True)),
            ('ref_ct', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['contenttypes.ContentType'], null=True, blank=True)),
            ('ref_id', self.gf('django.db.models.fields.PositiveIntegerField')(null=True, blank=True)),
        ))
        db.send_create_signal('peach3', ['RefPDFInfo'])

        # Adding model 'Report'
        db.create_table('peach3_report', (
            ('id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('type', self.gf('django.db.models.fields.CharField')(max_length=12)),
            ('parameters', self.gf('django.db.models.fields.TextField')()),
            ('filename', self.gf('django.db.models.fields.CharField')(max_length=256)),
            ('mimetype', self.gf('django.db.models.fields.CharField')(max_length=50)),
            ('created', self.gf('django.db.models.fields.DateTimeField')()),
            ('last_access', self.gf('django.db.models.fields.DateTimeField')(null=True, blank=True)),
        ))
        db.send_create_signal('peach3', ['Report'])

        # Adding M2M table for field users on 'Report'
        db.create_table('peach3_report_users', (
            ('id', models.AutoField(verbose_name='ID', primary_key=True, auto_created=True)),
            ('report', models.ForeignKey(orm['peach3.report'], null=False)),
            ('user', models.ForeignKey(orm['auth.user'], null=False))
        ))
        db.create_unique('peach3_report_users', ['report_id', 'user_id'])

        # Adding model 'Submission'
        db.create_table('peach3_submission', (
            ('id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('assignmentedition', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['peach3.AssignmentEdition'])),
            ('courseedition', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['peach3.CourseEdition'])),
            ('created', self.gf('django.db.models.fields.DateTimeField')(db_index=True)),
            ('created_by', self.gf('django.db.models.fields.related.ForeignKey')(related_name='submission_created_set', to=orm['auth.User'])),
            ('submitted', self.gf('django.db.models.fields.DateTimeField')(null=True, blank=True)),
            ('submitted_by', self.gf('django.db.models.fields.related.ForeignKey')(blank=True, related_name='submission_submitted_set', null=True, to=orm['auth.User'])),
            ('modified', self.gf('django.db.models.fields.DateTimeField')(db_index=True, null=True, blank=True)),
            ('language', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['peach3.ProgrammingLanguage'], null=True, blank=True)),
        ))
        db.send_create_signal('peach3', ['Submission'])

        # Adding M2M table for field authors on 'Submission'
        db.create_table('peach3_submission_authors', (
            ('id', models.AutoField(verbose_name='ID', primary_key=True, auto_created=True)),
            ('submission', models.ForeignKey(orm['peach3.submission'], null=False)),
            ('user', models.ForeignKey(orm['auth.user'], null=False))
        ))
        db.create_unique('peach3_submission_authors', ['submission_id', 'user_id'])

        # Adding model 'SubmissionFile'
        db.create_table('peach3_submissionfile', (
            ('id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('submission', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['peach3.Submission'])),
            ('file', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['peach3.FileRevision'])),
            ('slot', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['peach3.AssignmentSlot'], null=True, blank=True)),
        ))
        db.send_create_signal('peach3', ['SubmissionFile'])

        # Adding model 'CheckResult'
        db.create_table('peach3_checkresult', (
            ('id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('submission', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['peach3.Submission'])),
            ('created', self.gf('django.db.models.fields.DateTimeField')()),
            ('checked', self.gf('django.db.models.fields.DateTimeField')(null=True, blank=True)),
            ('checked_level', self.gf('django.db.models.fields.PositiveSmallIntegerField')(null=True, blank=True)),
            ('state', self.gf('django.db.models.fields.CharField')(max_length=8, blank=True)),
            ('grade', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['peach3.Grade'], null=True, blank=True)),
            ('report', self.gf('django.db.models.fields.TextField')(blank=True)),
            ('score_0', self.gf('django.db.models.fields.IntegerField')(null=True, blank=True)),
            ('score_1', self.gf('django.db.models.fields.IntegerField')(null=True, blank=True)),
            ('score_2', self.gf('django.db.models.fields.IntegerField')(null=True, blank=True)),
            ('score_3', self.gf('django.db.models.fields.IntegerField')(null=True, blank=True)),
            ('score_4', self.gf('django.db.models.fields.IntegerField')(null=True, blank=True)),
            ('score_5', self.gf('django.db.models.fields.IntegerField')(null=True, blank=True)),
            ('score_6', self.gf('django.db.models.fields.IntegerField')(null=True, blank=True)),
            ('score_7', self.gf('django.db.models.fields.IntegerField')(null=True, blank=True)),
            ('score_8', self.gf('django.db.models.fields.IntegerField')(null=True, blank=True)),
            ('score_9', self.gf('django.db.models.fields.IntegerField')(null=True, blank=True)),
            ('score_10', self.gf('django.db.models.fields.IntegerField')(null=True, blank=True)),
        ))
        db.send_create_signal('peach3', ['CheckResult'])

        # Adding model 'Reason'
        db.create_table('peach3_reason', (
            ('id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('code', self.gf('django.db.models.fields.CharField')(max_length=16, db_index=True)),
            ('param1', self.gf('django.db.models.fields.CharField')(max_length=16, blank=True)),
            ('param2', self.gf('django.db.models.fields.CharField')(max_length=16, blank=True)),
            ('default_description', self.gf('django.db.models.fields.TextField')()),
            ('default_language', self.gf('django.db.models.fields.CharField')(default='en', max_length=16)),
        ))
        db.send_create_signal('peach3', ['Reason'])

        # Adding model 'ReasonAltDescription'
        db.create_table('peach3_reasonaltdescription', (
            ('id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('reason', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['peach3.Reason'])),
            ('language', self.gf('django.db.models.fields.CharField')(max_length=16)),
            ('description', self.gf('django.db.models.fields.CharField')(max_length=80)),
        ))
        db.send_create_signal('peach3', ['ReasonAltDescription'])

        # Adding unique constraint on 'ReasonAltDescription', fields ['reason', 'language']
        db.create_unique('peach3_reasonaltdescription', ['reason_id', 'language'])

        # Adding model 'CheckResultStep'
        db.create_table('peach3_checkresultstep', (
            ('id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('checkresult', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['peach3.CheckResult'])),
            ('stage', self.gf('django.db.models.fields.CharField')(max_length=16, blank=True)),
            ('step', self.gf('django.db.models.fields.PositiveSmallIntegerField')()),
            ('level', self.gf('django.db.models.fields.PositiveSmallIntegerField')()),
            ('passed', self.gf('django.db.models.fields.BooleanField')(default=False)),
            ('reason', self.gf('django.db.models.fields.CharField')(max_length=32, blank=True)),
            ('report', self.gf('django.db.models.fields.TextField')(blank=True)),
            ('report_format', self.gf('django.db.models.fields.CharField')(max_length=1)),
            ('score', self.gf('django.db.models.fields.IntegerField')(null=True, blank=True)),
            ('runtime', self.gf('django.db.models.fields.PositiveIntegerField')(null=True, blank=True)),
        ))
        db.send_create_signal('peach3', ['CheckResultStep'])

        # Adding M2M table for field generatedfiles on 'CheckResultStep'
        db.create_table('peach3_checkresultstep_generatedfiles', (
            ('id', models.AutoField(verbose_name='ID', primary_key=True, auto_created=True)),
            ('checkresultstep', models.ForeignKey(orm['peach3.checkresultstep'], null=False)),
            ('filerevision', models.ForeignKey(orm['peach3.filerevision'], null=False))
        ))
        db.create_unique('peach3_checkresultstep_generatedfiles', ['checkresultstep_id', 'filerevision_id'])

        # Adding model 'CheckResultStepIO'
        db.create_table('peach3_checkresultstepio', (
            ('id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('checkresultstep', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['peach3.CheckResultStep'])),
            ('stream', self.gf('django.db.models.fields.CharField')(max_length=1)),
            ('timestamp', self.gf('django.db.models.fields.PositiveIntegerField')()),
            ('order', self.gf('django.db.models.fields.PositiveIntegerField')()),
            ('data', self.gf('django.db.models.fields.TextField')()),
        ))
        db.send_create_signal('peach3', ['CheckResultStepIO'])

        # Adding model 'Review'
        db.create_table('peach3_review', (
            ('id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('submission', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['peach3.Submission'])),
            ('created', self.gf('django.db.models.fields.DateTimeField')()),
            ('created_by', self.gf('django.db.models.fields.related.ForeignKey')(related_name='review_creator', to=orm['auth.User'])),
            ('reviewlevel', self.gf('django.db.models.fields.PositiveSmallIntegerField')()),
            ('visibilitylevel', self.gf('django.db.models.fields.PositiveSmallIntegerField')()),
            ('grade', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['peach3.Grade'], null=True, blank=True)),
        ))
        db.send_create_signal('peach3', ['Review'])

        # Adding M2M table for field authors on 'Review'
        db.create_table('peach3_review_authors', (
            ('id', models.AutoField(verbose_name='ID', primary_key=True, auto_created=True)),
            ('review', models.ForeignKey(orm['peach3.review'], null=False)),
            ('user', models.ForeignKey(orm['auth.user'], null=False))
        ))
        db.create_unique('peach3_review_authors', ['review_id', 'user_id'])

        # Adding model 'Page'
        db.create_table('peach3_page', (
            ('id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('parent_type', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['contenttypes.ContentType'], null=True, blank=True)),
            ('parent_id', self.gf('django.db.models.fields.PositiveIntegerField')(null=True, blank=True)),
            ('path', self.gf('django.db.models.fields.CharField')(max_length=200, blank=True)),
            ('created', self.gf('django.db.models.fields.DateTimeField')()),
            ('created_by', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['auth.User'])),
            ('allow_comments', self.gf('django.db.models.fields.BooleanField')(default=False)),
            ('access', self.gf('django.db.models.fields.PositiveSmallIntegerField')(default=2)),
            ('parent_access', self.gf('django.db.models.fields.CharField')(max_length=16, blank=True)),
            ('default_language', self.gf('django.db.models.fields.CharField')(default='en', max_length=16)),
        ))
        db.send_create_signal('peach3', ['Page'])

        # Adding unique constraint on 'Page', fields ['parent_type', 'parent_id', 'path']
        db.create_unique('peach3_page', ['parent_type_id', 'parent_id', 'path'])

        # Adding model 'PagePermission'
        db.create_table('peach3_pagepermission', (
            ('id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('page', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['peach3.Page'])),
            ('user', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['auth.User'])),
            ('permission', self.gf('django.db.models.fields.PositiveSmallIntegerField')()),
        ))
        db.send_create_signal('peach3', ['PagePermission'])

        # Adding model 'PageRevisionText'
        db.create_table('peach3_pagerevisiontext', (
            ('id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('markup', self.gf('django.db.models.fields.CharField')(default='rst', max_length=8)),
            ('diff_base', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['peach3.PageRevisionText'], null=True, blank=True)),
            ('content_or_diff', self.gf('django.db.models.fields.TextField')()),
        ))
        db.send_create_signal('peach3', ['PageRevisionText'])

        # Adding model 'PageRevision'
        db.create_table('peach3_pagerevision', (
            ('id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('page', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['peach3.Page'])),
            ('created', self.gf('django.db.models.fields.DateTimeField')()),
            ('created_by', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['auth.User'])),
            ('changes', self.gf('django.db.models.fields.TextField')(blank=True)),
            ('language', self.gf('django.db.models.fields.CharField')(default='en', max_length=16)),
            ('text', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['peach3.PageRevisionText'])),
        ))
        db.send_create_signal('peach3', ['PageRevision'])

        # Adding model 'Profile'
        db.create_table('peach3_profile', (
            ('id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('user', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['auth.User'])),
            ('initials', self.gf('django.db.models.fields.CharField')(max_length=30, blank=True)),
            ('titles_prefix', self.gf('django.db.models.fields.CharField')(max_length=30, blank=True)),
            ('last_name_prefix', self.gf('django.db.models.fields.CharField')(max_length=30, blank=True)),
            ('last_name_suffix', self.gf('django.db.models.fields.CharField')(max_length=30, blank=True)),
            ('titles_suffix', self.gf('django.db.models.fields.CharField')(max_length=30, blank=True)),
            ('timezone_str', self.gf('django.db.models.fields.CharField')(default='Europe/Amsterdam', max_length=48)),
            ('date_format', self.gf('django.db.models.fields.CharField')(default='D j M Y', max_length=16)),
            ('time_format', self.gf('django.db.models.fields.CharField')(default='G:i', max_length=8)),
            ('language', self.gf('django.db.models.fields.CharField')(default='', max_length=16, blank=True)),
            ('programmingLanguage', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['peach3.ProgrammingLanguage'], null=True, blank=True)),
            ('state', self.gf('django.db.models.fields.CharField')(default='U', max_length=1)),
        ))
        db.send_create_signal('peach3', ['Profile'])

        # Adding model 'VerificationCode'
        db.create_table('peach3_verificationcode', (
            ('id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('user', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['auth.User'])),
            ('type', self.gf('django.db.models.fields.CharField')(max_length=1)),
            ('code', self.gf('django.db.models.fields.CharField')(max_length=8)),
            ('created', self.gf('django.db.models.fields.DateTimeField')()),
            ('expires', self.gf('django.db.models.fields.DateTimeField')(null=True, blank=True)),
            ('parameters', self.gf('django.db.models.fields.TextField')(blank=True)),
        ))
        db.send_create_signal('peach3', ['VerificationCode'])


    def backwards(self, orm):
        
        # Removing unique constraint on 'Page', fields ['parent_type', 'parent_id', 'path']
        db.delete_unique('peach3_page', ['parent_type_id', 'parent_id', 'path'])

        # Removing unique constraint on 'ReasonAltDescription', fields ['reason', 'language']
        db.delete_unique('peach3_reasonaltdescription', ['reason_id', 'language'])

        # Removing unique constraint on 'IndividualTimeRange', fields ['user', 'assignmentedition', 'type']
        db.delete_unique('peach3_individualtimerange', ['user_id', 'assignmentedition_id', 'type'])

        # Removing unique constraint on 'ClusterTimeRange', fields ['cluster', 'assignmentedition', 'type']
        db.delete_unique('peach3_clustertimerange', ['cluster_id', 'assignmentedition_id', 'type'])

        # Removing unique constraint on 'AssignmentEditionOption', fields ['assignmentedition', 'option']
        db.delete_unique('peach3_asgnedoption', ['assignmentedition_id', 'option'])

        # Removing unique constraint on 'AssignmentEdition', fields ['courseedition', 'slug']
        db.delete_unique('peach3_assignmentedition', ['courseedition_id', 'slug'])

        # Removing unique constraint on 'ClusterStaff', fields ['cluster', 'user']
        db.delete_unique('peach3_clusterstaff', ['cluster_id', 'user_id'])

        # Removing unique constraint on 'ClusterMember', fields ['cluster', 'user']
        db.delete_unique('peach3_clustermember', ['cluster_id', 'user_id'])

        # Removing unique constraint on 'Cluster', fields ['courseedition', 'default_name']
        db.delete_unique('peach3_cluster', ['courseedition_id', 'default_name'])

        # Removing unique constraint on 'CourseEdition', fields ['code', 'period']
        db.delete_unique('peach3_courseedition', ['code', 'period_id'])

        # Removing unique constraint on 'CourseEdition', fields ['course', 'period']
        db.delete_unique('peach3_courseedition', ['course_id', 'period_id'])

        # Removing unique constraint on 'Grade', fields ['system', 'default_name']
        db.delete_unique('peach3_grade', ['system_id', 'default_name'])

        # Removing unique constraint on 'TranslatedName', fields ['content_type', 'object_id', 'language']
        db.delete_unique('peach3_translatedname', ['content_type_id', 'object_id', 'language'])

        # Deleting model 'TranslatedName'
        db.delete_table('peach3_translatedname')

        # Deleting model 'GradingSystem'
        db.delete_table('peach3_gradingsystem')

        # Deleting model 'Grade'
        db.delete_table('peach3_grade')

        # Deleting model 'Realm'
        db.delete_table('peach3_realm')

        # Deleting model 'Course'
        db.delete_table('peach3_course')

        # Deleting model 'Period'
        db.delete_table('peach3_period')

        # Deleting model 'CourseEdition'
        db.delete_table('peach3_courseedition')

        # Removing M2M table for field managers on 'CourseEdition'
        db.delete_table('peach3_courseedition_managers')

        # Deleting model 'FinalGrade'
        db.delete_table('peach3_finalgrade')

        # Deleting model 'Cluster'
        db.delete_table('peach3_cluster')

        # Removing M2M table for field realms on 'Cluster'
        db.delete_table('peach3_cluster_realms')

        # Deleting model 'ClusterMember'
        db.delete_table('peach3_clustermember')

        # Deleting model 'ClusterStaff'
        db.delete_table('peach3_clusterstaff')

        # Deleting model 'FileType'
        db.delete_table('peach3_filetype')

        # Deleting model 'File'
        db.delete_table('peach3_file')

        # Deleting model 'FileRevision'
        db.delete_table('peach3_filerevision')

        # Deleting model 'ProgrammingLanguage'
        db.delete_table('peach3_proglang')

        # Deleting model 'AssignmentSet'
        db.delete_table('peach3_assignmentset')

        # Deleting model 'Assignment'
        db.delete_table('peach3_assignment')

        # Deleting model 'AssignmentEdition'
        db.delete_table('peach3_assignmentedition')

        # Removing M2M table for field gradingsystems on 'AssignmentEdition'
        db.delete_table('peach3_assignmentedition_gradingsystems')

        # Removing M2M table for field languages on 'AssignmentEdition'
        db.delete_table('peach3_assignmentedition_languages')

        # Deleting model 'AssignmentEditionOption'
        db.delete_table('peach3_asgnedoption')

        # Deleting model 'AssignmentLayout'
        db.delete_table('peach3_assignmentlayout')

        # Deleting model 'AssignmentSlot'
        db.delete_table('peach3_assignmentslot')

        # Removing M2M table for field allowedTypes on 'AssignmentSlot'
        db.delete_table('peach3_assignmentslot_allowedTypes')

        # Deleting model 'ClusterTimeRange'
        db.delete_table('peach3_clustertimerange')

        # Deleting model 'IndividualTimeRange'
        db.delete_table('peach3_individualtimerange')

        # Deleting model 'Comment'
        db.delete_table('peach3_comment')

        # Deleting model 'CommentRevision'
        db.delete_table('peach3_commentrevision')

        # Deleting model 'NewsItem'
        db.delete_table('peach3_newsitem')

        # Removing M2M table for field read on 'NewsItem'
        db.delete_table('peach3_newsitem_read')

        # Deleting model 'NewsBody'
        db.delete_table('peach3_newsbody')

        # Deleting model 'RefPDFInfo'
        db.delete_table('peach3_refpdfinfo')

        # Deleting model 'Report'
        db.delete_table('peach3_report')

        # Removing M2M table for field users on 'Report'
        db.delete_table('peach3_report_users')

        # Deleting model 'Submission'
        db.delete_table('peach3_submission')

        # Removing M2M table for field authors on 'Submission'
        db.delete_table('peach3_submission_authors')

        # Deleting model 'SubmissionFile'
        db.delete_table('peach3_submissionfile')

        # Deleting model 'CheckResult'
        db.delete_table('peach3_checkresult')

        # Deleting model 'Reason'
        db.delete_table('peach3_reason')

        # Deleting model 'ReasonAltDescription'
        db.delete_table('peach3_reasonaltdescription')

        # Deleting model 'CheckResultStep'
        db.delete_table('peach3_checkresultstep')

        # Removing M2M table for field generatedfiles on 'CheckResultStep'
        db.delete_table('peach3_checkresultstep_generatedfiles')

        # Deleting model 'CheckResultStepIO'
        db.delete_table('peach3_checkresultstepio')

        # Deleting model 'Review'
        db.delete_table('peach3_review')

        # Removing M2M table for field authors on 'Review'
        db.delete_table('peach3_review_authors')

        # Deleting model 'Page'
        db.delete_table('peach3_page')

        # Deleting model 'PagePermission'
        db.delete_table('peach3_pagepermission')

        # Deleting model 'PageRevisionText'
        db.delete_table('peach3_pagerevisiontext')

        # Deleting model 'PageRevision'
        db.delete_table('peach3_pagerevision')

        # Deleting model 'Profile'
        db.delete_table('peach3_profile')

        # Deleting model 'VerificationCode'
        db.delete_table('peach3_verificationcode')


    models = {
        'auth.group': {
            'Meta': {'object_name': 'Group'},
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'name': ('django.db.models.fields.CharField', [], {'unique': 'True', 'max_length': '80'}),
            'permissions': ('django.db.models.fields.related.ManyToManyField', [], {'to': "orm['auth.Permission']", 'symmetrical': 'False', 'blank': 'True'})
        },
        'auth.permission': {
            'Meta': {'ordering': "('content_type__app_label', 'content_type__model', 'codename')", 'unique_together': "(('content_type', 'codename'),)", 'object_name': 'Permission'},
            'codename': ('django.db.models.fields.CharField', [], {'max_length': '100'}),
            'content_type': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['contenttypes.ContentType']"}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '50'})
        },
        'auth.user': {
            'Meta': {'object_name': 'User'},
            'date_joined': ('django.db.models.fields.DateTimeField', [], {'default': 'datetime.datetime(2012, 1, 13, 17, 7, 29, 405706)'}),
            'email': ('django.db.models.fields.EmailField', [], {'max_length': '75', 'blank': 'True'}),
            'first_name': ('django.db.models.fields.CharField', [], {'max_length': '30', 'blank': 'True'}),
            'groups': ('django.db.models.fields.related.ManyToManyField', [], {'to': "orm['auth.Group']", 'symmetrical': 'False', 'blank': 'True'}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'is_active': ('django.db.models.fields.BooleanField', [], {'default': 'True'}),
            'is_staff': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'is_superuser': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'last_login': ('django.db.models.fields.DateTimeField', [], {'default': 'datetime.datetime(2012, 1, 13, 17, 7, 29, 405442)'}),
            'last_name': ('django.db.models.fields.CharField', [], {'max_length': '30', 'blank': 'True'}),
            'password': ('django.db.models.fields.CharField', [], {'max_length': '128'}),
            'user_permissions': ('django.db.models.fields.related.ManyToManyField', [], {'to': "orm['auth.Permission']", 'symmetrical': 'False', 'blank': 'True'}),
            'username': ('django.db.models.fields.CharField', [], {'unique': 'True', 'max_length': '30'})
        },
        'contenttypes.contenttype': {
            'Meta': {'ordering': "('name',)", 'unique_together': "(('app_label', 'model'),)", 'object_name': 'ContentType', 'db_table': "'django_content_type'"},
            'app_label': ('django.db.models.fields.CharField', [], {'max_length': '100'}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'model': ('django.db.models.fields.CharField', [], {'max_length': '100'}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '100'})
        },
        'pdfviewer.pdfinfo': {
            'Meta': {'object_name': 'PDFInfo'},
            'hash': ('django.db.models.fields.CharField', [], {'max_length': '32', 'db_index': 'True'}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'last_access': ('django.db.models.fields.DateTimeField', [], {'auto_now': 'True', 'blank': 'True'}),
            'path': ('django.db.models.fields.CharField', [], {'max_length': '250', 'db_index': 'True'}),
            'title': ('django.db.models.fields.CharField', [], {'max_length': '250'})
        },
        'peach3.assignment': {
            'Meta': {'object_name': 'Assignment'},
            'course': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['peach3.Course']"}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'})
        },
        'peach3.assignmentedition': {
            'Meta': {'ordering': "('order',)", 'unique_together': "(('courseedition', 'slug'),)", 'object_name': 'AssignmentEdition'},
            'assignment': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['peach3.Assignment']"}),
            'assignmentset': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['peach3.AssignmentSet']", 'null': 'True', 'blank': 'True'}),
            'courseedition': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['peach3.CourseEdition']"}),
            'created': ('django.db.models.fields.DateTimeField', [], {}),
            'default_language': ('django.db.models.fields.CharField', [], {'default': "'en'", 'max_length': '16'}),
            'default_name': ('django.db.models.fields.CharField', [], {'max_length': '100'}),
            'gradingsystems': ('django.db.models.fields.related.ManyToManyField', [], {'to': "orm['peach3.GradingSystem']", 'symmetrical': 'False', 'blank': 'True'}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'individual_timeranges': ('django.db.models.fields.related.ManyToManyField', [], {'to': "orm['auth.User']", 'through': "orm['peach3.IndividualTimeRange']", 'symmetrical': 'False'}),
            'languages': ('django.db.models.fields.related.ManyToManyField', [], {'to': "orm['peach3.ProgrammingLanguage']", 'symmetrical': 'False', 'blank': 'True'}),
            'layout': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['peach3.AssignmentLayout']", 'null': 'True', 'blank': 'True'}),
            'observelevel': ('django.db.models.fields.PositiveSmallIntegerField', [], {'default': '1'}),
            'order': ('django.db.models.fields.PositiveIntegerField', [], {'null': 'True', 'blank': 'True'}),
            'reviewlevel': ('django.db.models.fields.PositiveSmallIntegerField', [], {'default': '1'}),
            'reviewpublishlevel': ('django.db.models.fields.PositiveSmallIntegerField', [], {'default': '1'}),
            'slug': ('django.db.models.fields.SlugField', [], {'max_length': '32', 'db_index': 'True'}),
            'timeranges': ('django.db.models.fields.related.ManyToManyField', [], {'to': "orm['peach3.Cluster']", 'through': "orm['peach3.ClusterTimeRange']", 'symmetrical': 'False'})
        },
        'peach3.assignmenteditionoption': {
            'Meta': {'unique_together': "(('assignmentedition', 'option'),)", 'object_name': 'AssignmentEditionOption', 'db_table': "'peach3_asgnedoption'"},
            'assignmentedition': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['peach3.AssignmentEdition']"}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'option': ('django.db.models.fields.CharField', [], {'max_length': '16'}),
            'parameters': ('django.db.models.fields.TextField', [], {'blank': 'True'})
        },
        'peach3.assignmentlayout': {
            'Meta': {'object_name': 'AssignmentLayout'},
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'name': ('django.db.models.fields.CharField', [], {'unique': 'True', 'max_length': '80'})
        },
        'peach3.assignmentset': {
            'Meta': {'ordering': "('order',)", 'object_name': 'AssignmentSet'},
            'courseedition': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['peach3.CourseEdition']"}),
            'default_language': ('django.db.models.fields.CharField', [], {'default': "'en'", 'max_length': '16'}),
            'default_name': ('django.db.models.fields.CharField', [], {'max_length': '100'}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'order': ('django.db.models.fields.PositiveIntegerField', [], {'null': 'True', 'blank': 'True'})
        },
        'peach3.assignmentslot': {
            'Meta': {'object_name': 'AssignmentSlot'},
            'allowedTypes': ('django.db.models.fields.related.ManyToManyField', [], {'to': "orm['peach3.FileType']", 'symmetrical': 'False', 'blank': 'True'}),
            'assignmentsubmlayout': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['peach3.AssignmentLayout']"}),
            'default_language': ('django.db.models.fields.CharField', [], {'default': "'en'", 'max_length': '16'}),
            'default_name': ('django.db.models.fields.CharField', [], {'max_length': '100'}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'namePattern': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'order': ('django.db.models.fields.PositiveIntegerField', [], {}),
            'required': ('django.db.models.fields.BooleanField', [], {'default': 'False'})
        },
        'peach3.checkresult': {
            'Meta': {'object_name': 'CheckResult'},
            'checked': ('django.db.models.fields.DateTimeField', [], {'null': 'True', 'blank': 'True'}),
            'checked_level': ('django.db.models.fields.PositiveSmallIntegerField', [], {'null': 'True', 'blank': 'True'}),
            'created': ('django.db.models.fields.DateTimeField', [], {}),
            'grade': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['peach3.Grade']", 'null': 'True', 'blank': 'True'}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'report': ('django.db.models.fields.TextField', [], {'blank': 'True'}),
            'score_0': ('django.db.models.fields.IntegerField', [], {'null': 'True', 'blank': 'True'}),
            'score_1': ('django.db.models.fields.IntegerField', [], {'null': 'True', 'blank': 'True'}),
            'score_10': ('django.db.models.fields.IntegerField', [], {'null': 'True', 'blank': 'True'}),
            'score_2': ('django.db.models.fields.IntegerField', [], {'null': 'True', 'blank': 'True'}),
            'score_3': ('django.db.models.fields.IntegerField', [], {'null': 'True', 'blank': 'True'}),
            'score_4': ('django.db.models.fields.IntegerField', [], {'null': 'True', 'blank': 'True'}),
            'score_5': ('django.db.models.fields.IntegerField', [], {'null': 'True', 'blank': 'True'}),
            'score_6': ('django.db.models.fields.IntegerField', [], {'null': 'True', 'blank': 'True'}),
            'score_7': ('django.db.models.fields.IntegerField', [], {'null': 'True', 'blank': 'True'}),
            'score_8': ('django.db.models.fields.IntegerField', [], {'null': 'True', 'blank': 'True'}),
            'score_9': ('django.db.models.fields.IntegerField', [], {'null': 'True', 'blank': 'True'}),
            'state': ('django.db.models.fields.CharField', [], {'max_length': '8', 'blank': 'True'}),
            'submission': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['peach3.Submission']"})
        },
        'peach3.checkresultstep': {
            'Meta': {'object_name': 'CheckResultStep'},
            'checkresult': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['peach3.CheckResult']"}),
            'generatedfiles': ('django.db.models.fields.related.ManyToManyField', [], {'symmetrical': 'False', 'to': "orm['peach3.FileRevision']", 'null': 'True', 'blank': 'True'}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'level': ('django.db.models.fields.PositiveSmallIntegerField', [], {}),
            'passed': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'reason': ('django.db.models.fields.CharField', [], {'max_length': '32', 'blank': 'True'}),
            'report': ('django.db.models.fields.TextField', [], {'blank': 'True'}),
            'report_format': ('django.db.models.fields.CharField', [], {'max_length': '1'}),
            'runtime': ('django.db.models.fields.PositiveIntegerField', [], {'null': 'True', 'blank': 'True'}),
            'score': ('django.db.models.fields.IntegerField', [], {'null': 'True', 'blank': 'True'}),
            'stage': ('django.db.models.fields.CharField', [], {'max_length': '16', 'blank': 'True'}),
            'step': ('django.db.models.fields.PositiveSmallIntegerField', [], {})
        },
        'peach3.checkresultstepio': {
            'Meta': {'object_name': 'CheckResultStepIO'},
            'checkresultstep': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['peach3.CheckResultStep']"}),
            'data': ('django.db.models.fields.TextField', [], {}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'order': ('django.db.models.fields.PositiveIntegerField', [], {}),
            'stream': ('django.db.models.fields.CharField', [], {'max_length': '1'}),
            'timestamp': ('django.db.models.fields.PositiveIntegerField', [], {})
        },
        'peach3.cluster': {
            'Meta': {'unique_together': "(('courseedition', 'default_name'),)", 'object_name': 'Cluster'},
            'active': ('django.db.models.fields.NullBooleanField', [], {'default': 'False', 'null': 'True', 'blank': 'True'}),
            'active_from': ('django.db.models.fields.DateTimeField', [], {'null': 'True', 'blank': 'True'}),
            'active_until': ('django.db.models.fields.DateTimeField', [], {'null': 'True', 'blank': 'True'}),
            'admin_cluster': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'courseedition': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['peach3.CourseEdition']"}),
            'default_language': ('django.db.models.fields.CharField', [], {'default': "'en'", 'max_length': '16'}),
            'default_name': ('django.db.models.fields.CharField', [], {'max_length': '100', 'blank': 'True'}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'joinable': ('django.db.models.fields.NullBooleanField', [], {'default': 'False', 'null': 'True', 'blank': 'True'}),
            'joinable_from': ('django.db.models.fields.DateTimeField', [], {'null': 'True', 'blank': 'True'}),
            'joinable_until': ('django.db.models.fields.DateTimeField', [], {'null': 'True', 'blank': 'True'}),
            'order': ('django.db.models.fields.PositiveIntegerField', [], {'null': 'True', 'blank': 'True'}),
            'realms': ('django.db.models.fields.related.ManyToManyField', [], {'to': "orm['peach3.Realm']", 'symmetrical': 'False'})
        },
        'peach3.clustermember': {
            'Meta': {'unique_together': "(('cluster', 'user'),)", 'object_name': 'ClusterMember'},
            'active': ('django.db.models.fields.BooleanField', [], {'default': 'True'}),
            'cluster': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['peach3.Cluster']"}),
            'favorite': ('django.db.models.fields.BooleanField', [], {'default': 'True'}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'realm': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['peach3.Realm']"}),
            'user': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['auth.User']"})
        },
        'peach3.clusterstaff': {
            'Meta': {'unique_together': "(('cluster', 'user'),)", 'object_name': 'ClusterStaff'},
            'cluster': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['peach3.Cluster']"}),
            'extend_deadline': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'level': ('django.db.models.fields.PositiveSmallIntegerField', [], {}),
            'role': ('django.db.models.fields.CharField', [], {'max_length': '8'}),
            'user': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['auth.User']"})
        },
        'peach3.clustertimerange': {
            'Meta': {'unique_together': "(('cluster', 'assignmentedition', 'type'),)", 'object_name': 'ClusterTimeRange'},
            'assignmentedition': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['peach3.AssignmentEdition']"}),
            'cluster': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['peach3.Cluster']"}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'state_from': ('django.db.models.fields.DateTimeField', [], {'null': 'True', 'blank': 'True'}),
            'state_until': ('django.db.models.fields.DateTimeField', [], {'null': 'True', 'blank': 'True'}),
            'type': ('django.db.models.fields.CharField', [], {'max_length': '1'})
        },
        'peach3.comment': {
            'Meta': {'object_name': 'Comment'},
            'author': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['auth.User']"}),
            'created': ('django.db.models.fields.DateTimeField', [], {}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'parent_content_type': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['contenttypes.ContentType']"}),
            'parent_id': ('django.db.models.fields.PositiveIntegerField', [], {}),
            'response_to': ('django.db.models.fields.related.ForeignKey', [], {'blank': 'True', 'related_name': "'response_set'", 'null': 'True', 'to': "orm['peach3.Comment']"})
        },
        'peach3.commentrevision': {
            'Meta': {'object_name': 'CommentRevision'},
            'author': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['auth.User']"}),
            'comment': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['peach3.Comment']"}),
            'created': ('django.db.models.fields.DateTimeField', [], {}),
            'header': ('django.db.models.fields.CharField', [], {'max_length': '255', 'blank': 'True'}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'markup': ('django.db.models.fields.CharField', [], {'default': "'plain'", 'max_length': '8'}),
            'message': ('django.db.models.fields.TextField', [], {'blank': 'True'})
        },
        'peach3.course': {
            'Meta': {'object_name': 'Course'},
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'})
        },
        'peach3.courseedition': {
            'Meta': {'unique_together': "(('course', 'period'), ('code', 'period'))", 'object_name': 'CourseEdition'},
            'cluster_selection': ('django.db.models.fields.CharField', [], {'default': "'M'", 'max_length': '1'}),
            'code': ('django.db.models.fields.SlugField', [], {'max_length': '16', 'db_index': 'True'}),
            'course': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['peach3.Course']"}),
            'created': ('django.db.models.fields.DateTimeField', [], {}),
            'default_language': ('django.db.models.fields.CharField', [], {'default': "'en'", 'max_length': '16'}),
            'default_name': ('django.db.models.fields.CharField', [], {'max_length': '100'}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'managers': ('django.db.models.fields.related.ManyToManyField', [], {'symmetrical': 'False', 'related_name': "'courseedition_manager_set'", 'blank': 'True', 'to': "orm['auth.User']"}),
            'period': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['peach3.Period']"}),
            'scoreboard': ('django.db.models.fields.BooleanField', [], {'default': 'False'})
        },
        'peach3.file': {
            'Meta': {'object_name': 'File'},
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'})
        },
        'peach3.filerevision': {
            'Meta': {'object_name': 'FileRevision'},
            'charset': ('django.db.models.fields.CharField', [], {'max_length': '32', 'blank': 'True'}),
            'created': ('django.db.models.fields.DateTimeField', [], {}),
            'created_by': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['auth.User']"}),
            'file': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['peach3.File']"}),
            'filename': ('django.db.models.fields.CharField', [], {'max_length': '100'}),
            'filepath': ('django.db.models.fields.CharField', [], {'max_length': '300'}),
            'filetype': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['peach3.FileType']", 'null': 'True', 'blank': 'True'}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'provided_mimetype': ('django.db.models.fields.CharField', [], {'max_length': '32', 'blank': 'True'}),
            'sha1': ('django.db.models.fields.CharField', [], {'max_length': '40'})
        },
        'peach3.filetype': {
            'Meta': {'object_name': 'FileType'},
            'base_type': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'binary_content': ('django.db.models.fields.NullBooleanField', [], {'null': 'True', 'blank': 'True'}),
            'default_language': ('django.db.models.fields.CharField', [], {'default': "'en'", 'max_length': '16'}),
            'default_name': ('django.db.models.fields.CharField', [], {'unique': 'True', 'max_length': '100'}),
            'iconcls': ('django.db.models.fields.CharField', [], {'max_length': '30', 'blank': 'True'}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'lexer': ('django.db.models.fields.CharField', [], {'default': "''", 'max_length': '80', 'blank': 'True'}),
            'lexer_parameters': ('django.db.models.fields.TextField', [], {'blank': 'True'}),
            'mimetypes': ('django.db.models.fields.TextField', [], {'default': "''", 'blank': 'True'}),
            'namepatterns': ('django.db.models.fields.TextField', [], {'default': "''", 'blank': 'True'})
        },
        'peach3.finalgrade': {
            'Meta': {'object_name': 'FinalGrade'},
            'courseedition': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['peach3.CourseEdition']"}),
            'grade': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['peach3.Grade']"}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'user': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['auth.User']"})
        },
        'peach3.grade': {
            'Meta': {'unique_together': "(('system', 'default_name'),)", 'object_name': 'Grade'},
            'default_language': ('django.db.models.fields.CharField', [], {'default': "'en'", 'max_length': '16'}),
            'default_name': ('django.db.models.fields.CharField', [], {'max_length': '100'}),
            'icon': ('django.db.models.fields.CharField', [], {'max_length': '80', 'blank': 'True'}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'passing': ('django.db.models.fields.NullBooleanField', [], {'null': 'True', 'blank': 'True'}),
            'system': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['peach3.GradingSystem']"}),
            'value_high': ('django.db.models.fields.DecimalField', [], {'null': 'True', 'max_digits': '7', 'decimal_places': '2', 'blank': 'True'}),
            'value_low': ('django.db.models.fields.DecimalField', [], {'max_digits': '7', 'decimal_places': '2'})
        },
        'peach3.gradingsystem': {
            'Meta': {'object_name': 'GradingSystem'},
            'default_language': ('django.db.models.fields.CharField', [], {'default': "'en'", 'max_length': '16'}),
            'default_name': ('django.db.models.fields.CharField', [], {'unique': 'True', 'max_length': '100'}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'})
        },
        'peach3.individualtimerange': {
            'Meta': {'unique_together': "(('user', 'assignmentedition', 'type'),)", 'object_name': 'IndividualTimeRange'},
            'assignmentedition': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['peach3.AssignmentEdition']"}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'state_from': ('django.db.models.fields.DateTimeField', [], {'null': 'True', 'blank': 'True'}),
            'state_until': ('django.db.models.fields.DateTimeField', [], {'null': 'True', 'blank': 'True'}),
            'type': ('django.db.models.fields.CharField', [], {'max_length': '1'}),
            'user': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['auth.User']"})
        },
        'peach3.newsbody': {
            'Meta': {'object_name': 'NewsBody'},
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'markup': ('django.db.models.fields.SlugField', [], {'default': "'plain'", 'max_length': '8', 'db_index': 'True'}),
            'message': ('django.db.models.fields.TextField', [], {}),
            'subject': ('django.db.models.fields.CharField', [], {'max_length': '80'})
        },
        'peach3.newsitem': {
            'Meta': {'object_name': 'NewsItem'},
            'appears': ('django.db.models.fields.DateTimeField', [], {}),
            'cluster': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['peach3.Cluster']", 'null': 'True', 'blank': 'True'}),
            'courseedition': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['peach3.CourseEdition']", 'null': 'True', 'blank': 'True'}),
            'created': ('django.db.models.fields.DateTimeField', [], {}),
            'created_by': ('django.db.models.fields.related.ForeignKey', [], {'related_name': "'newsitem_creator'", 'to': "orm['auth.User']"}),
            'current': ('django.db.models.fields.BooleanField', [], {'default': 'True'}),
            'expires': ('django.db.models.fields.DateTimeField', [], {}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'msgparam': ('django.db.models.fields.TextField', [], {'blank': 'True'}),
            'msgtype': ('django.db.models.fields.SlugField', [], {'db_index': 'True', 'max_length': '50', 'blank': 'True'}),
            'read': ('django.db.models.fields.related.ManyToManyField', [], {'symmetrical': 'False', 'related_name': "'newsitem_read'", 'blank': 'True', 'to': "orm['auth.User']"}),
            'receipient': ('django.db.models.fields.related.ForeignKey', [], {'blank': 'True', 'related_name': "'newsitem_receipient'", 'null': 'True', 'to': "orm['auth.User']"}),
            'related_content_type': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['contenttypes.ContentType']", 'null': 'True', 'blank': 'True'}),
            'related_id': ('django.db.models.fields.PositiveIntegerField', [], {'null': 'True', 'blank': 'True'}),
            'text': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['peach3.NewsBody']", 'null': 'True', 'blank': 'True'})
        },
        'peach3.page': {
            'Meta': {'unique_together': "(('parent_type', 'parent_id', 'path'),)", 'object_name': 'Page'},
            'access': ('django.db.models.fields.PositiveSmallIntegerField', [], {'default': '2'}),
            'allow_comments': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'created': ('django.db.models.fields.DateTimeField', [], {}),
            'created_by': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['auth.User']"}),
            'default_language': ('django.db.models.fields.CharField', [], {'default': "'en'", 'max_length': '16'}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'parent_access': ('django.db.models.fields.CharField', [], {'max_length': '16', 'blank': 'True'}),
            'parent_id': ('django.db.models.fields.PositiveIntegerField', [], {'null': 'True', 'blank': 'True'}),
            'parent_type': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['contenttypes.ContentType']", 'null': 'True', 'blank': 'True'}),
            'path': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'permission': ('django.db.models.fields.related.ManyToManyField', [], {'related_name': "'page_permission'", 'symmetrical': 'False', 'through': "orm['peach3.PagePermission']", 'to': "orm['auth.User']"})
        },
        'peach3.pagepermission': {
            'Meta': {'object_name': 'PagePermission'},
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'page': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['peach3.Page']"}),
            'permission': ('django.db.models.fields.PositiveSmallIntegerField', [], {}),
            'user': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['auth.User']"})
        },
        'peach3.pagerevision': {
            'Meta': {'object_name': 'PageRevision'},
            'changes': ('django.db.models.fields.TextField', [], {'blank': 'True'}),
            'created': ('django.db.models.fields.DateTimeField', [], {}),
            'created_by': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['auth.User']"}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'language': ('django.db.models.fields.CharField', [], {'default': "'en'", 'max_length': '16'}),
            'page': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['peach3.Page']"}),
            'text': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['peach3.PageRevisionText']"})
        },
        'peach3.pagerevisiontext': {
            'Meta': {'object_name': 'PageRevisionText'},
            'content_or_diff': ('django.db.models.fields.TextField', [], {}),
            'diff_base': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['peach3.PageRevisionText']", 'null': 'True', 'blank': 'True'}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'markup': ('django.db.models.fields.CharField', [], {'default': "'rst'", 'max_length': '8'})
        },
        'peach3.period': {
            'Meta': {'ordering': "('_begin', '-_end')", 'object_name': 'Period'},
            '_begin': ('django.db.models.fields.DateTimeField', [], {'default': 'None', 'null': 'True', 'db_column': "'begin'", 'blank': 'True'}),
            '_end': ('django.db.models.fields.DateTimeField', [], {'default': 'None', 'null': 'True', 'db_column': "'end'", 'blank': 'True'}),
            'default_language': ('django.db.models.fields.CharField', [], {'default': "'en'", 'max_length': '16'}),
            'default_name': ('django.db.models.fields.CharField', [], {'max_length': '100'}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'slug': ('django.db.models.fields.CharField', [], {'unique': 'True', 'max_length': '8'})
        },
        'peach3.profile': {
            'Meta': {'object_name': 'Profile'},
            'date_format': ('django.db.models.fields.CharField', [], {'default': "'D j M Y'", 'max_length': '16'}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'initials': ('django.db.models.fields.CharField', [], {'max_length': '30', 'blank': 'True'}),
            'language': ('django.db.models.fields.CharField', [], {'default': "''", 'max_length': '16', 'blank': 'True'}),
            'last_name_prefix': ('django.db.models.fields.CharField', [], {'max_length': '30', 'blank': 'True'}),
            'last_name_suffix': ('django.db.models.fields.CharField', [], {'max_length': '30', 'blank': 'True'}),
            'programmingLanguage': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['peach3.ProgrammingLanguage']", 'null': 'True', 'blank': 'True'}),
            'state': ('django.db.models.fields.CharField', [], {'default': "'U'", 'max_length': '1'}),
            'time_format': ('django.db.models.fields.CharField', [], {'default': "'G:i'", 'max_length': '8'}),
            'timezone_str': ('django.db.models.fields.CharField', [], {'default': "'Europe/Amsterdam'", 'max_length': '48'}),
            'titles_prefix': ('django.db.models.fields.CharField', [], {'max_length': '30', 'blank': 'True'}),
            'titles_suffix': ('django.db.models.fields.CharField', [], {'max_length': '30', 'blank': 'True'}),
            'user': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['auth.User']"})
        },
        'peach3.programminglanguage': {
            'Meta': {'object_name': 'ProgrammingLanguage', 'db_table': "'peach3_proglang'"},
            'code': ('django.db.models.fields.CharField', [], {'max_length': '16'}),
            'default_language': ('django.db.models.fields.CharField', [], {'default': "'en'", 'max_length': '16'}),
            'default_name': ('django.db.models.fields.CharField', [], {'unique': 'True', 'max_length': '100'}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'})
        },
        'peach3.realm': {
            'Meta': {'object_name': 'Realm'},
            'default_language': ('django.db.models.fields.CharField', [], {'default': "'en'", 'max_length': '16'}),
            'default_name': ('django.db.models.fields.CharField', [], {'unique': 'True', 'max_length': '100'}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'site': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['sites.Site']"})
        },
        'peach3.reason': {
            'Meta': {'object_name': 'Reason'},
            'code': ('django.db.models.fields.CharField', [], {'max_length': '16', 'db_index': 'True'}),
            'default_description': ('django.db.models.fields.TextField', [], {}),
            'default_language': ('django.db.models.fields.CharField', [], {'default': "'en'", 'max_length': '16'}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'param1': ('django.db.models.fields.CharField', [], {'max_length': '16', 'blank': 'True'}),
            'param2': ('django.db.models.fields.CharField', [], {'max_length': '16', 'blank': 'True'})
        },
        'peach3.reasonaltdescription': {
            'Meta': {'unique_together': "(('reason', 'language'),)", 'object_name': 'ReasonAltDescription'},
            'description': ('django.db.models.fields.CharField', [], {'max_length': '80'}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'language': ('django.db.models.fields.CharField', [], {'max_length': '16'}),
            'reason': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['peach3.Reason']"})
        },
        'peach3.refpdfinfo': {
            'Meta': {'object_name': 'RefPDFInfo', '_ormbases': ['pdfviewer.PDFInfo']},
            'pdfinfo_ptr': ('django.db.models.fields.related.OneToOneField', [], {'to': "orm['pdfviewer.PDFInfo']", 'unique': 'True', 'primary_key': 'True'}),
            'ref_ct': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['contenttypes.ContentType']", 'null': 'True', 'blank': 'True'}),
            'ref_id': ('django.db.models.fields.PositiveIntegerField', [], {'null': 'True', 'blank': 'True'})
        },
        'peach3.report': {
            'Meta': {'object_name': 'Report'},
            'created': ('django.db.models.fields.DateTimeField', [], {}),
            'filename': ('django.db.models.fields.CharField', [], {'max_length': '256'}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'last_access': ('django.db.models.fields.DateTimeField', [], {'null': 'True', 'blank': 'True'}),
            'mimetype': ('django.db.models.fields.CharField', [], {'max_length': '50'}),
            'parameters': ('django.db.models.fields.TextField', [], {}),
            'type': ('django.db.models.fields.CharField', [], {'max_length': '12'}),
            'users': ('django.db.models.fields.related.ManyToManyField', [], {'to': "orm['auth.User']", 'symmetrical': 'False'})
        },
        'peach3.review': {
            'Meta': {'object_name': 'Review'},
            'authors': ('django.db.models.fields.related.ManyToManyField', [], {'related_name': "'review_author'", 'symmetrical': 'False', 'to': "orm['auth.User']"}),
            'created': ('django.db.models.fields.DateTimeField', [], {}),
            'created_by': ('django.db.models.fields.related.ForeignKey', [], {'related_name': "'review_creator'", 'to': "orm['auth.User']"}),
            'grade': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['peach3.Grade']", 'null': 'True', 'blank': 'True'}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'reviewlevel': ('django.db.models.fields.PositiveSmallIntegerField', [], {}),
            'submission': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['peach3.Submission']"}),
            'visibilitylevel': ('django.db.models.fields.PositiveSmallIntegerField', [], {})
        },
        'peach3.submission': {
            'Meta': {'object_name': 'Submission'},
            'assignmentedition': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['peach3.AssignmentEdition']"}),
            'authors': ('django.db.models.fields.related.ManyToManyField', [], {'to': "orm['auth.User']", 'symmetrical': 'False'}),
            'courseedition': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['peach3.CourseEdition']"}),
            'created': ('django.db.models.fields.DateTimeField', [], {'db_index': 'True'}),
            'created_by': ('django.db.models.fields.related.ForeignKey', [], {'related_name': "'submission_created_set'", 'to': "orm['auth.User']"}),
            'files': ('django.db.models.fields.related.ManyToManyField', [], {'to': "orm['peach3.FileRevision']", 'through': "orm['peach3.SubmissionFile']", 'symmetrical': 'False'}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'language': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['peach3.ProgrammingLanguage']", 'null': 'True', 'blank': 'True'}),
            'modified': ('django.db.models.fields.DateTimeField', [], {'db_index': 'True', 'null': 'True', 'blank': 'True'}),
            'submitted': ('django.db.models.fields.DateTimeField', [], {'null': 'True', 'blank': 'True'}),
            'submitted_by': ('django.db.models.fields.related.ForeignKey', [], {'blank': 'True', 'related_name': "'submission_submitted_set'", 'null': 'True', 'to': "orm['auth.User']"})
        },
        'peach3.submissionfile': {
            'Meta': {'object_name': 'SubmissionFile'},
            'file': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['peach3.FileRevision']"}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'slot': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['peach3.AssignmentSlot']", 'null': 'True', 'blank': 'True'}),
            'submission': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['peach3.Submission']"})
        },
        'peach3.translatedname': {
            'Meta': {'unique_together': "(('content_type', 'object_id', 'language'),)", 'object_name': 'TranslatedName'},
            'content_type': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['contenttypes.ContentType']"}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'language': ('django.db.models.fields.CharField', [], {'max_length': '16'}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '100'}),
            'object_id': ('django.db.models.fields.PositiveIntegerField', [], {})
        },
        'peach3.verificationcode': {
            'Meta': {'object_name': 'VerificationCode'},
            'code': ('django.db.models.fields.CharField', [], {'max_length': '8'}),
            'created': ('django.db.models.fields.DateTimeField', [], {}),
            'expires': ('django.db.models.fields.DateTimeField', [], {'null': 'True', 'blank': 'True'}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'parameters': ('django.db.models.fields.TextField', [], {'blank': 'True'}),
            'type': ('django.db.models.fields.CharField', [], {'max_length': '1'}),
            'user': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['auth.User']"})
        },
        'sites.site': {
            'Meta': {'ordering': "('domain',)", 'object_name': 'Site', 'db_table': "'django_site'"},
            'domain': ('django.db.models.fields.CharField', [], {'max_length': '100'}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '50'})
        }
    }

    complete_apps = ['peach3']
