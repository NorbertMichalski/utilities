# -*- coding: utf-8 -*-
import datetime
from south.db import db
from south.v2 import SchemaMigration
from django.db import models
from django.utils.timezone import now

class Migration(SchemaMigration):

    def forwards(self, orm):

        # Changing field 'Submission.modified'
        db.alter_column('peach3_submission', 'modified', self.gf('django.db.models.fields.DateTimeField')(auto_now=True, default=now()))
    def backwards(self, orm):

        # Changing field 'Submission.modified'
        db.alter_column('peach3_submission', 'modified', self.gf('django.db.models.fields.DateTimeField')(null=True))
    models = {
        'auth.group': {
            'Meta': {'object_name': 'Group'},
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'name': ('django.db.models.fields.CharField', [], {'unique': 'True', 'max_length': '80'}),
            'permissions': ('django.db.models.fields.related.ManyToManyField', [], {'to': "orm['auth.Permission']", 'symmetrical': 'False', 'blank': 'True'})
        },
        'auth.permission': {
            'Meta': {'ordering': "('content_type__app_label', 'content_type__model', 'codename')", 'unique_together': "(('content_type', 'codename'),)", 'object_name': 'Permission'},
            'codename': ('django.db.models.fields.CharField', [], {'max_length': '100'}),
            'content_type': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['contenttypes.ContentType']"}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '50'})
        },
        'auth.user': {
            'Meta': {'object_name': 'User'},
            'date_joined': ('django.db.models.fields.DateTimeField', [], {'default': 'datetime.datetime.now'}),
            'email': ('django.db.models.fields.EmailField', [], {'max_length': '75', 'blank': 'True'}),
            'first_name': ('django.db.models.fields.CharField', [], {'max_length': '30', 'blank': 'True'}),
            'groups': ('django.db.models.fields.related.ManyToManyField', [], {'to': "orm['auth.Group']", 'symmetrical': 'False', 'blank': 'True'}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'is_active': ('django.db.models.fields.BooleanField', [], {'default': 'True'}),
            'is_staff': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'is_superuser': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'last_login': ('django.db.models.fields.DateTimeField', [], {'default': 'datetime.datetime.now'}),
            'last_name': ('django.db.models.fields.CharField', [], {'max_length': '30', 'blank': 'True'}),
            'password': ('django.db.models.fields.CharField', [], {'max_length': '128'}),
            'user_permissions': ('django.db.models.fields.related.ManyToManyField', [], {'to': "orm['auth.Permission']", 'symmetrical': 'False', 'blank': 'True'}),
            'username': ('django.db.models.fields.CharField', [], {'unique': 'True', 'max_length': '30'})
        },
        'contenttypes.contenttype': {
            'Meta': {'ordering': "('name',)", 'unique_together': "(('app_label', 'model'),)", 'object_name': 'ContentType', 'db_table': "'django_content_type'"},
            'app_label': ('django.db.models.fields.CharField', [], {'max_length': '100'}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'model': ('django.db.models.fields.CharField', [], {'max_length': '100'}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '100'})
        },
        'pdfviewer.pdfinfo': {
            'Meta': {'object_name': 'PDFInfo'},
            'hash': ('django.db.models.fields.CharField', [], {'max_length': '32', 'db_index': 'True'}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'last_access': ('django.db.models.fields.DateTimeField', [], {'auto_now': 'True', 'blank': 'True'}),
            'path': ('django.db.models.fields.CharField', [], {'max_length': '500', 'db_index': 'True'}),
            'title': ('django.db.models.fields.CharField', [], {'max_length': '250'})
        },
        'peach3.assignmentedition': {
            'Meta': {'ordering': "('order', 'default_name')", 'unique_together': "(('courseedition', 'slug'),)", 'object_name': 'AssignmentEdition'},
            'assignmentset': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['peach3.AssignmentSet']", 'null': 'True', 'blank': 'True'}),
            'courseedition': ('mptt.fields.TreeForeignKey', [], {'to': "orm['peach3.CourseEdition']"}),
            'created': ('django.db.models.fields.DateTimeField', [], {'default': 'datetime.datetime.now'}),
            'default_language': ('django.db.models.fields.CharField', [], {'default': "'en'", 'max_length': '16'}),
            'default_name': ('django.db.models.fields.CharField', [], {'max_length': '100'}),
            'gradingsystems': ('django.db.models.fields.related.ManyToManyField', [], {'to': "orm['peach3.GradingSystem']", 'symmetrical': 'False', 'blank': 'True'}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'languages': ('django.db.models.fields.related.ManyToManyField', [], {'to': "orm['peach3.ProgrammingLanguage']", 'symmetrical': 'False', 'blank': 'True'}),
            'layout': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['peach3.AssignmentLayout']", 'null': 'True', 'blank': 'True'}),
            'level': ('django.db.models.fields.PositiveIntegerField', [], {'db_index': 'True'}),
            'lft': ('django.db.models.fields.PositiveIntegerField', [], {'db_index': 'True'}),
            'observelevel': ('django.db.models.fields.PositiveSmallIntegerField', [], {'default': '1'}),
            'order': ('django.db.models.fields.PositiveIntegerField', [], {'null': 'True', 'blank': 'True'}),
            'parent': ('mptt.fields.TreeForeignKey', [], {'blank': 'True', 'related_name': "'children'", 'null': 'True', 'to': "orm['peach3.AssignmentEdition']"}),
            'reviewlevel': ('django.db.models.fields.PositiveSmallIntegerField', [], {'default': '1'}),
            'reviewpublishlevel': ('django.db.models.fields.PositiveSmallIntegerField', [], {'default': '1'}),
            'rght': ('django.db.models.fields.PositiveIntegerField', [], {'db_index': 'True'}),
            'slug': ('django.db.models.fields.SlugField', [], {'max_length': '32'}),
            'tree_id': ('django.db.models.fields.PositiveIntegerField', [], {'db_index': 'True'})
        },
        'peach3.assignmenteditionoption': {
            'Meta': {'unique_together': "(('assignmentedition', 'option'),)", 'object_name': 'AssignmentEditionOption', 'db_table': "'peach3_asgnedoption'"},
            'assignmentedition': ('mptt.fields.TreeForeignKey', [], {'to': "orm['peach3.AssignmentEdition']"}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'option': ('django.db.models.fields.CharField', [], {'max_length': '16'}),
            'parameters': ('django.db.models.fields.TextField', [], {'blank': 'True'})
        },
        'peach3.assignmentlayout': {
            'Meta': {'object_name': 'AssignmentLayout'},
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'name': ('django.db.models.fields.CharField', [], {'unique': 'True', 'max_length': '80'})
        },
        'peach3.assignmentset': {
            'Meta': {'ordering': "('courseedition', 'order', 'default_name')", 'object_name': 'AssignmentSet'},
            'courseedition': ('mptt.fields.TreeForeignKey', [], {'to': "orm['peach3.CourseEdition']"}),
            'default_language': ('django.db.models.fields.CharField', [], {'default': "'en'", 'max_length': '16'}),
            'default_name': ('django.db.models.fields.CharField', [], {'max_length': '100'}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'order': ('django.db.models.fields.PositiveIntegerField', [], {'null': 'True', 'blank': 'True'})
        },
        'peach3.assignmentslot': {
            'Meta': {'object_name': 'AssignmentSlot'},
            'allowedTypes': ('django.db.models.fields.related.ManyToManyField', [], {'to': "orm['peach3.FileType']", 'symmetrical': 'False', 'blank': 'True'}),
            'assignmentsubmlayout': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['peach3.AssignmentLayout']"}),
            'default_language': ('django.db.models.fields.CharField', [], {'default': "'en'", 'max_length': '16'}),
            'default_name': ('django.db.models.fields.CharField', [], {'max_length': '100'}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'namePattern': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'order': ('django.db.models.fields.PositiveIntegerField', [], {}),
            'required': ('django.db.models.fields.BooleanField', [], {'default': 'False'})
        },
        'peach3.checkresult': {
            'Meta': {'ordering': "('submission', 'created')", 'object_name': 'CheckResult'},
            'checked': ('django.db.models.fields.DateTimeField', [], {'null': 'True', 'blank': 'True'}),
            'checked_level': ('django.db.models.fields.PositiveSmallIntegerField', [], {'null': 'True', 'blank': 'True'}),
            'created': ('django.db.models.fields.DateTimeField', [], {'default': 'datetime.datetime.now'}),
            'grade': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['peach3.Grade']", 'null': 'True', 'blank': 'True'}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'report': ('django.db.models.fields.TextField', [], {'blank': 'True'}),
            'score_0': ('django.db.models.fields.IntegerField', [], {'null': 'True', 'blank': 'True'}),
            'score_1': ('django.db.models.fields.IntegerField', [], {'null': 'True', 'blank': 'True'}),
            'score_10': ('django.db.models.fields.IntegerField', [], {'null': 'True', 'blank': 'True'}),
            'score_2': ('django.db.models.fields.IntegerField', [], {'null': 'True', 'blank': 'True'}),
            'score_3': ('django.db.models.fields.IntegerField', [], {'null': 'True', 'blank': 'True'}),
            'score_4': ('django.db.models.fields.IntegerField', [], {'null': 'True', 'blank': 'True'}),
            'score_5': ('django.db.models.fields.IntegerField', [], {'null': 'True', 'blank': 'True'}),
            'score_6': ('django.db.models.fields.IntegerField', [], {'null': 'True', 'blank': 'True'}),
            'score_7': ('django.db.models.fields.IntegerField', [], {'null': 'True', 'blank': 'True'}),
            'score_8': ('django.db.models.fields.IntegerField', [], {'null': 'True', 'blank': 'True'}),
            'score_9': ('django.db.models.fields.IntegerField', [], {'null': 'True', 'blank': 'True'}),
            'state': ('django.db.models.fields.CharField', [], {'max_length': '8', 'blank': 'True'}),
            'submission': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['peach3.Submission']"})
        },
        'peach3.checkresultstep': {
            'Meta': {'ordering': "('checkresult', 'stage', 'step')", 'object_name': 'CheckResultStep'},
            'checkresult': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['peach3.CheckResult']"}),
            'generatedfiles': ('django.db.models.fields.related.ManyToManyField', [], {'symmetrical': 'False', 'to': "orm['peach3.FileRevision']", 'null': 'True', 'blank': 'True'}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'level': ('django.db.models.fields.PositiveSmallIntegerField', [], {}),
            'passed': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'reason': ('django.db.models.fields.CharField', [], {'max_length': '32', 'blank': 'True'}),
            'report': ('django.db.models.fields.TextField', [], {'blank': 'True'}),
            'report_format': ('django.db.models.fields.CharField', [], {'max_length': '1'}),
            'runtime': ('django.db.models.fields.PositiveIntegerField', [], {'null': 'True', 'blank': 'True'}),
            'score': ('django.db.models.fields.IntegerField', [], {'null': 'True', 'blank': 'True'}),
            'stage': ('django.db.models.fields.CharField', [], {'max_length': '16', 'blank': 'True'}),
            'step': ('django.db.models.fields.PositiveSmallIntegerField', [], {})
        },
        'peach3.checkresultstepio': {
            'Meta': {'object_name': 'CheckResultStepIO'},
            'checkresultstep': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['peach3.CheckResultStep']"}),
            'data': ('django.db.models.fields.TextField', [], {}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'order': ('django.db.models.fields.PositiveIntegerField', [], {}),
            'stream': ('django.db.models.fields.CharField', [], {'max_length': '1'}),
            'timestamp': ('django.db.models.fields.PositiveIntegerField', [], {})
        },
        'peach3.cluster': {
            'Meta': {'ordering': "('courseedition', 'order', 'default_name')", 'unique_together': "(('courseedition', 'default_name'),)", 'object_name': 'Cluster'},
            '_active_from': ('django.db.models.fields.DateTimeField', [], {'null': 'True', 'db_column': "'active_from'", 'blank': 'True'}),
            '_active_until': ('django.db.models.fields.DateTimeField', [], {'null': 'True', 'db_column': "'active_until'", 'blank': 'True'}),
            '_joinable_from': ('django.db.models.fields.DateTimeField', [], {'null': 'True', 'db_column': "'joinable_from'", 'blank': 'True'}),
            '_joinable_until': ('django.db.models.fields.DateTimeField', [], {'null': 'True', 'db_column': "'joinable_until'", 'blank': 'True'}),
            'admin_cluster': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'courseedition': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['peach3.CourseEdition']"}),
            'default_language': ('django.db.models.fields.CharField', [], {'default': "'en'", 'max_length': '16'}),
            'default_name': ('django.db.models.fields.CharField', [], {'max_length': '100', 'blank': 'True'}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'order': ('django.db.models.fields.PositiveIntegerField', [], {'null': 'True', 'blank': 'True'}),
            'realms': ('django.db.models.fields.related.ManyToManyField', [], {'symmetrical': 'False', 'to': "orm['peach3.Realm']", 'null': 'True', 'blank': 'True'}),
            'subcodes': ('django.db.models.fields.related.ManyToManyField', [], {'symmetrical': 'False', 'to': "orm['peach3.SubCode']", 'null': 'True', 'blank': 'True'}),
            'test_cluster': ('django.db.models.fields.BooleanField', [], {'default': 'False'})
        },
        'peach3.clustermember': {
            'Meta': {'ordering': "('cluster', 'user')", 'unique_together': "(('cluster', 'user'),)", 'object_name': 'ClusterMember'},
            'cluster': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['peach3.Cluster']"}),
            'favorite': ('django.db.models.fields.BooleanField', [], {'default': 'True'}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'realm': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['peach3.Realm']", 'null': 'True', 'blank': 'True'}),
            'removed': ('django.db.models.fields.CharField', [], {'default': "''", 'max_length': '10', 'blank': 'True'}),
            'source': ('django.db.models.fields.CharField', [], {'default': "''", 'max_length': '10', 'blank': 'True'}),
            'subcode': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['peach3.SubCode']", 'null': 'True', 'blank': 'True'}),
            'user': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['auth.User']"})
        },
        'peach3.clusterstaff': {
            'Meta': {'unique_together': "(('cluster', 'user'),)", 'object_name': 'ClusterStaff'},
            'cluster': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['peach3.Cluster']"}),
            'extend_deadline': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'level': ('peach3.models.fields.ClusterStaffLevelField', [], {}),
            'role': ('django.db.models.fields.CharField', [], {'max_length': '8'}),
            'user': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['auth.User']"})
        },
        'peach3.clustertimerange': {
            'Meta': {'unique_together': "(('cluster', 'assignmentedition', 'type'),)", 'object_name': 'ClusterTimeRange'},
            '_begin': ('django.db.models.fields.DateTimeField', [], {'null': 'True', 'db_column': "'state_from'", 'blank': 'True'}),
            '_end': ('django.db.models.fields.DateTimeField', [], {'null': 'True', 'db_column': "'state_until'", 'blank': 'True'}),
            'assignmentedition': ('mptt.fields.TreeForeignKey', [], {'to': "orm['peach3.AssignmentEdition']"}),
            'cluster': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['peach3.Cluster']"}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'type': ('django.db.models.fields.CharField', [], {'max_length': '1'})
        },
        'peach3.comment': {
            'Meta': {'object_name': 'Comment'},
            'author': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['auth.User']"}),
            'created': ('django.db.models.fields.DateTimeField', [], {'default': 'datetime.datetime.now'}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'parent_content_type': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['contenttypes.ContentType']"}),
            'parent_id': ('django.db.models.fields.PositiveIntegerField', [], {}),
            'response_to': ('django.db.models.fields.related.ForeignKey', [], {'blank': 'True', 'related_name': "'response_set'", 'null': 'True', 'to': "orm['peach3.Comment']"})
        },
        'peach3.commentrevision': {
            'Meta': {'object_name': 'CommentRevision'},
            'author': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['auth.User']"}),
            'comment': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['peach3.Comment']"}),
            'created': ('django.db.models.fields.DateTimeField', [], {'default': 'datetime.datetime.now'}),
            'header': ('django.db.models.fields.CharField', [], {'max_length': '255', 'blank': 'True'}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'markup': ('django.db.models.fields.CharField', [], {'default': "'plain'", 'max_length': '8'}),
            'message': ('django.db.models.fields.TextField', [], {'blank': 'True'})
        },
        'peach3.courseedition': {
            'Meta': {'unique_together': "(('code', 'period'),)", 'object_name': 'CourseEdition'},
            'cluster_selection': ('django.db.models.fields.CharField', [], {'default': "'M'", 'max_length': '1'}),
            'code': ('django.db.models.fields.SlugField', [], {'max_length': '16'}),
            'created': ('django.db.models.fields.DateTimeField', [], {'default': 'datetime.datetime.now'}),
            'created_by': ('django.db.models.fields.related.ForeignKey', [], {'default': 'None', 'to': "orm['auth.User']"}),
            'default_language': ('django.db.models.fields.CharField', [], {'default': "'en'", 'max_length': '16'}),
            'default_name': ('django.db.models.fields.CharField', [], {'max_length': '100'}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'level': ('django.db.models.fields.PositiveIntegerField', [], {'db_index': 'True'}),
            'lft': ('django.db.models.fields.PositiveIntegerField', [], {'db_index': 'True'}),
            'managers': ('django.db.models.fields.related.ManyToManyField', [], {'symmetrical': 'False', 'related_name': "'courseedition_manager_set'", 'blank': 'True', 'to': "orm['auth.User']"}),
            'parent': ('mptt.fields.TreeForeignKey', [], {'blank': 'True', 'related_name': "'children'", 'null': 'True', 'to': "orm['peach3.CourseEdition']"}),
            'period': ('mptt.fields.TreeForeignKey', [], {'to': "orm['peach3.Period']"}),
            'rght': ('django.db.models.fields.PositiveIntegerField', [], {'db_index': 'True'}),
            'scoreboard': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'tree_id': ('django.db.models.fields.PositiveIntegerField', [], {'db_index': 'True'})
        },
        'peach3.filerevision': {
            'Meta': {'object_name': 'FileRevision'},
            'charset': ('django.db.models.fields.CharField', [], {'max_length': '32', 'blank': 'True'}),
            'created': ('django.db.models.fields.DateTimeField', [], {'default': 'datetime.datetime.now'}),
            'file': ('django.db.models.fields.files.FileField', [], {'max_length': '300', 'null': 'True'}),
            'filetype': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['peach3.FileType']", 'null': 'True', 'blank': 'True'}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'sha1': ('django.db.models.fields.CharField', [], {'max_length': '40'})
        },
        'peach3.filetype': {
            'Meta': {'object_name': 'FileType'},
            'base_type': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'binary_content': ('django.db.models.fields.NullBooleanField', [], {'null': 'True', 'blank': 'True'}),
            'default_language': ('django.db.models.fields.CharField', [], {'default': "'en'", 'max_length': '16'}),
            'default_name': ('django.db.models.fields.CharField', [], {'unique': 'True', 'max_length': '100'}),
            'iconcls': ('django.db.models.fields.CharField', [], {'max_length': '30', 'blank': 'True'}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'lexer': ('django.db.models.fields.CharField', [], {'default': "''", 'max_length': '80', 'blank': 'True'}),
            'lexer_parameters': ('django.db.models.fields.TextField', [], {'blank': 'True'}),
            'mimetypes': ('django.db.models.fields.TextField', [], {'default': "''", 'blank': 'True'}),
            'namepatterns': ('django.db.models.fields.TextField', [], {'default': "''", 'blank': 'True'}),
            'validators': ('django.db.models.fields.related.ManyToManyField', [], {'to': "orm['peach3.FileValidator']", 'symmetrical': 'False', 'blank': 'True'})
        },
        'peach3.filevalidator': {
            'Meta': {'object_name': 'FileValidator'},
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '80'}),
            'parameters': ('django.db.models.fields.TextField', [], {'blank': 'True'}),
            'validator': ('django.db.models.fields.CharField', [], {'max_length': '80'})
        },
        'peach3.grade': {
            'Meta': {'ordering': "('system', 'value_low')", 'unique_together': "(('system', 'default_name'),)", 'object_name': 'Grade'},
            'default_language': ('django.db.models.fields.CharField', [], {'default': "'en'", 'max_length': '16'}),
            'default_name': ('django.db.models.fields.CharField', [], {'max_length': '100'}),
            'icon': ('django.db.models.fields.CharField', [], {'max_length': '80', 'blank': 'True'}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'passing': ('django.db.models.fields.NullBooleanField', [], {'null': 'True', 'blank': 'True'}),
            'system': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['peach3.GradingSystem']"}),
            'value_high': ('django.db.models.fields.DecimalField', [], {'null': 'True', 'max_digits': '7', 'decimal_places': '2', 'blank': 'True'}),
            'value_low': ('django.db.models.fields.DecimalField', [], {'max_digits': '7', 'decimal_places': '2'})
        },
        'peach3.gradingsystem': {
            'Meta': {'ordering': "('default_name',)", 'object_name': 'GradingSystem'},
            'default_language': ('django.db.models.fields.CharField', [], {'default': "'en'", 'max_length': '16'}),
            'default_name': ('django.db.models.fields.CharField', [], {'unique': 'True', 'max_length': '100'}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'})
        },
        'peach3.individualtimerange': {
            'Meta': {'unique_together': "(('user', 'assignmentedition', 'type'),)", 'object_name': 'IndividualTimeRange'},
            '_begin': ('django.db.models.fields.DateTimeField', [], {'null': 'True', 'db_column': "'state_from'", 'blank': 'True'}),
            '_end': ('django.db.models.fields.DateTimeField', [], {'null': 'True', 'db_column': "'state_until'", 'blank': 'True'}),
            'assignmentedition': ('mptt.fields.TreeForeignKey', [], {'to': "orm['peach3.AssignmentEdition']"}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'type': ('django.db.models.fields.CharField', [], {'max_length': '1'}),
            'user': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['auth.User']"})
        },
        'peach3.newsbody': {
            'Meta': {'object_name': 'NewsBody'},
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'markup': ('django.db.models.fields.SlugField', [], {'default': "'plain'", 'max_length': '8'}),
            'message': ('django.db.models.fields.TextField', [], {}),
            'subject': ('django.db.models.fields.CharField', [], {'max_length': '80'})
        },
        'peach3.newsitem': {
            'Meta': {'object_name': 'NewsItem'},
            'appears': ('django.db.models.fields.DateTimeField', [], {'default': 'datetime.datetime.now'}),
            'cluster': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['peach3.Cluster']", 'null': 'True', 'blank': 'True'}),
            'courseedition': ('mptt.fields.TreeForeignKey', [], {'to': "orm['peach3.CourseEdition']", 'null': 'True', 'blank': 'True'}),
            'created': ('django.db.models.fields.DateTimeField', [], {'default': 'datetime.datetime.now'}),
            'created_by': ('django.db.models.fields.related.ForeignKey', [], {'default': 'None', 'related_name': "'newsitem_creator'", 'to': "orm['auth.User']"}),
            'current': ('django.db.models.fields.BooleanField', [], {'default': 'True'}),
            'expires': ('django.db.models.fields.DateTimeField', [], {}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'msgparam': ('django.db.models.fields.TextField', [], {'blank': 'True'}),
            'msgtype': ('django.db.models.fields.SlugField', [], {'max_length': '50', 'blank': 'True'}),
            'read': ('django.db.models.fields.related.ManyToManyField', [], {'symmetrical': 'False', 'related_name': "'newsitem_read'", 'blank': 'True', 'to': "orm['auth.User']"}),
            'receipient': ('django.db.models.fields.related.ForeignKey', [], {'blank': 'True', 'related_name': "'newsitem_receipient'", 'null': 'True', 'to': "orm['auth.User']"}),
            'related_content_type': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['contenttypes.ContentType']", 'null': 'True', 'blank': 'True'}),
            'related_id': ('django.db.models.fields.PositiveIntegerField', [], {'null': 'True', 'blank': 'True'}),
            'text': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['peach3.NewsBody']", 'null': 'True', 'blank': 'True'})
        },
        'peach3.page': {
            'Meta': {'unique_together': "(('parent_type', 'parent_id', 'path'),)", 'object_name': 'Page'},
            'access': ('django.db.models.fields.PositiveSmallIntegerField', [], {'default': '2'}),
            'allow_comments': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'created': ('django.db.models.fields.DateTimeField', [], {'default': 'datetime.datetime.now'}),
            'created_by': ('django.db.models.fields.related.ForeignKey', [], {'default': 'None', 'to': "orm['auth.User']"}),
            'default_language': ('django.db.models.fields.CharField', [], {'default': "'en'", 'max_length': '16'}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'parent_access': ('django.db.models.fields.CharField', [], {'max_length': '16', 'blank': 'True'}),
            'parent_id': ('django.db.models.fields.PositiveIntegerField', [], {'null': 'True', 'blank': 'True'}),
            'parent_type': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['contenttypes.ContentType']", 'null': 'True', 'blank': 'True'}),
            'path': ('django.db.models.fields.CharField', [], {'max_length': '200', 'blank': 'True'}),
            'permission': ('django.db.models.fields.related.ManyToManyField', [], {'related_name': "'page_permission'", 'symmetrical': 'False', 'through': "orm['peach3.PagePermission']", 'to': "orm['auth.User']"})
        },
        'peach3.pagepermission': {
            'Meta': {'object_name': 'PagePermission'},
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'page': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['peach3.Page']"}),
            'permission': ('django.db.models.fields.PositiveSmallIntegerField', [], {}),
            'user': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['auth.User']"})
        },
        'peach3.pagerevision': {
            'Meta': {'object_name': 'PageRevision'},
            'changes': ('django.db.models.fields.TextField', [], {'blank': 'True'}),
            'created': ('django.db.models.fields.DateTimeField', [], {'default': 'datetime.datetime.now'}),
            'created_by': ('django.db.models.fields.related.ForeignKey', [], {'default': 'None', 'to': "orm['auth.User']"}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'language': ('django.db.models.fields.CharField', [], {'default': "'en'", 'max_length': '16'}),
            'page': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['peach3.Page']"}),
            'text': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['peach3.PageRevisionText']", 'null': 'True', 'blank': 'True'})
        },
        'peach3.pagerevisiontext': {
            'Meta': {'object_name': 'PageRevisionText'},
            'content_or_diff': ('django.db.models.fields.TextField', [], {}),
            'diff_base': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['peach3.PageRevisionText']", 'null': 'True', 'blank': 'True'}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'markup': ('django.db.models.fields.CharField', [], {'default': "'rst'", 'max_length': '8'})
        },
        'peach3.peerreview': {
            'Meta': {'unique_together': "(('bundle', 'identifier'),)", 'object_name': 'PeerReview'},
            'bundle': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['peach3.PeerReviewBundle']"}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'identifier': ('django.db.models.fields.CharField', [], {'max_length': '16'}),
            'rank': ('django.db.models.fields.PositiveIntegerField', [], {'null': 'True', 'blank': 'True'}),
            'review': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['peach3.SubmissionFile']", 'null': 'True', 'blank': 'True'}),
            'review_grade': ('django.db.models.fields.related.ForeignKey', [], {'blank': 'True', 'related_name': "'review_grade'", 'null': 'True', 'to': "orm['peach3.Grade']"}),
            'submission': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['peach3.Submission']"}),
            'submission_grade': ('django.db.models.fields.related.ForeignKey', [], {'blank': 'True', 'related_name': "'submission_grade'", 'null': 'True', 'to': "orm['peach3.Grade']"})
        },
        'peach3.peerreviewassignment': {
            'Meta': {'object_name': 'PeerReviewAssignment', 'db_table': "'peach3_peerreview_assignment'"},
            '_review_result_visible_from': ('django.db.models.fields.DateTimeField', [], {'null': 'True', 'db_column': "'review_result_visible_from'", 'blank': 'True'}),
            '_review_result_visible_until': ('django.db.models.fields.DateTimeField', [], {'null': 'True', 'db_column': "'review_result_visible_until'", 'blank': 'True'}),
            'bundle_size': ('django.db.models.fields.IntegerField', [], {'default': '3'}),
            'feedback_grade': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'feedback_rank': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'feedback_report': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'grading': ('django.db.models.fields.IntegerField', [], {'default': '0'}),
            'original_assignment': ('django.db.models.fields.related.ForeignKey', [], {'related_name': "'peerreviewed_via_set'", 'to': "orm['peach3.AssignmentEdition']"}),
            'ranking': ('django.db.models.fields.IntegerField', [], {'default': '0'}),
            'ranking_max_equal_group_size': ('django.db.models.fields.IntegerField', [], {'null': 'True', 'blank': 'True'}),
            'ranking_max_equal_groups': ('django.db.models.fields.IntegerField', [], {'null': 'True', 'blank': 'True'}),
            'reporting': ('django.db.models.fields.IntegerField', [], {'default': '2'}),
            'reporting_type': ('django.db.models.fields.CharField', [], {'default': "'all'", 'max_length': '4'}),
            'review_assignment': ('django.db.models.fields.related.OneToOneField', [], {'to': "orm['peach3.AssignmentEdition']", 'unique': 'True', 'primary_key': 'True'}),
            'review_gradingsystem': ('django.db.models.fields.related.ManyToManyField', [], {'symmetrical': 'False', 'related_name': "'peerreviewassignment_review_set'", 'blank': 'True', 'to': "orm['peach3.GradingSystem']"}),
            'reviewed_by_group': ('django.db.models.fields.BooleanField', [], {'default': 'True'}),
            'submission_gradingsystem': ('django.db.models.fields.related.ManyToManyField', [], {'symmetrical': 'False', 'related_name': "'peerreviewassignment_submission_set'", 'blank': 'True', 'to': "orm['peach3.GradingSystem']"})
        },
        'peach3.peerreviewbundle': {
            'Meta': {'object_name': 'PeerReviewBundle'},
            'assignment': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['peach3.PeerReviewAssignment']"}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'reviewer': ('django.db.models.fields.related.ManyToManyField', [], {'to': "orm['auth.User']", 'symmetrical': 'False'})
        },
        'peach3.period': {
            'Meta': {'ordering': "('_begin', '_end')", 'unique_together': "(('_begin', '_end'),)", 'object_name': 'Period'},
            '_begin': ('django.db.models.fields.DateTimeField', [], {'default': 'datetime.datetime(1899, 1, 1, 0, 0)', 'db_column': "'begin'", 'db_index': 'True'}),
            '_end': ('django.db.models.fields.DateTimeField', [], {'default': 'datetime.datetime(3001, 1, 1, 0, 0)', 'db_column': "'end'", 'db_index': 'True'}),
            'default_language': ('django.db.models.fields.CharField', [], {'default': "'en'", 'max_length': '16'}),
            'default_name': ('django.db.models.fields.CharField', [], {'max_length': '100'}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'level': ('django.db.models.fields.PositiveIntegerField', [], {'db_index': 'True'}),
            'lft': ('django.db.models.fields.PositiveIntegerField', [], {'db_index': 'True'}),
            'parent': ('mptt.fields.TreeForeignKey', [], {'blank': 'True', 'related_name': "'children'", 'null': 'True', 'to': "orm['peach3.Period']"}),
            'rght': ('django.db.models.fields.PositiveIntegerField', [], {'db_index': 'True'}),
            'slug': ('django.db.models.fields.CharField', [], {'unique': 'True', 'max_length': '8'}),
            'tree_id': ('django.db.models.fields.PositiveIntegerField', [], {'db_index': 'True'})
        },
        'peach3.profile': {
            'Meta': {'object_name': 'Profile'},
            'date_format': ('django.db.models.fields.CharField', [], {'default': "'D j M Y'", 'max_length': '16'}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'initials': ('django.db.models.fields.CharField', [], {'max_length': '30', 'blank': 'True'}),
            'language': ('django.db.models.fields.CharField', [], {'default': "''", 'max_length': '16', 'blank': 'True'}),
            'last_name_prefix': ('django.db.models.fields.CharField', [], {'max_length': '30', 'blank': 'True'}),
            'last_name_suffix': ('django.db.models.fields.CharField', [], {'max_length': '30', 'blank': 'True'}),
            'programmingLanguage': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['peach3.ProgrammingLanguage']", 'null': 'True', 'blank': 'True'}),
            'state': ('django.db.models.fields.CharField', [], {'default': "'V'", 'max_length': '1'}),
            'time_format': ('django.db.models.fields.CharField', [], {'default': "'G:i'", 'max_length': '8'}),
            'timezone_str': ('django.db.models.fields.CharField', [], {'default': "'Europe/Amsterdam'", 'max_length': '48'}),
            'titles_prefix': ('django.db.models.fields.CharField', [], {'max_length': '30', 'blank': 'True'}),
            'titles_suffix': ('django.db.models.fields.CharField', [], {'max_length': '30', 'blank': 'True'}),
            'user': ('django.db.models.fields.related.OneToOneField', [], {'to': "orm['auth.User']", 'unique': 'True'})
        },
        'peach3.programminglanguage': {
            'Meta': {'object_name': 'ProgrammingLanguage', 'db_table': "'peach3_proglang'"},
            'code': ('django.db.models.fields.CharField', [], {'max_length': '16'}),
            'default_language': ('django.db.models.fields.CharField', [], {'default': "'en'", 'max_length': '16'}),
            'default_name': ('django.db.models.fields.CharField', [], {'unique': 'True', 'max_length': '100'}),
            'enabled': ('django.db.models.fields.BooleanField', [], {'default': 'True'}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'})
        },
        'peach3.realm': {
            'Meta': {'ordering': "('default_name',)", 'object_name': 'Realm'},
            'default_language': ('django.db.models.fields.CharField', [], {'default': "'en'", 'max_length': '16'}),
            'default_name': ('django.db.models.fields.CharField', [], {'unique': 'True', 'max_length': '100'}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'site': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['sites.Site']"})
        },
        'peach3.reason': {
            'Meta': {'object_name': 'Reason'},
            'code': ('django.db.models.fields.CharField', [], {'max_length': '16', 'db_index': 'True'}),
            'default_description': ('django.db.models.fields.TextField', [], {}),
            'default_language': ('django.db.models.fields.CharField', [], {'default': "'en'", 'max_length': '16'}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'param1': ('django.db.models.fields.CharField', [], {'max_length': '16', 'blank': 'True'}),
            'param2': ('django.db.models.fields.CharField', [], {'max_length': '16', 'blank': 'True'})
        },
        'peach3.reasonaltdescription': {
            'Meta': {'unique_together': "(('reason', 'language'),)", 'object_name': 'ReasonAltDescription'},
            'description': ('django.db.models.fields.CharField', [], {'max_length': '80'}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'language': ('django.db.models.fields.CharField', [], {'max_length': '16'}),
            'reason': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['peach3.Reason']"})
        },
        'peach3.refpdfinfo': {
            'Meta': {'object_name': 'RefPDFInfo', '_ormbases': ['pdfviewer.PDFInfo']},
            'pdfinfo_ptr': ('django.db.models.fields.related.OneToOneField', [], {'to': "orm['pdfviewer.PDFInfo']", 'unique': 'True', 'primary_key': 'True'}),
            'ref_ct': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['contenttypes.ContentType']", 'null': 'True', 'blank': 'True'}),
            'ref_id': ('django.db.models.fields.PositiveIntegerField', [], {'null': 'True', 'blank': 'True'})
        },
        'peach3.report': {
            'Meta': {'object_name': 'Report'},
            'created': ('django.db.models.fields.DateTimeField', [], {'default': 'datetime.datetime.now'}),
            'file': ('django.db.models.fields.files.FileField', [], {'max_length': '300', 'null': 'True', 'blank': 'True'}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'last_access': ('django.db.models.fields.DateTimeField', [], {'default': 'datetime.datetime.now'}),
            'mimetype': ('django.db.models.fields.CharField', [], {'max_length': '50'}),
            'parameters': ('django.db.models.fields.TextField', [], {}),
            'type': ('django.db.models.fields.CharField', [], {'max_length': '12'}),
            'users': ('django.db.models.fields.related.ManyToManyField', [], {'to': "orm['auth.User']", 'symmetrical': 'False'})
        },
        'peach3.review': {
            'Meta': {'ordering': "('created',)", 'object_name': 'Review'},
            'authors': ('django.db.models.fields.related.ManyToManyField', [], {'related_name': "'review_author'", 'symmetrical': 'False', 'to': "orm['auth.User']"}),
            'created': ('django.db.models.fields.DateTimeField', [], {'default': 'datetime.datetime.now'}),
            'created_by': ('django.db.models.fields.related.ForeignKey', [], {'default': 'None', 'related_name': "'review_creator'", 'to': "orm['auth.User']"}),
            'grade': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['peach3.Grade']", 'null': 'True', 'blank': 'True'}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'reviewlevel': ('django.db.models.fields.PositiveSmallIntegerField', [], {}),
            'submission': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['peach3.Submission']"}),
            'visibilitylevel': ('django.db.models.fields.PositiveSmallIntegerField', [], {})
        },
        'peach3.secret': {
            'Meta': {'object_name': 'Secret'},
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'secret': ('django.db.models.fields.CharField', [], {'max_length': '16'}),
            'user': ('django.db.models.fields.related.OneToOneField', [], {'to': "orm['auth.User']", 'unique': 'True'})
        },
        'peach3.subcode': {
            'Meta': {'unique_together': "(('courseedition', 'subcode'),)", 'object_name': 'SubCode'},
            'courseedition': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['peach3.CourseEdition']"}),
            'default_language': ('django.db.models.fields.CharField', [], {'default': "'en'", 'max_length': '16'}),
            'default_name': ('django.db.models.fields.CharField', [], {'max_length': '100'}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'subcode': ('django.db.models.fields.SlugField', [], {'max_length': '16'})
        },
        'peach3.submission': {
            'Meta': {'ordering': "('created',)", 'object_name': 'Submission'},
            'assignmentedition': ('mptt.fields.TreeForeignKey', [], {'to': "orm['peach3.AssignmentEdition']"}),
            'authors': ('django.db.models.fields.related.ManyToManyField', [], {'to': "orm['auth.User']", 'through': "orm['peach3.SubmissionAuthor']", 'symmetrical': 'False'}),
            'clusters': ('django.db.models.fields.related.ManyToManyField', [], {'to': "orm['peach3.Cluster']", 'symmetrical': 'False'}),
            'courseedition': ('mptt.fields.TreeForeignKey', [], {'to': "orm['peach3.CourseEdition']"}),
            'created': ('django.db.models.fields.DateTimeField', [], {'default': 'datetime.datetime.now', 'db_index': 'True'}),
            'created_by': ('django.db.models.fields.related.ForeignKey', [], {'default': 'None', 'related_name': "'submission_created_set'", 'to': "orm['auth.User']"}),
            'files': ('django.db.models.fields.related.ManyToManyField', [], {'to': "orm['peach3.FileRevision']", 'through': "orm['peach3.SubmissionFile']", 'symmetrical': 'False'}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'is_group': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'language': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['peach3.ProgrammingLanguage']", 'null': 'True', 'blank': 'True'}),
            'modified': ('django.db.models.fields.DateTimeField', [], {'auto_now': 'True', 'db_index': 'True', 'blank': 'True'}),
            'submitted': ('django.db.models.fields.DateTimeField', [], {'null': 'True', 'blank': 'True'}),
            'submitted_by': ('django.db.models.fields.related.ForeignKey', [], {'blank': 'True', 'related_name': "'submission_submitted_set'", 'null': 'True', 'to': "orm['auth.User']"})
        },
        'peach3.submissionauthor': {
            'Meta': {'unique_together': "(('submission', 'author'),)", 'object_name': 'SubmissionAuthor'},
            'active': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'author': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['auth.User']"}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'latest_accepted': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'state': ('django.db.models.fields.CharField', [], {'default': "''", 'max_length': '12', 'blank': 'True'}),
            'submission': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['peach3.Submission']"})
        },
        'peach3.submissionfile': {
            'Meta': {'ordering': "('submission', 'name')", 'object_name': 'SubmissionFile'},
            'created': ('django.db.models.fields.DateTimeField', [], {'default': 'datetime.datetime.now'}),
            'created_by': ('django.db.models.fields.related.ForeignKey', [], {'default': 'None', 'to': "orm['auth.User']"}),
            'file': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['peach3.FileRevision']"}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '300'}),
            'provided_mimetype': ('django.db.models.fields.CharField', [], {'max_length': '256', 'blank': 'True'}),
            'slot': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['peach3.AssignmentSlot']", 'null': 'True', 'blank': 'True'}),
            'submission': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['peach3.Submission']"})
        },
        'peach3.translatedname': {
            'Meta': {'unique_together': "(('content_type', 'object_id', 'language'),)", 'object_name': 'TranslatedName'},
            'content_type': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['contenttypes.ContentType']"}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'language': ('django.db.models.fields.CharField', [], {'max_length': '16'}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '100'}),
            'object_id': ('django.db.models.fields.PositiveIntegerField', [], {})
        },
        'peach3.verificationcode': {
            'Meta': {'object_name': 'VerificationCode'},
            'code': ('django.db.models.fields.CharField', [], {'max_length': '8'}),
            'created': ('django.db.models.fields.DateTimeField', [], {'auto_now_add': 'True', 'blank': 'True'}),
            'expires': ('django.db.models.fields.DateTimeField', [], {'null': 'True', 'blank': 'True'}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'parameters': ('django.db.models.fields.TextField', [], {'blank': 'True'}),
            'type': ('django.db.models.fields.CharField', [], {'max_length': '1'}),
            'user': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['auth.User']"})
        },
        'sites.site': {
            'Meta': {'ordering': "('domain',)", 'object_name': 'Site', 'db_table': "'django_site'"},
            'domain': ('django.db.models.fields.CharField', [], {'max_length': '100'}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '50'})
        }
    }

    complete_apps = ['peach3']
