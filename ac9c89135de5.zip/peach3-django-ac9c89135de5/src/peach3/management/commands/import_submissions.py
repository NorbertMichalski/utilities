from peach3.core.user import AlternativeNames
from peach3.models import AssignmentEdition
from peach3.models import FileRevision, Submission, SubmissionAuthor

from django.contrib.auth import get_user_model
from django.core.management.base import BaseCommand, CommandError
from django.db import transaction
from django.core.files import File
from django.utils import timezone

from datetime import datetime
from optparse import make_option
import os, os.path, re #@UnusedImport

# Regular expression to match valid timestamps.
TIMESTAMP_RE = re.compile(r'(?:\b|_)(20\d\d)(0[1-9]|1[0-2])(0[1-9]|[12]\d|3[01])'
                          r'([01]\d|2[0-3])([0-5]\d)([0-5]\d)(?=\b|_)')

@transaction.commit_on_success
def import_submission(stdout, path, ae, users, timestamp=None, dry_run=False):
    """ Import submision files in 'path' for given users
        Submission date is set to timestamp (in UTC)
    """

    timestamp_provided = timestamp is not None
    if not timestamp_provided:
        timestamp = timezone.now()
    elif not timezone.is_aware(timestamp):
        timestamp = timezone.make_aware(timestamp, timezone.utc)

    stdout.write("(-)   Users: %s\n" % ', '.join(user.username for user in users))
    stdout.write("(-)   Timestamp: %s%s\n" % (timestamp, '' if timestamp_provided else ' (current time)'))

    sb = None
    stdout.write("(-)   Files:\n")
    for filename in os.listdir(path):
        filepath = os.path.join(path, filename)
        if os.path.isfile(filepath):
            stdout.write("(-)     %s\n" % filename)

            if (not dry_run) and sb is None:
                sb = Submission.objects.create(courseedition=ae.courseedition,
                                               assignmentedition=ae,
                                               created=timestamp,
                                               created_by=users[0],
                                              )
                sb.add_author(*users)

            if sb:
                nfr = FileRevision.objects.get_or_create_for_upload(
                    File(file(filepath), filename),
                    ae
                )[0]

                obj, created = sb.submissionfile_set.get_or_create(name=filename,
                                                                   defaults={
                                                                       'file': nfr,
                                                                       'created_by': users[0],
                                                                   })
                if not created:
                    obj.file = nfr
                    obj.created_by = users[0]
                    obj.save(update_fields=['file', 'created_by'])

    if sb:
        # Finalize submission
        sb.submit(timestamp, None)
        stdout.write("(*) Submission created\n")

    elif dry_run:
        stdout.write("(!) Dry-run: Submission not created\n")

    else:
        stdout.write("(!) No files: Submission not created\n")

class Command(BaseCommand):
    option_list = BaseCommand.option_list + (
        make_option('-a', '--assignmentedition',
                    type='int',
                    action='store',
                    dest='aeid',
                    help='(Required) The assignment edition id to import the submissions into.'
                   ),
        make_option('-u', '--user',
                    action='append',
                    dest='users',
                    help='(Repeatable) Username of user to import submission for. '
                         'Can be a list of users (comma separated). '
                         'If not supplied this will be inferred from the pathnames.'
                   ),
        make_option('--dry-run',
                    action='store_true',
                    dest='dry_run',
                    default=False,
                    help='Do not actually import submissions, just show what will be imported.'
                   ),
        make_option('--ignore-timestamp',
                    action='store_true',
                    dest='ignore_timestamp',
                    default=False,
                    help='Ignore timestamps in directory names, always set created time to current time.'
                   ),
    )
    args = 'directory_to_import'
    help = "Import submissions into database."

    def handle(self, path='', *args, **options):
        stdout = self.stdout
        User = get_user_model()

        if not path or args:
            raise CommandError('Usage is import_submissions %s' % self.args)

        if not os.path.isdir(path):
            raise CommandError('Path %r does not exist or isn\'t a directory' % path)

        aeid = options.get('aeid')
        if not aeid:
            raise CommandError('Required option --assignmentedition missing')

        try:
            ae = AssignmentEdition.objects.get(pk=aeid)
        except AssignmentEdition.DoesNotExist:
            raise CommandError('Invalid assignmentedition id')

        stdout.write("(*) Assignment: %s\n" % ae)

        users_option = options.get('users')
        users = []

        if users_option:
            for username in users_option:
                if ',' in username:
                    usernames = username.split(',')
                else:
                    usernames = [username]

                for username in usernames:
                    try:
                        user = User.objects.get(username=username)
                    except User.DoesNotExist:
                        raise CommandError('Unknown user "%s"' % username)

                    users.append(user)

            self._handle_path(path, ae, users, options)

        else:
            altNameConverter = AlternativeNames()

            all_usernames = list(User.objects.filter(clustermember__cluster__courseedition=ae.courseedition)\
                                             .values_list('username', flat=True))

            alt_names = []
            for username in all_usernames:
                alt_names.extend(altNameConverter.get_alternative_names(username))
            all_usernames.extend(alt_names)

            expr = ur'(?:\b|_)(%s)(?=\b|_)' % ('|'.join(all_usernames))

            name_re = re.compile(expr, re.U)

            subdirs = os.listdir(path)

            matches = 0
            for subdir in subdirs:
                subpath = os.path.join(path, subdir)
                if not subdir.startswith('.') and os.path.isdir(subpath):
                    names = name_re.findall(subdir)
                    if names:
                        stdout.write("(*) Importing directory %r\n' % subdir")
                        stdout.write("(.)  Detected users: ")

                        usernames = []
                        for num, name in enumerate(names):
                            s = name

                            alts = altNameConverter.get_usernames_from_alternative(name)
                            if alts:
                                username = alts[0]
                                s += '=>'+username
                            else:
                                username = None

                            usernames.append(username or name)

                            if num<len(names)-1:
                                stdout.write(s+', ')
                            else:
                                stdout.write(s+'\n')

                        users = User.objects.filter(username__in=usernames)
                        self._handle_path(subpath, ae, users, options)
                        matches += 1

                    else:
                        stdout.write("(!) No valid user names detected in directory name %r\n" % subdir)

            stdout.write("%d directories matched and imported\n" % matches)

    def _handle_path(self, path, ae, users, options): #pylint: disable=R0201
        # Analyze layout of submission folder:
        #  1) immediate: all submission files in 'path'
        #  2) date subdirs: 'path' contains sub-folders with timestamp YYYYMMDDHHMMSS
        dry_run = options.get('dry_run', False)
        ignore_timestamp = options.get('ignore_timestamp', False)

        subdirs = os.listdir(path)

        has_stamps = False
        for subdir in subdirs:
            subpath = os.path.join(path, subdir)

            if os.path.isdir(subpath):
                m = TIMESTAMP_RE.search(subdir)
                if m:
                    has_stamps = True
                    self.stdout.write("(*)  Importing time-stamped directory %r\n" % subdir)

                    if not ignore_timestamp:
                        timestamp = datetime(*map(int, m.groups()))
                    else:
                        timestamp = None

                    import_submission(self.stdout, subpath, ae, users, timestamp, dry_run)

        if not has_stamps:
            timestamp = None
            if not ignore_timestamp:
                m = TIMESTAMP_RE.search(path)
                if m:
                    timestamp = datetime(*map(int, m.groups()))

            import_submission(self.stdout, path, ae, users, timestamp, dry_run)
