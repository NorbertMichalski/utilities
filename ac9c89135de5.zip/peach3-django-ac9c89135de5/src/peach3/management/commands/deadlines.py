""" This file is part of PEACH.

    Copyright (C) 2006-2009 Eindhoven University of Technology
"""
from django.core.management.base import NoArgsCommand


class Command(NoArgsCommand):
    help = "Print upcoming deadlines."

    def handle_noargs(self, **options):
        from peach3.core.stats import get_deadlines

        self.stdout.write(get_deadlines().encode('utf-8')+"\n")
