from django.contrib.auth import get_user_model
from django.core.management.base import BaseCommand, CommandError
from django.db import transaction
from django.db.models import ObjectDoesNotExist

from peach3.models import CourseEdition, Cluster, ClusterMember, Realm

from optparse import make_option
import os, os.path #@UnusedImport

def get_cluster_by_name_or_id(name):
    try:
        clusterid = int(name)
    except ValueError:
        cluster = Cluster.objects.get(default_name__iexact=name)
    else:
        cluster = Cluster.objects.get(pk=clusterid)

    return cluster

def get_realm_by_name_or_id(name):
    try:
        realmid = int(name)
    except ValueError:
        realm = Realm.objects.get(default_name__iexact=name)
    else:
        realm = Realm.objects.get(pk=realmid)

    return realm

def get_subcode_by_name(ce, code):
    return ce.subcode_set.get(subcode__iexact=code)

class Command(BaseCommand):
    option_list = BaseCommand.option_list + (
        make_option('-c', '--course',
                    type='int',
                    action='store',
                    dest='ceid',
                    help='(Required) The course id to import the users into.',
                   ),
        make_option('--dialect',
                    type='string',
                    action='store',
                    dest='csv_dialect',
                    default=None,
                    help='The csv dialect (see http://docs.python.org/2/library/csv.html#csv.Dialect).',
                   ),
        make_option('--source',
                    action='store',
                    dest='source',
                    default='staff',
                    help='The "source" of this import (%s)' % ', '.join(
                        '"%s"' % source[0]
                        for source in ClusterMember.SOURCE_CHOICES
                        if source[0]
                    ),
                   ),
        make_option('--realm',
                    action='store',
                    dest='realm',
                    default=None,
                    help="Default realm, if not provided. (Required if any user's realm is unknown)",
                   ),
        make_option('--subcode',
                    action='store',
                    dest='subcode',
                    default=None,
                    help="Default sub code, if not provided. "
                         "(Required if any user's sub code is unknown, and the course has sub codes)",
                   ),
        make_option('--template-cluster',
                    action='store',
                    dest='cluster',
                    default=None,
                    help="If any of clusters doesn't exist yet, use this cluster as a template to create it.",
                   ),
        make_option('--dry-run',
                    action='store_true',
                    dest='dry_run',
                    default=False,
                    help='Do not actually import users, just show what will be done.',
                   ),
    )
    args = 'cvs_file'
    help = """ Import (or rearrange) users into clusters. Input is a cvs file with the following layout:

username,clustername/id,realmname/id,subcode

If clustername/id is empty, user is assigned a random cluster.
If realmname/id is empty, existing users realm is not changed. If a user is new, the default realm will be used.
If subcode is empty, existing users subcode is not changed. If a user is new, the default subcode will be used.
"""

    @transaction.commit_on_success
    def handle(self, path='', *args, **options): #pylint: disable=R0912,R0914,R0915
        import csv

        if not path or args:
            raise CommandError('Usage is import_users %s' % self.args)
        elif not os.path.exists(path):
            raise CommandError('File %r does not exist' % path)

        ceid = options.get('ceid')
        if not ceid:
            raise CommandError('Required option --course missing')

        try:
            ce = CourseEdition.objects.get(pk=ceid)
        except CourseEdition.DoesNotExist:
            raise CommandError('Invalid course id')

        self.stdout.write("--- Course: %s %s\n" % (ce.code, ce.name))

        parsed = []
        clusters = {}
        users = {}
        new_clusters = []
        new_cluster_subcodes = {}
        default_realm = None
        default_subcode = None
        has_subcodes = ce.subcode_set.exists()

        with file(path, 'rb') as csvfile:
            dialect = options.get('csv_dialect')
            if not dialect:
                dialect = csv.Sniffer().sniff(csvfile.read(1024))
                csvfile.seek(0)
                self.stdout.write("--- Sniffed csv dialect: %s\n" % dialect)
            else:
                self.stdout.write("--- Provided csv dialect: %s\n" % dialect)

            reader = csv.reader(csvfile, dialect=dialect)
            for line, row in enumerate(reader):
                username = row[0]
                if len(row)<2 and line>0:
                    self.stdout.write("Warning: Line %d too short, ignored\n" % line+1)
                    continue

                if username.lower() in users:
                    self.stdout.write("Warning: Line %d: Duplicate user '%s' ignored\n" % (line+1, username))
                    continue

                User = get_user_model()
                try:
                    user = User.objects.get(username__iexact=username)
                except User.DoesNotExist:
                    if line>0:
                        self.stdout.write("Warning: Line %d: User '%s' not found\n" % (line+1, username))
                    continue

                users[username.lower()] = user

                try:
                    clm = ClusterMember.objects.get(cluster__courseedition=ce, user=user)
                except ClusterMember.DoesNotExist:
                    clm = None

                clustername = row[1]
                cluster = clusters.get(clustername.lower())

                if not cluster:
                    try:
                        cluster = get_cluster_by_name_or_id(clustername)
                    except ObjectDoesNotExist:
                        self.stdout.write("--- New cluster: %s\n" % clustername)
                        cluster = True
                        new_clusters.append(clustername)

                    clusters[clustername.lower()] = cluster

                if len(row)>2 and row[2]:
                    try:
                        realm = get_realm_by_name_or_id(row[2])
                    except ObjectDoesNotExist:
                        raise CommandError('Line %d: Unknown realm: %s' % (line+1, row[2]))

                elif clm:
                    realm = clm.realm

                elif default_realm:
                    realm = default_realm

                else:
                    realmname = options.get('realm')
                    if realmname is None:
                        raise CommandError("Default realm not provided")

                    try:
                        realm = get_realm_by_name_or_id(realmname)
                    except ObjectDoesNotExist:
                        raise CommandError('Default realm not found: %s' % (realmname))

                    default_realm = realm

                if has_subcodes:
                    if len(row)>3 and row[3]:
                        try:
                            subcode = get_subcode_by_name(ce, row[3])
                        except ObjectDoesNotExist:
                            raise CommandError('Line %d: Unknown subcode: %s' % (line+1, row[3]))

                    elif clm:
                        subcode = clm.subcode

                    elif default_subcode:
                        subcode = default_subcode

                    else:
                        subcode_name = options.get('subcode')
                        if subcode_name is None:
                            raise CommandError("Default sub code not provided")

                        try:
                            subcode = get_subcode_by_name(ce, subcode_name)
                        except ObjectDoesNotExist:
                            raise CommandError('Default sub code not found: %s' % (subcode_name))

                        default_subcode = subcode

                    if cluster is True and subcode.pk not in new_cluster_subcodes:
                        new_cluster_subcodes[subcode.pk] = subcode

                else:
                    if len(row)>3 and row[3]:
                        self.stdout.write("Line %d: Sub code ignored (course has no sub codes)\n" % (line+1))
                    subcode = None

                parsed.append((user, clm, clustername, realm, subcode))

            dry_run = options.get('dry_run')

            # Create new clusters
            if new_clusters:
                clustername = options.get('cluster')
                if clustername is None:
                    raise CommandError('Need to make new clusters, but --template-cluster option not set')

                try:
                    cluster = get_cluster_by_name_or_id(clustername)
                except ObjectDoesNotExist:
                    raise CommandError('Template cluster "%s" does not exist' % clustername)

                if not dry_run:
                    for clustername in new_clusters:
                        clusters[clustername.lower()] =  Cluster.objects.clone_from(
                            cluster,
                            default_name=clustername,
                            subcodes=new_cluster_subcodes.values()
                        )

            source = options.get('source')
            for user, clm, clustername, realm, subcode in parsed:
                s = ' * User %s:' % (user.username)

                new_cluster = clusters.get(clustername.lower())
                if clm:
                    old_cluster = clm.cluster
                    s += ' %s =>' % old_cluster.default_name
                    if not dry_run:
                        old_cluster.move_member(user, new_cluster, realm, subcode, source)

                else:
                    s += ' (NEW)'
                    if not dry_run:
                        new_cluster.add_member(source, user, realm, subcode)

                s += ' %s (Realm: %s' % (clustername, realm.default_name)

                if subcode:
                    s+= ', Subcode: %s' % subcode.subcode

                s += ')\n'
                self.stdout.write(s)
