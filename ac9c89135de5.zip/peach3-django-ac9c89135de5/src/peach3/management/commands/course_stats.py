from django.core.management.base import BaseCommand
from django.db import transaction
from django.utils import six

from peach3.core.stats import course_stats, assignment_stats
from peach3.models import CourseEdition

from optparse import make_option

from collections import defaultdict
import itertools

class Command(BaseCommand):
    option_list = BaseCommand.option_list + (
        make_option('-p', '--period',
                    type='string',
                    action='store',
                    dest='period',
                    help='The period (slug) to report.',
        ),
        make_option('-c', '--course',
                    type='string',
                    action='store',
                    dest='course',
                    help='The course code to report.',
                   ),
    )

    @transaction.commit_on_success
    def handle(self, *args, **options): #pylint: disable=R0912,R0914,R0915
        courses = CourseEdition.objects.all()

        period_filter = options.get('period')
        if period_filter:
            courses = courses.filter(period__slug=period_filter)

        course_filter = options.get('course')
        if course_filter:
            courses = courses.filter(code=course_filter)

        six.print_('Course,Assignment,# Staff,# Members,# Submissions,# Peer reviews')

        for ce in courses.order_by('code'):
            six.print_('"{0}",,{1[staff]},{1[members]},{1[submissions]},{1[peerreviews]}'.format(ce, course_stats(ce)))

            for ae in ce.assignmentedition_set.order_by('order'):
                # Using defaultdict() to return an empty string for missing elements in the stats
                stats = defaultdict(itertools.repeat('').next)
                stats.update(assignment_stats(ae))

                six.print_(',"{0}",,{1[members]},{1[submissions]},{1[peerreviews]}'.format(ae, stats))

            six.print_('')
