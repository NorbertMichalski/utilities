from django import dispatch
from django.conf import settings
from django.db.models import get_models
from django.db.models.signals import post_syncdb
import django.contrib.auth.models

from south.signals import post_migrate

import peach3.models

@dispatch.receiver(post_migrate, dispatch_uid = "peach3.management.setup_validators")
@dispatch.receiver(post_syncdb, dispatch_uid = "peach3.management.setup_validators",
                   sender = peach3.models)
def setup_validators(app, **kwargs): #pylint: disable=W0613
    from peach3.core.validator import FILE_VALIDATORS
    from peach3.models.files import import_by_string, FileValidator

    # For 'post_migrate' app is 'peach3', for 'post_syncdb', app is peach3.models
    if app=='peach3' or app==peach3.models:
        print 'Syncing file validator models:'

        validators, added = 0, 0
        for validator_cls_name in FILE_VALIDATORS+getattr(settings, 'FILE_VALIDATORS', []):
            validator_cls = import_by_string(validator_cls_name)
            created = FileValidator.objects.get_or_create(
                name = validator_cls.NAME,
                validator = validator_cls_name,
            )[1]

            validators += 1
            if created:
                added += 1
                print ' - Added', validator_cls_name

        print '%d FileValidator(s) installed (%d new)' % (validators, added)

@dispatch.receiver(post_syncdb, dispatch_uid = "peach3.management.setup_managers_group",
                   sender = django.contrib.auth.models)
def setup_setup_managers_group(app, **kwargs): #pylint: disable=W0613
    " Create a group named 'Managers' if it does not already exist "
    from django.contrib.auth.models import Group

    Group.objects.get_or_create(name='Managers')
