""" This file is part of PEACH.

    Copyright (C) 2006-2009 Eindhoven University of Technology
"""
from django.contrib import admin
from django.forms.models import modelform_factory

from peach3.models.flag import * #@UnusedWildImport pylint: disable=W0401,W0614
from peach3.admin.forms import I18NModelForm

__all__ = ('FlagAdmin',)

class FlagAdmin(admin.ModelAdmin): #pylint: disable=R0904
    form = modelform_factory(Flag, I18NModelForm)
    fields = 'i18n_names',
admin.site.register(Flag, FlagAdmin)
