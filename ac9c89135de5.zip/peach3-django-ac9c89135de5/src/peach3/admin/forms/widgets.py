from django import forms
from django.contrib.admin.templatetags.admin_static import static
from django.contrib.admin.widgets import AdminSplitDateTime
from django.template.loader import render_to_string
from django.utils.html import escape
from django.utils.safestring import mark_safe
from django.utils.text import Truncator
from django.utils.translation import ugettext as _

from peach3.core.rst.writers import html4css1
from peach3.forms.widgets import TimeRangeWidget

__all__ = ('AdminNewsItemMessage', 'AdminImmutableUser', 'AdminTimeRange')


class AdminNewsItemMessage(forms.HiddenInput):
    def render(self, name, value, attrs=None):
        from peach3.models.news import NewsItem

        html = super(AdminNewsItemMessage, self).render(name, '', attrs)
        if isinstance(value, NewsItem) and value.pk:
            subject, body, link = value.get_message(writer=html4css1.AdminWriter)
            return html + render_to_string('peach3/admin/news-item-widget.html', {
                'subject': subject,
                'body': body,
                'link': link,
            })

        return html

class AdminImmutableUser(forms.HiddenInput):
    def render(self, name, value, attrs=None):
        output = [super(AdminImmutableUser, self).render(name, value, attrs)]

        if value:
            output.append(self.label_for_value(value))

        return mark_safe(''.join(output))

    def label_for_value(self, value): #pylint: disable=R0201
        from django.contrib.auth import get_user_model

        User = get_user_model()
        try:
            user = User.objects.get(pk=value)
        except User.DoesNotExist:
            return ''

        return '<strong>%s</strong>' % escape(Truncator(user).words(14, truncate='...'))

class AdminSplitDateTimeFrom(AdminSplitDateTime):
    def format_output(self, rendered_widgets):
        return mark_safe(u'<p class="datetime timerange-from">%s %s<br/>%s %s</p>' % \
            (_('Date from:'), rendered_widgets[0], _('Time from:'), rendered_widgets[1]))

class AdminSplitDateTimeUntil(AdminSplitDateTime):
    def format_output(self, rendered_widgets):
        return mark_safe(u'<p class="datetime timerange-until">%s %s<br/>%s %s</p>' % \
            (_('Date until:'), rendered_widgets[0], _('Time until:'), rendered_widgets[1]))

class AdminTimeRange(TimeRangeWidget):
    def __init__(self, attrs=None):
        widgets = (forms.Select, AdminSplitDateTimeFrom, AdminSplitDateTimeUntil)
        super(AdminTimeRange, self).__init__(widgets, attrs)

    @property
    def media(self):
        js = ['TimeRange.js']
        css = ['TimeRange.css']
        media = forms.Media(js=[static('peach3/admin/js/%s' % path) for path in js],
                            css={'screen':[static('peach3/admin/css/%s' % path) for path in css]})
        for widget in self.widgets:
            media += widget.media
        return media

    def format_output(self, rendered_widgets):
        return mark_safe(u'<div class="timerange">%s<div class="timerange-range">%s%s</div></div>'
                                % tuple(rendered_widgets))
