from django.forms.models import BaseInlineFormSet

class BaseInlineFormSetWithParentInstance(BaseInlineFormSet): #pylint: disable=R0924
    " Forms in this FormSet get an additional parameter `parent_instance` during construction "

    def _construct_form(self, i, **kwargs):
        return super(BaseInlineFormSetWithParentInstance, self)._construct_form(i, parent_instance=self.instance,
                                                                                **kwargs)  #pylint: disable=W0212

    @property
    def empty_form(self):
        form = self.form(
            parent_instance=self.instance,
            auto_id=self.auto_id,
            prefix=self.add_prefix('__prefix__'),
            empty_permitted=True,
        )
        self.add_fields(form, None)
        return form
