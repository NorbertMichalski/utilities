from django import forms
from django.core.exceptions import ValidationError
from django.utils.translation import ugettext_lazy, ugettext as _

from peach3.admin.forms.widgets import AdminImmutableUser

__all__ = ('I18NModelForm', 'AdminImmutableUserModelForm',)

class I18NModelForm(forms.ModelForm): #pylint: disable=R0924
    """ A ModelForm for models based on peach3.models.i18n.I18NModel
        This adds a field 'i18n_names' to the available form fields that
        allows editing of the default name and all translated names.

        Example usage, for a class XYZ subclassing from I18NModel:

            from django.forms.models import modelform_factory
            from peach3.admin.i18n import I18NModelForm

            class XYZAdmin(ModelAdmin):
                form = modelform_factory(XYZ, I18NModelForm)
                fields = 'i18n_names', ...
            admin.site.register(XYZ, XYZAdmin)

            class XYZInline(TabularInline):
                form = modelform_factory(XYZ, I18NModelForm)
                model = XYZ
    """
    i18n_names = forms.CharField(label=ugettext_lazy("Name"), widget=forms.Textarea(), required=True)

    def __init__(self, *arg, **kwargs):
        super(I18NModelForm, self).__init__(*arg, **kwargs)
        self.initial['i18n_names'] = self.instance.get_all_names()

        # If the 'default_name' field of the model can be blank, the 'i18n_names' form field
        # is not required
        for field in self._meta.model._meta.fields: #pylint: disable=W0212
            if field.name=='default_name':
                self.fields['i18n_names'].required = not field.blank
                break

    def clean_i18n_names(self):
        from peach3.models.i18n import parse_names

        data = self.cleaned_data['i18n_names']

        try:
            names, lang = parse_names(data)
        except ValueError, e:
            raise ValidationError(str(e))

        if self.fields['i18n_names'].required and not names.get(lang):
            raise ValidationError(_("At least one name is required"))

        return data

    def save(self, commit=True):
        r = super(I18NModelForm, self).save(commit)
        self.instance.set_all_names(self.cleaned_data['i18n_names'])
        return r


class AdminImmutableUserModelForm(forms.ModelForm): #pylint: disable=R0924
    def __init__(self, *args, **kwargs):
        super(AdminImmutableUserModelForm, self).__init__(*args, **kwargs)

        # Make the user field Immutable for existing objects
        if self.instance and self.instance.pk:
            self.fields['user'].widget = AdminImmutableUser()

    def clean_user(self):
        # Make sure the user cannot be modified by hacking the hidden field
        if self.instance and self.instance.pk and self.instance.user:
            return self.instance.user

        return self.cleaned_data['user']

