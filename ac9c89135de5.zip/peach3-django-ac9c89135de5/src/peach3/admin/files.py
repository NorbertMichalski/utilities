""" This file is part of PEACH.

    Copyright (C) 2006-2009 Eindhoven University of Technology
"""
from django.contrib import admin
from django.forms.models import modelform_factory

from peach3.models.files import * #@UnusedWildImport pylint: disable=W0401,W0614

from peach3.admin.forms import I18NModelForm

__all__ = ('FileValidatorAdmin', 'FileTypeAdmin',)

class FileValidatorAdmin(admin.ModelAdmin): #pylint: disable=R0904
    list_display = 'name', 'validator',
    ordering = 'name',
admin.site.register(FileValidator, FileValidatorAdmin)

class FileTypeAdmin(admin.ModelAdmin): #pylint: disable=R0904
    #filter_horizontal = 'validators',
    form = modelform_factory(FileType, I18NModelForm)

    fields = ('i18n_names', 'lexer', 'lexer_parameters',
              'binary_content', 'base_type',
              'namepatterns', 'mimetypes',
              'validators',
              'iconcls')

    list_display = 'default_name', 'base_type',
    ordering = 'default_name',

    filter_horizontal = 'validators',
admin.site.register(FileType, FileTypeAdmin)

class FileRevisionInline(admin.TabularInline):
    model = FileRevision
    raw_id_fields = 'created_by',
    date_hierarchy = 'created'
    ordering = 'created',
    extra = 1

#class FileAdmin(admin.ModelAdmin):
#    inlines = FileRevisionInline,
#admin.site.register(File, FileAdmin)
