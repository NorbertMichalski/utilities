""" This file is part of PEACH.

    Copyright (C) 2006-2012 Eindhoven University of Technology
"""
from django.contrib import admin
from django.contrib.admin import SimpleListFilter
from django.forms.models import ModelForm
from django.utils.html import format_html
from django.utils.safestring import mark_safe
from django.utils.translation import ugettext_lazy as _, ugettext

from peach3.admin.forms.formsets import BaseInlineFormSetWithParentInstance
from peach3.admin.forms.widgets import AdminTimeRange
from peach3.forms import TimeRangeField
from peach3.models import AssignmentEdition, CourseEdition
from peach3.models.peerreview import *


def _user_list(users):
    return ', '.join(u.get_full_name() for u in users)


class PeerReviewResultVisibleTimeRangeField(TimeRangeField):
    " A TimeRangeField with the 'Always' option renamed to 'Immediately' "
    CHOICES = (
        (TimeRangeField.CHOICE_NEVER, TimeRangeField.CHOICES[0][1]),
        (TimeRangeField.CHOICE_ALWAYS, _("Immediately")),
        (TimeRangeField.CHOICE_RANGE, TimeRangeField.CHOICES[2][1]),
    )


class PeerReviewAssignmentInlineForm(ModelForm): #pylint: disable=R0924
    """
    Adjusted form that only allows to choose from assignments that are in the same course
    """
    #pylint: disable=W0212

    review_result_visible_range = PeerReviewResultVisibleTimeRangeField(
        widget=AdminTimeRange,
        label=_("Review result visible")
    )

    review_rating_enabled_range = PeerReviewResultVisibleTimeRangeField(
        widget=AdminTimeRange,
        label=_("Review rating enabled")
    )

    def __init__(self, parent_instance, *args, **kwargs):
        super(PeerReviewAssignmentInlineForm, self).__init__(*args, **kwargs)
        self.fields['original_assignment'].queryset = \
            AssignmentEdition.objects.filter(courseedition=parent_instance.courseedition)
        self.fields['review_result_visible_range'].initial = self.instance.review_result_visible_range
        self.fields['review_rating_enabled_range'].initial = self.instance.review_rating_enabled_range

    def _post_clean(self):
        if 'review_result_visible_range' in self.cleaned_data:
            self.instance.review_result_visible_range = self.cleaned_data['review_result_visible_range']
        if 'review_rating_enabled_range' in self.cleaned_data:
            self.instance.review_rating_enabled_range = self.cleaned_data['review_rating_enabled_range']

        super(PeerReviewAssignmentInlineForm, self)._post_clean()

    class Meta: #pylint: disable=W0232,C0111,R0903
        model = PeerReviewAssignment


class PeerReviewAssignmentInline(admin.StackedInline):
    model = PeerReviewAssignment
    fk_name = 'review_assignment'

    formset = BaseInlineFormSetWithParentInstance
    form = PeerReviewAssignmentInlineForm

    fieldsets = (
        (None, {
            'fields': ('original_assignment', 'bundle_size', 'reviewed_by_group',)
        }),
        (_("Review options: Reporting"), {
            'description': _("With reporting enabled, a peer reviewer can enter a free-text review, "
                             "or upload a file containing the review."),
            'classes': ('collapse',),
            'fields': ('reporting', 'reporting_type',)
        }),
        (_("Review options: Ranking"), {
            'description': _("With ranking enabled, a peer reviewer ranks the submissions in a specific "
                             "order."),
            'classes': ('collapse',),
            'fields': ('ranking', 'ranking_max_equal_groups', 'ranking_max_equal_group_size',)
        }),
        (_("Review options: Grading"), {
            'description': _("With grading enabled, a peer reviewer grades each submission with a "
                             "specific grade."),
            'classes': ('collapse',),
            'fields': ('grading', 'submission_gradingsystem',)
        }),
        (_("Review options: Self-Review"), {
            'description': _("Reviewing of ones own submission"),
            'classes': ('collapse',),
            'fields': ('self_review', 'self_reporting',)
        }),
        (_("Review options: Flagging"), {
            'classes': ('collapse',),
            'fields': ('submission_flags',)
        }),
        (_("Feedback options: When and what"), {
            'description': _("With feedback enabled, the original author receives the "
                             "peer reviews for their submission. Each type of peer review "
                             "feedback can be separately enabled"),
            'classes': ('collapse',),
            'fields': ('review_result_visible_range',
                       'feedback_report',
                       'feedback_grade',
                       'feedback_rank',
                      )
        }),
        (_("Feedback options: Rating"), {
            'description': _("Rating allows the original author to rate (grade or flag) the "
                             "peer reviews for their submission"),
            'classes': ('collapse',),
            'fields': ('review_rating_enabled_range',
                       'review_gradingsystem',
                       'review_grades_distributed_min',
                       'review_grades_distributed_max',
                       'review_grades_required',
                       'review_grades_unique',
                       'review_flags',
            )
        }),
    )

    filter_horizontal = 'submission_gradingsystem', 'review_gradingsystem', 'submission_flags', 'review_flags'


class BooleanFilter(SimpleListFilter):
    def lookups(self, request, model_admin):
        return (
            ('yes', self.yes_label),
            ('no', self.no_label),
        )

    def queryset(self, request, queryset):
        value = self.value()

        if value:
            q = {
                self.parameter_name + '__isnull': value == 'no'
            }
            return queryset.filter(**q)

        return queryset


class ReviewListFilter(BooleanFilter):
    parameter_name = 'review'
    title = _("review status")
    yes_label = _("Reviewed")
    no_label = _("Not reviewed")


class GradeListFilter(BooleanFilter):
    yes_label = _("Graded")
    no_label = _("Not graded")


class SubmissionGradeListFilter(GradeListFilter):
    parameter_name = 'submission_grade'
    title = _("submission grade")


class ReviewGradeListFilter(GradeListFilter):
    parameter_name = 'review_grade'
    title = _("review grade")


class FlagListFilter(BooleanFilter):
    yes_label = _("Flagged")
    no_label = _("Not flagged")


class SubmissionFlagListFilter(FlagListFilter):
    parameter_name = 'submission_flag'
    title = _("submission flag")


class ReviewFlagListFilter(FlagListFilter):
    parameter_name = 'review_flags'
    title = _("review flag")


class CourseEditionListFilter(SimpleListFilter):
    """ A ListFilter that will only list course editions the current user can manage
    """
    title = _("course edition")

    parameter_name = 'courseedition'

    query_filter_parameter = 'bundle__assignment__review_assignment__courseedition'

    def lookups(self, request, model_admin):
        user = request.user

        query = CourseEdition.objects

        if not user.is_superuser:
            query = query.filter(managers=user)

        for ce in query.distinct():
            yield (ce.pk, unicode(ce))

    def queryset(self, request, queryset):
        value = self.value()
        if value:
            q = {self.query_filter_parameter: value}
            return queryset.filter(**q)
        return queryset


class PeerReviewAssignmentListFilter(SimpleListFilter):
    """ A ListFilter that will only list peer review assignments the current user can manage
    """
    title = _("peer review assignment")

    parameter_name = 'assignment'

    query_filter_parameter = 'bundle__assignment'

    def lookups(self, request, model_admin):
        user = request.user

        query = PeerReviewAssignment.objects

        if not user.is_superuser:
            query = query.filter(review_assignment__courseedition__managers=user)

        # If the user filtered on courseedition, limit this lookup to assignments for that course edition
        courseedition_id = request.REQUEST.get('courseedition')
        if courseedition_id:
            query = query.filter(review_assignment__courseedition__id__exact=courseedition_id)

        for pra in query.distinct():
            yield (pra.pk, unicode(pra))

    def queryset(self, request, queryset):
        value = self.value()
        if value:
            q = {self.query_filter_parameter: value}
            return queryset.filter(**q)
        return queryset


class PeerReviewAdmin(admin.ModelAdmin): #pylint: disable=R0904
    fields = ('bundle', 'identifier', 'get_submission_link',
              'reviewed_by', 'reviewed_on',
              'review', 'rank',
              'submission_grade', 'get_submission_flag_details',
              'get_review_grade', 'get_review_flag_details')
    readonly_fields = ('bundle', 'identifier', 'get_submission_link',
                       'reviewed_by', 'reviewed_on',
                       'review', 'rank',
                       'submission_grade', 'get_submission_flag_details',
                       'get_review_grade', 'get_review_flag_details')
    list_display = ('bundle', 'identifier', 'being_reviewed', 'review_status',
                    'submission_grade', 'get_submission_flag',
                    'get_review_grade', 'get_review_flag')
    list_filter = (ReviewListFilter,
                   SubmissionGradeListFilter, SubmissionFlagListFilter,
                   ReviewGradeListFilter, ReviewFlagListFilter,
                   CourseEditionListFilter,
                   PeerReviewAssignmentListFilter)
    search_fields = ['bundle__assignment__original_assignment__default_name',
                     'bundle__assignment__review_assignment__default_name',
                     'bundle__reviewer__last_name',
                     'submission__authors__last_name',
                    ]

    #pylint: disable=R0201
    def being_reviewed(self, peerreview):
        return _user_list(peerreview.submission.authors.all())

    def get_submission_flag(self, obj, detail=False):
        if not obj.submission_flag:
            return None

        if detail:
            comment = obj.submission_flag.get_comment()
        else:
            comment = None

        if comment:
            return format_html('<dl><dt><span style="color:red">{0}</span></dt><dd>{1}</dd></dl>',
                               obj.submission_flag.flag.name,
                               mark_safe(comment))
        else:
            return format_html('<span style="color:red">{0}</span>',
                               obj.submission_flag.flag.name)

    get_submission_flag.short_description = "Submission flag"
    get_submission_flag.allow_tags = True

    def get_submission_flag_details(self, obj):
        return self.get_submission_flag(obj, True)

    get_submission_flag_details.short_description = "Submission flag"
    get_submission_flag_details.allow_tags = True

    def get_submission_link(self, obj):
        return format_html('<a href="{0}">{1}</a>',
                           obj.submission.get_absolute_url(),
                           str(obj.submission))

    get_submission_link.short_description = "Submission"
    get_submission_link.allow_tags = True

    def get_review_grade(self, obj):
        try:
            return unicode(obj.get_review_grade())
        except PeerReviewGrade.DoesNotExist:
            return None

    get_review_grade.short_description = "Review grade"

    def get_review_flag(self, obj, detail=False):
        flagged_objects = list(obj.review_flags.all())
        if not flagged_objects:
            return None

        flag_names = []
        comments_by_flag = {}
        for flagged_object in flagged_objects:
            flag = flagged_object.flag
            if flag.id not in comments_by_flag:
                comments_by_flag[flag.id] = []
                flag_names.append((flag.name, flag.id))

            if detail:
                comment = flagged_object.get_comment()
                if comment:
                    comments_by_flag[flag.id].append(comment)

        flag_names.sort()

        if detail:
            return '<dl>'+''.join(
                (format_html('<dt><span style="color:red">{0}</span></dt>', flag[0])
                 + '<dd><ul>'
                 + ''.join(format_html('<li>{0}</li>', mark_safe(comment)) for comment in comments_by_flag[flag[1]])
                 + '</ul></dd>'
                ) for flag in flag_names
            )+'</dl>'

        else:
            return format_html(
                '<span style="color:red">{0}</span>',
                ' '.join(flag[0] for flag in flag_names)
            )

    get_review_flag.short_description = "Review flag"
    get_review_flag.allow_tags = True

    def get_review_flag_details(self, obj):
        return self.get_review_flag(obj, True)

    get_review_flag_details.short_description = "Review flag"
    get_review_flag_details.allow_tags = True

    def review_status(self, peerreview):
        state = []
        if peerreview.review:
            state.append(ugettext("Reviewed"))
        if peerreview.rank is not None:
            state.append(ugettext("Ranked"))
        if peerreview.submission_grade is not None:
            state.append(ugettext("Graded"))

        if state:
            return ', '.join(state)
        else:
            return ugettext("(None)")

    def queryset(self, request):
        """ Limit the visible peer reviews to the ones the current for assignments the user can manage
        """
        queryset = super(PeerReviewAdmin, self).queryset(request)
        user = request.user
        if user and not user.is_superuser:
            queryset = queryset.filter(bundle__assignment__review_assignment__courseedition__managers=user).distinct()
        return queryset


admin.site.register(PeerReview, PeerReviewAdmin)

class PeerReviewInline(admin.TabularInline):
    fields = 'identifier', 'submission', 'rank', 'is_reviewed', 'submission_grade', 'get_review_grade',
    readonly_fields = 'identifier', 'submission', 'rank', 'is_reviewed', 'submission_grade', 'get_review_grade',
    ordering = 'identifier',
    model = PeerReview
    extra = 0
    max_num = 0
    can_delete = False

    def get_review_grade(self, obj):
        try:
            return unicode(obj.get_review_grade())
        except PeerReviewGrade.DoesNotExist:
            return None

    get_review_grade.short_description = "Review grade"


class BundleCourseEditionListFilter(CourseEditionListFilter):
    query_filter_parameter = 'assignment__review_assignment__courseedition'


class BundlePeerReviewAssignmentListFilter(PeerReviewAssignmentListFilter):
    query_filter_parameter = 'assignment'


class PeerReviewBundleAdmin(admin.ModelAdmin): #pylint: disable=R0904
    list_display = 'assignment', 'reviewers', 'review_status'
    list_filter = BundleCourseEditionListFilter, BundlePeerReviewAssignmentListFilter,
    search_fields = ['assignment__original_assignment__default_name',
                     'assignment__review_assignment__default_name',
                     'reviewer__last_name',
                    ]

    readonly_fields = 'assignment', 'reviewer',
    inlines = PeerReviewInline,

    search_fields = ['assignment__original_assignment__default_name',
                     'assignment__review_assignment__default_name',
                     'reviewer__last_name',
                    ]

    #pylint: disable=R0201

    def reviewers(self, bundle):
        return _user_list(bundle.reviewer.all())

    def review_status(self, bundle):
        state = []
        if bundle.is_reviewed():
            state.append('Reviewed')
        if bundle.is_ranked():
            state.append('Ranked')
        if bundle.is_graded():
            state.append('Graded')

        if state:
            return ', '.join(state)
        else:
            return 'None'

    def queryset(self, request):
        """ Limit the visible peer review bundles to the ones the current for assignments the user can manage
        """
        queryset = super(PeerReviewBundleAdmin, self).queryset(request)
        user = request.user
        if user and not user.is_superuser:
            queryset = queryset.filter(assignment__review_assignment__courseedition__managers=user).distinct()
        return queryset


admin.site.register(PeerReviewBundle, PeerReviewBundleAdmin)
