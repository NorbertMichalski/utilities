""" This file is part of PEACH.

    Copyright (C) 2006-2009 Eindhoven University of Technology
"""
from django.contrib import admin
from django.forms.models import ModelForm
from django.utils.translation import ugettext_lazy

from peach3.forms import TimeRangeField
from peach3.admin.forms import BaseInlineFormSetWithParentInstance
from peach3.admin.forms.widgets import AdminTimeRange
from peach3.models.timerange import * #@UnusedWildImport pylint: disable=W0401,W0614

__all__ = []

class TimeRangeModelForm(ModelForm): #pylint: disable=R0924
    period = TimeRangeField(widget=AdminTimeRange, label=ugettext_lazy("Period"))

    def __init__(self, *args, **kwargs):
        super(TimeRangeModelForm, self).__init__(*args, **kwargs)
        self.fields['period'].initial = self.instance.range

    def _post_clean(self):
        if 'period' in self.cleaned_data:
            self.instance.range = self.cleaned_data['period']
        super(TimeRangeModelForm, self)._post_clean() #pylint: disable=W0212


class ClusterTimeRangeInlineForm(TimeRangeModelForm): #pylint: disable=R0924
    def __init__(self, parent_instance, *args, **kwargs):
        from peach3.models.course import CourseEdition
        from peach3.models.cluster import Cluster

        super(ClusterTimeRangeInlineForm, self).__init__(*args, **kwargs)
        try:
            self.fields['cluster'].queryset = parent_instance.courseedition.cluster_set.filter(admin_cluster=False)
        except CourseEdition.DoesNotExist:
            # This is a new assignment, it is not linked to a courseedition yet, so we can't allow the user to select
            # clusters yet.
            self.fields['cluster'].queryset = Cluster.objects.none()

    class Meta: #pylint: disable=W0232,C0111,R0903
        fields = 'type', 'period', 'cluster',

class ClusterTimeRangeInline(admin.TabularInline):
    model = ClusterTimeRange
    formset = BaseInlineFormSetWithParentInstance
    form = ClusterTimeRangeInlineForm
    extra = 0

class IndividualTimeRangeInlineForm(TimeRangeModelForm): #pylint: disable=R0924
    class Meta: #pylint: disable=W0232,C0111,R0903
        fields = 'type', 'period', 'user',

class IndividualTimeRangeInline(admin.TabularInline):
    model = IndividualTimeRange
    form = IndividualTimeRangeInlineForm
    raw_id_fields = 'user',
    extra = 0
