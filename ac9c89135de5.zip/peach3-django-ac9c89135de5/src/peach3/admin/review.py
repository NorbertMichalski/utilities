from django.contrib import admin

from peach3.models.review import * #@UnusedWildImport pylint: disable=W0401,W0614
from peach3.admin.forum import CommentInline

__all__ = ('ReviewAdmin',)

class ReviewAdmin(admin.ModelAdmin): #pylint: disable=R0904
    filter_horizontal = 'authors',
    raw_id_fields = 'submission', 'created_by', 'authors',
    inlines = CommentInline,

    list_display = 'submission', 'created_by',

#    def get_form(self, request, obj=None):
#        # Sort user field on username
#        f = super(ReviewAdmin, self).get_form(request, obj)
#
#        qs = f.base_fields['created_by'].queryset
#        f.base_fields['created_by'].queryset = qs.order_by('username')
#
#        qs = f.base_fields['authors'].queryset
#        f.base_fields['authors'].queryset = qs.order_by('username')
#
#        return f

admin.site.register(Review, ReviewAdmin)

