""" This file is part of PEACH.

    Copyright (C) 2006-2009 Eindhoven University of Technology
"""
from django.utils.translation import ugettext_lazy
from django.contrib import admin
from django.contrib.admin.filters import SimpleListFilter
from django.forms.models import modelform_factory

from peach3.admin.forms import I18NModelForm
from peach3.models.course import * #@UnusedWildImport pylint: disable=W0401,W0614

__all__ = ('CourseEditionAdmin',)

class SubCodeInline(admin.TabularInline):
    form = modelform_factory(SubCode, I18NModelForm)
    model = SubCode
    fields = ('subcode', 'i18n_names')
    extra = 0

class CourseEditionAdmin(admin.ModelAdmin): #pylint: disable=R0904
    form = modelform_factory(CourseEdition, I18NModelForm)
    fields = ('code', 'i18n_names', 'parent', 'period', 'cluster_selection',
              'scoreboard', 'managers', 'created', 'created_by')
    readonly_fields = 'created', 'created_by',
    raw_id_fields = 'managers', 'parent',
    radio_fields = {
        'cluster_selection' : admin.VERTICAL,
    }

    inlines = SubCodeInline,

    list_display = 'code', 'name', 'period',
    list_filter = 'period',
    ordering = 'created',

    def queryset(self, request):
        """ Limit the visible CourseEditions to the ones the current user can manage
        """
        queryset = super(CourseEditionAdmin, self).queryset(request)
        user = request.user
        if user and not user.is_superuser:
            queryset = queryset.filter(managers=user)
        return queryset
admin.site.register(CourseEdition, CourseEditionAdmin)

class CourseEditionListFilter(SimpleListFilter):
    """ A ListFilter that will only list courseeditions the current user can manage
    """
    title = ugettext_lazy("course edition")

    parameter_name = 'courseedition'

    def lookups(self, request, model_admin):
        user = request.user

        query = CourseEdition.objects

        if not user.is_superuser:
            query = query.filter(managers=user)

        # If the user filtered on period, limit this lookup to course editions in the selected period
        period_id = request.REQUEST.get('courseedition__period__id__exact')
        if period_id:
            query = query.filter(period__id__exact=period_id)

        # If the user filtered on realm, limit this lookup to course editions for the selected realm
        realms_id = request.REQUEST.get('realms')
        if realms_id:
            query = query.filter(cluster__realms__id__exact=realms_id)

        for ce in query.distinct():
            yield (ce.pk, unicode(ce))

    def queryset(self, request, queryset):
        return queryset.filter(**self.used_parameters)

def _unique(i):
    l=None
    for v in i:
        if v!=l:
            yield v
        l=v
