""" This file is part of PEACH.

    Copyright (C) 2006-2009 Eindhoven University of Technology
"""
from django.contrib import admin
from django.forms.formsets import DELETION_FIELD_NAME
from django.forms.models import BaseInlineFormSet
from django.utils.translation import ugettext_lazy

from peach3.admin.course import CourseEditionListFilter
from peach3.admin.forms import AdminImmutableUserModelForm, BaseInlineFormSetWithParentInstance, I18NModelForm
from peach3.admin.forms.widgets import AdminTimeRange
from peach3.admin.news import NewsItemInline
from peach3.admin.realm import CourseEditionRealmsListFilter

from peach3.forms import TimeRangeField

from peach3.models.cluster import * #@UnusedWildImport pylint: disable=W0401,W0614

__all__ = ('ClusterAdmin',)

class ClusterMemberInlineForm(AdminImmutableUserModelForm): #pylint: disable=R0924
    def __init__(self, parent_instance, *args, **kwargs):
        from peach3.models.realm import Realm
        from peach3.models.course import SubCode

        super(ClusterMemberInlineForm, self).__init__(*args, **kwargs)

        admin_cluster = parent_instance.admin_cluster

        # Limit the available Realms for a ClusterMember to the Realms of the CourseEdition
        realms_queryset = Realm.objects
        if admin_cluster:
            # Admin cluster doesn't need realms
            realms_queryset = realms_queryset.none()
        else:
            realms_queryset = realms_queryset.filter(cluster=parent_instance).distinct()

        realm_field = self.fields['realm']
        realm_field.queryset = realms_queryset
        realm_field.required = not admin_cluster

        # Limit the subcodes to the valid subcodes
        subcodes_queryset = SubCode.objects
        if admin_cluster:
            subcodes_queryset = subcodes_queryset.none()
        else:
            subcodes_queryset = subcodes_queryset.filter(courseedition=parent_instance.courseedition).distinct()

        subcode_field = self.fields['subcode']
        subcode_field.queryset = subcodes_queryset

class ClusterMembersInline(admin.TabularInline):
    model = ClusterMember
    formset = BaseInlineFormSetWithParentInstance
    form = ClusterMemberInlineForm

    fields = 'user', 'realm', 'subcode', 'source', 'removed', 'favorite',
    raw_id_fields = 'user',
    extra = 0

class ClusterStaffInlineFormSet(BaseInlineFormSet): #pylint: disable=R0924
    def add_fields(self, form, index):
        super(ClusterStaffInlineFormSet, self).add_fields(form, index)

        if index is not None and index<len(self.queryset):
            # Prevent mutation or deletion of ClusterStaff records of managers
            # Need to do this in the formset instead of in the form itself
            # because we also want to disable the delete checkbox
            staff = self.queryset[index]
            if staff.cluster.courseedition.is_manager(staff.user):
                for fn in ['role', 'level', 'extend_deadline', DELETION_FIELD_NAME]:
                    form.fields[fn].widget.attrs['disabled'] = 'disabled'
                    form.fields[fn].required = False

class ClusterStaffInline(admin.TabularInline):
    model = ClusterStaff
    formset = ClusterStaffInlineFormSet
    form = AdminImmutableUserModelForm

    fields = 'user', 'level', 'role', 'extend_deadline',
    raw_id_fields = 'user',
    ordering = '-level', 'role', 'user',
    extra = 0

class ClusterAdminModelForm(I18NModelForm): #pylint: disable=R0924
    # For admin clusters, raise a ValidationError if realms are defined
    # For non-admin clusters, raise ValidationError if no realms are defined
    # TODO: Figure out a way to completely hide the realms field for admin clusters

    active_range = TimeRangeField(widget=AdminTimeRange, label=ugettext_lazy("Active"))
    joinable_range = TimeRangeField(widget=AdminTimeRange, label=ugettext_lazy("Joinable"))

    def __init__(self, *arg, **kwargs):
        super(ClusterAdminModelForm, self).__init__(*arg, **kwargs)
        admin_cluster = self.instance.admin_cluster

        self.fields['courseedition'].readonly = self.instance.pk is not None
        self.fields['realms'].required = not admin_cluster
        self.fields['active_range'].initial = self.instance.active_range
        self.fields['joinable_range'].initial = self.instance.joinable_range
        self.fields['subcodes'].readonly = admin_cluster
        self.fields['subcodes'].required = self.instance.pk and self.instance.subcodes.exists()

    def _post_clean(self):
        if 'active_range' in self.cleaned_data:
            self.instance.active_range = self.cleaned_data['active_range']
        if 'joinable_range' in self.cleaned_data:
            self.instance.joinable_range = self.cleaned_data['joinable_range']
        super(ClusterAdminModelForm, self)._post_clean() #pylint: disable=W0212

    class Meta: #pylint: disable=W0232,C0111,R0903
        model = Cluster

class ClusterAdmin(admin.ModelAdmin): #pylint: disable=R0904
    form = ClusterAdminModelForm
    readonly_fields = 'admin_cluster',
    fields = ('courseedition', 'subcodes', 'i18n_names', 'admin_cluster', 'test_cluster',
              'realms', 'order', 'joinable_range', 'active_range',)
    filter_horizontal = 'subcodes', 'realms',
    inlines = ClusterMembersInline, ClusterStaffInline, NewsItemInline,

    list_display = 'courseedition', 'default_name', 'admin_cluster', 'order',
    list_filter = 'courseedition__period', CourseEditionRealmsListFilter, CourseEditionListFilter,
    ordering = 'order',

    def queryset(self, request):
        """ Limit the visible Clusters to the ones the current user can manage
        """
        queryset = super(ClusterAdmin, self).queryset(request)
        user = request.user
        if user and not user.is_superuser:
            queryset = queryset.filter(courseedition__managers=user).distinct()
        return queryset

admin.site.register(Cluster, ClusterAdmin)
