from django.contrib import admin
from django.utils.translation import ugettext_lazy

from peach3.models.checking import * #@UnusedWildImport pylint: disable=W0401,W0614

__all__ = ('CheckResultAdmin', 'ReasonAdmin',)

class CheckResultStepInline(admin.TabularInline):
    model = CheckResultStep

def force_recheck(modeladmin, request, queryset): #pylint: disable=W0613
    queryset.update(checked=None, state='')
force_recheck.short_description = ugettext_lazy("Force Recheck")

class CheckResultAdmin(admin.ModelAdmin): #pylint: disable=R0904
    raw_id_fields = 'submission',
    inlines = CheckResultStepInline,

    date_hierarchy = 'created'

    list_display = 'submission', 'created', 'checked', 'state',
    list_filter = 'submission__assignmentedition',
    actions = force_recheck,

admin.site.register(CheckResult, CheckResultAdmin)

class ReasonAltDescriptionInline(admin.TabularInline):
    model = ReasonAltDescription

class ReasonAdmin(admin.ModelAdmin): #pylint: disable=R0904
    list_display = 'code', 'param1', 'param2', 'default_description',
    inlines = ReasonAltDescriptionInline,
admin.site.register(Reason, ReasonAdmin)



