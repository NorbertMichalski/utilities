""" This file is part of PEACH.

    Copyright (C) 2006-2009 Eindhoven University of Technology
"""
from __future__ import absolute_import

from django.contrib import admin
from peach3.models.wiki import * #@UnusedWildImport pylint: disable=W0401,W0614

__all__ = ('PageAdmin',)

class PagePermissionInline(admin.TabularInline):
    model = PagePermission

class PageAdmin(admin.ModelAdmin): #pylint: disable=R0904
    fieldsets = (
        (None, {
            'fields' : ('parent_type', 'parent_id', 'path', 'default_language',
                        'created', 'created_by',),
        }),
        ('Permissions', {
            'classes' : ('collapse',),
            'fields' : ('allow_comments', 'access', ),
        })
    )
    raw_id_fields = 'created_by',
    radio_fields = {
        'access' : admin.VERTICAL,
    }
    inlines = PagePermissionInline,

admin.site.register(Page, PageAdmin)

class PageRevisionTextAdmin(admin.ModelAdmin): #pylint: disable=R0904
    raw_id_fields = 'diff_base',
    radio_fields = {
        'markup' : admin.VERTICAL,
    }

admin.site.register(PageRevisionText, PageRevisionTextAdmin)

class PageRevisionAdmin(admin.ModelAdmin): #pylint: disable=R0904
    raw_id_fields = 'page', 'created_by', 'text',

    list_display = 'page', 'language', 'created_by', 'created', 'revision',

admin.site.register(PageRevision, PageRevisionAdmin)

#class PageCommentAdmin(admin.ModelAdmin):
#    raw_id_fields = 'created_by',
#
#admin.site.register(PageComment, PageCommentAdmin)
