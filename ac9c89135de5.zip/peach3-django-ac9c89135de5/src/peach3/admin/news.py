""" This file is part of PEACH.

    Copyright (C) 2006-2009 Eindhoven University of Technology
"""
from django import forms
from django.contrib.contenttypes import generic

from peach3.admin.forms.widgets import AdminNewsItemMessage
from peach3.models.news import NewsItem

__all__ = []

class NewsItemForm(forms.ModelForm): #pylint: disable=R0924
    message = forms.CharField(widget=AdminNewsItemMessage,
                              required=False)

    def __init__(self, *arg, **kwargs):
        super(NewsItemForm, self).__init__(*arg, **kwargs)
        self.initial['message'] = self.instance

    class Meta: #pylint: disable=W0232,C0111,R0903
        model = NewsItem

class NewsItemInline(generic.GenericStackedInline):
    model = NewsItem
    form = NewsItemForm

    fieldsets = (
        (None, {
            'fields':('receipient','message','current',
                     )
        }),
        ("Advanced", {
            'fields':('courseedition','cluster',
                      ('created','created_by'),
                      ('appears','expires'),
                      'msgtype','msgparam','read'),
            'classes': ('collapse',),
        })
    )

    raw_id_fields = 'courseedition', 'receipient', 'cluster', 'read', 'created_by',

    ct_field = 'related_content_type'
    ct_fk_field = 'related_id'

    extra = 0
    max_num = 0
