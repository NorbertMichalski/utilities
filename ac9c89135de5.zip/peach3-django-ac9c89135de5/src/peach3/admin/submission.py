""" This file is part of PEACH.

    Copyright (C) 2006-2009 Eindhoven University of Technology
"""
from django.contrib import admin
from peach3.models.submission import * #@UnusedWildImport pylint: disable=W0401,W0614

from peach3.admin.news import NewsItemInline
from peach3.admin.assignment import AssignmentEditionListFilter
from peach3.admin.course import CourseEditionListFilter

__all__ = ('SubmissionAdmin',)

class SubmissionNewsItemInline(NewsItemInline):
    #fields =
    pass

class SubmissionFileInline(admin.TabularInline):
    model = SubmissionFile
    raw_id_fields = 'slot', 'file', 'created_by',
    extra = 0

class SubmissionAuthorInline(admin.TabularInline):
    model = SubmissionAuthor
    raw_id_fields = 'author',
    readonly_fields = 'author', 'state', 'active', 'latest_accepted',
    extra = 0

class SubmissionAdmin(admin.ModelAdmin): #pylint: disable=R0904
    raw_id_fields = ('assignmentedition', 'courseedition',
                     'created_by', 'submitted_by',)
    readonly_fields = 'assignmentedition', 'courseedition', 'clusters', 'is_group',
    inlines = SubmissionAuthorInline, SubmissionFileInline, SubmissionNewsItemInline,

    date_hierarchy = 'created'

    list_display = 'assignmentedition', 'created', 'created_by',
    list_filter = 'courseedition__period', CourseEditionListFilter, AssignmentEditionListFilter

admin.site.register(Submission, SubmissionAdmin)
