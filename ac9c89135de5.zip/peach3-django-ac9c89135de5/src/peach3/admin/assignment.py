""" This file is part of PEACH.

    Copyright (C) 2006-2009 Eindhoven University of Technology
"""
from django.contrib import admin
from django.contrib.admin.filters import SimpleListFilter
from django.forms.models import modelform_factory
from django.utils.translation import ugettext_lazy as _

from peach3.admin.course import CourseEditionListFilter
from peach3.admin.forms import I18NModelForm
from peach3.admin.peerreview import PeerReviewAssignmentInline
from peach3.admin.timerange import ClusterTimeRangeInline, IndividualTimeRangeInline

from peach3.models.assignment import * #@UnusedWildImport pylint: disable=W0401,W0614

__all__ = ('AssignmentSetAdmin', 'AssignmentEditionAdmin',)

class AssignmentSetAdmin(admin.ModelAdmin): #pylint: disable=R0904
    form = modelform_factory(AssignmentSet, I18NModelForm)
    fields = 'i18n_names', 'courseedition', 'order',
    raw_id_fields = 'courseedition',

    list_display = 'courseedition', '__unicode__', 'order',
    list_filter = 'courseedition__period', CourseEditionListFilter,
    ordering = 'order',

    def queryset(self, request):
        """ Limit the visible AssignmentSets to the ones the current user can manage
        """
        queryset = super(AssignmentSetAdmin, self).queryset(request)
        user = request.user
        if user and not user.is_superuser:
            queryset = queryset.filter(courseedition__managers=user).distinct()
        return queryset

admin.site.register(AssignmentSet, AssignmentSetAdmin)

class AssignmentEditionListFilter(SimpleListFilter):
    """ A ListFilter that will only list assignment editions the current user can manage
    """
    title = _("assignment edition")

    parameter_name = 'assignmentedition'

    def lookups(self, request, model_admin):
        user = request.user

        query = AssignmentEdition.objects

        if not user.is_superuser:
            query = query.filter(courseedition__managers=user)

        # If the user filtered on period, limit this lookup to course editions in the selected period
        period_id = request.REQUEST.get('courseedition__period__id__exact')
        if period_id:
            query = query.filter(courseedition__period__id__exact=period_id)

        # If the user filtered on courseedition, limit this lookup to assignments for that course edition
        courseedition_id = request.REQUEST.get('courseedition')
        if courseedition_id:
            query = query.filter(courseedition__id__exact=courseedition_id)

        for ae in query.distinct():
            yield (ae.pk, unicode(ae))

    def queryset(self, request, queryset):
        return queryset.filter(**self.used_parameters)

class AssignmentEditionOptionInline(admin.TabularInline):
    model = AssignmentEditionOption
    extra = 0

class AssignmentEditionAdmin(admin.ModelAdmin): #pylint: disable=R0904
    form = modelform_factory(AssignmentEdition, I18NModelForm)
    fieldsets = (
        (None, {
            'fields' : ('courseedition', 'parent', 'assignmentset',
                        'i18n_names',
                        'created', 'order',),
        }),
        ('Advanced', {
            'classes': ('collapse',),
            'fields' : ('gradingsystems', 'languages',)
        })
    )
    filter_horizontal = 'gradingsystems', 'languages',
    raw_id_fields = 'courseedition', 'assignmentset', 'parent',
    inlines = (AssignmentEditionOptionInline, ClusterTimeRangeInline,
               IndividualTimeRangeInline,PeerReviewAssignmentInline)

    list_display = 'slug', '__unicode__', 'courseedition', 'order',
    list_filter = 'courseedition__period', CourseEditionListFilter,
    date_hierarchy = 'created'
    ordering = 'order',

    def queryset(self, request):
        """ Limit the visible AssignmentEditions to the ones the current user can manage
        """
        queryset = super(AssignmentEditionAdmin, self).queryset(request)
        user = request.user
        if user and not user.is_superuser:
            queryset = queryset.filter(courseedition__managers=user).distinct()
        return queryset

admin.site.register(AssignmentEdition, AssignmentEditionAdmin)
