""" This file is part of PEACH.

    Copyright (C) 2006-2009 Eindhoven University of Technology
"""
from django.contrib import admin
from peach3.models.report import Report

__all__ = ('ReportAdmin',)

class ReportAdmin(admin.ModelAdmin): #pylint: disable=R0904
    raw_id_fields = 'users',
    list_display = 'file', 'type', 'created', 'last_access',
    date_hierarchy = 'created'

admin.site.register(Report, ReportAdmin)
