""" This file is part of PEACH.

    Copyright (C) 2006-2009 Eindhoven University of Technology
"""
from django.contrib import admin
from django.contrib.admin.filters import SimpleListFilter
from django.forms.models import modelform_factory
from django.utils.translation import ugettext_lazy as _

from peach3.admin.forms import I18NModelForm
from peach3.models.realm import * #@UnusedWildImport pylint: disable=W0401,W0614

__all__ = ('RealmAdmin',)

class RealmAdmin(admin.ModelAdmin): #pylint: disable=R0904
    form = modelform_factory(Realm, I18NModelForm)

    fields = 'i18n_names', 'site'
    list_display = 'default_name',
    list_filter = 'site',

admin.site.register(Realm, RealmAdmin)

class CourseEditionRealmsListFilter(SimpleListFilter):
    """ A ListFilter for Realms
    """
    title = _("realm")

    parameter_name = 'realms'

    def lookups(self, request, model_admin):
        #user = request.user

        query = Realm.objects

        # If the user filtered on period, limit this lookup to course editions in the selected period
        period_id = request.REQUEST.get('courseedition__period__id__exact')
        if period_id:
            query = query.filter(cluster__courseedition__period__id__exact=period_id)

        for r in query.distinct():
            yield (r.pk, unicode(r))

    def queryset(self, request, queryset):
        return queryset.filter(**self.used_parameters)

