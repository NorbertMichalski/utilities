""" This file is part of PEACH.

    Copyright (C) 2006-2009 Eindhoven University of Technology
    Copyright (C) 2009 Eljakim Information Technology bv.
"""
from django.contrib import admin
from django.forms.models import modelform_factory

from peach3.admin.forms import I18NModelForm
from peach3.models.proglang import ProgrammingLanguage

__all__ = ('ProgrammingLanguageAdmin',)

class ProgrammingLanguageAdmin(admin.ModelAdmin): #pylint: disable=R0904
    form = modelform_factory(ProgrammingLanguage, I18NModelForm)
    list_display = 'default_name', 'enabled',
    list_editable = 'enabled',
    fields = 'code', 'enabled', 'i18n_names',
admin.site.register(ProgrammingLanguage, ProgrammingLanguageAdmin)
