""" This file is part of PEACH.

    Copyright (C) 2006-2009 Eindhoven University of Technology
"""
from django.contrib import admin
from django.forms.models import modelform_factory

from peach3.models.grade import * #@UnusedWildImport pylint: disable=W0401,W0614
from peach3.admin.forms import I18NModelForm

__all__ = ('GradingSystemAdmin',)

class GradeInline(admin.TabularInline):
    model = Grade
    form = modelform_factory(Grade, I18NModelForm)
    fields = 'i18n_names', 'icon', 'value_low', 'value_high', 'passing'
    extra = 1

class GradingSystemAdmin(admin.ModelAdmin): #pylint: disable=R0904
    form = modelform_factory(GradingSystem, I18NModelForm)
    fields = 'i18n_names',
    inlines = GradeInline,
admin.site.register(GradingSystem, GradingSystemAdmin)
