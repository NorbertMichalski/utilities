""" This file is part of PEACH.

    Copyright (C) 2006-2009 Eindhoven University of Technology
"""
from django.contrib import admin
from django.utils.translation import ugettext_lazy

from peach3.admin.forms import I18NModelForm
from peach3.admin.forms.widgets import AdminTimeRange
from peach3.forms import TimeRangeField

from peach3.models.period import * #@UnusedWildImport pylint: disable=W0401,W0614

from mptt.admin import MPTTModelAdmin

__all__ = ('PeriodAdmin',)

class PeriodModelForm(I18NModelForm): #pylint: disable=R0924
    range = TimeRangeField(widget=AdminTimeRange, label=ugettext_lazy("Range")) #@ReservedAssignment

    def __init__(self, *args, **kwargs):
        super(PeriodModelForm, self).__init__(*args, **kwargs)
        self.fields['range'].initial = self.instance.range

    def _post_clean(self):
        if 'range' in self.cleaned_data:
            self.instance.range = self.cleaned_data['range']
        super(PeriodModelForm, self)._post_clean() #pylint: disable=W0212

    class Meta: #pylint: disable=W0232,C0111,R0903
        model = Period
        fields = 'i18n_names', 'slug', 'range'

class PeriodAdmin(MPTTModelAdmin): #pylint: disable=R0904
    list_display = 'slug', 'default_name', 'range'
    form = PeriodModelForm
    date_hierarchy = '_begin'
admin.site.register(Period, PeriodAdmin)
