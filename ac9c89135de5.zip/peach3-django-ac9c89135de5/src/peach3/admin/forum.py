""" This file is part of PEACH.

    Copyright (C) 2006-2009 Eindhoven University of Technology
"""
from django.contrib import admin
from django.contrib.contenttypes import generic

from peach3.models.forum import * #@UnusedWildImport pylint: disable=W0401,W0614

__all__ = ('CommentAdmin', 'CommentRevisionAdmin',)

class CommentInline(generic.GenericTabularInline):
    model = Comment
    ct_field = 'parent_content_type'
    ct_fk_field = 'parent_id'
    raw_id_fields = 'author', 'response_to',

class CommentAdmin(admin.ModelAdmin): #pylint: disable=R0904
    raw_id_fields = 'author', 'response_to',
    list_display = 'parent_content_type', 'parent_id', 'author'
admin.site.register(Comment, CommentAdmin)

class CommentRevisionAdmin(admin.ModelAdmin): #pylint: disable=R0904
    list_display = 'comment', 'author'
admin.site.register(CommentRevision, CommentRevisionAdmin)
