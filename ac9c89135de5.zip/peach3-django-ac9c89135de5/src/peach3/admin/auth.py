from django.contrib import admin
from django.contrib.auth import forms as auth_forms
from django.contrib.auth import admin as auth_admin
from django.utils.translation import ugettext_lazy as _

from tastypie.admin import ApiKeyInline

from peach3.models.auth import User, UserPreference, VerificationCode

__all__ = ['UserAdmin']

class UserPreferenceInline(admin.StackedInline):
    model = UserPreference
    extra = 0
    max_num = 0

class VerificationCodeInline(admin.TabularInline):
    model = VerificationCode
    readonly_field = 'created',
    extra = 0
    max_num = 0

class UserChangeForm(auth_forms.UserChangeForm):
    class Meta(auth_forms.UserChangeForm.Meta):
        model = User

class UserCreationForm(auth_forms.UserCreationForm):
    class Meta(auth_forms.UserCreationForm.Meta):
        model = User

class UserAdmin(auth_admin.UserAdmin):
    fieldsets = (
        (None, {'fields': (
            'username', 'password')}),
        (_('Personal info'), {'fields': (
            'titles_prefix', 'first_name', 'initials', 'last_name_prefix', 'last_name',
            'last_name_suffix', 'titles_suffix', 'email')}),
        (_('State'), {'fields': ('is_active', 'state')}),
        (_('Permissions'), {'fields': ('is_staff', 'is_superuser',
                                       'groups', 'user_permissions')}),
        (_('Important dates'), {'fields': ('last_login', 'date_joined')}),
    )
    form = UserChangeForm
    add_form = UserCreationForm
    list_display = ('username', 'email', 'full_name', 'is_staff')
    list_filter = ('is_staff', 'is_superuser', 'is_active', 'state', 'groups')
    inlines = UserPreferenceInline, VerificationCodeInline, ApiKeyInline

    def full_name(self, obj):
        return obj.get_full_name_sortable()
    full_name.short_description = _("Full name")

admin.site.register(User, UserAdmin)
