from django.contrib import admin
from peach3.models.pdf import RefPDFInfo
from pdfviewer.admin import PDFPageInfoInline

__all__ = ('RefPDFInfoAdmin',)

class RefPDFInfoAdmin(admin.ModelAdmin): #pylint: disable=R0904
    inlines = PDFPageInfoInline,

    list_display = 'path', 'ref_ct', 'ref_id', 'title', 'pagecount', 'last_access',

admin.site.register(RefPDFInfo, RefPDFInfoAdmin)
