(function($) {
	$(document).ready(function() {
		$(".timerange select").change(function(e){
			var range=$(this).nextAll(".timerange-range");
			if ($(this).attr('value')=='period'){
				range.removeClass("collapsed");
			}
			else {
				range.addClass("collapsed");
			}
		}).filter("[value!='period']").nextAll(".timerange-range").addClass("collapsed");
	});
})(django.jQuery);
