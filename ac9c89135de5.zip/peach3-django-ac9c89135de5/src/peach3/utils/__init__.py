""" This file is part of PEACH.

    Copyright (C) 2006-2009 Eindhoven University of Technology
"""
import os

MAX_LOAD = 10

def systemloaded():
    try:
        load = os.getloadavg()[0]
    except:
        load = 0

    return load>MAX_LOAD
