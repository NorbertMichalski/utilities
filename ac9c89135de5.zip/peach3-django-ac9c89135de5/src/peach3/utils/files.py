from __future__ import with_statement

from django.utils.encoding import smart_str

import codecs, hashlib
from chardet.universaldetector import UniversalDetector

from unipath import Path, AbstractPath

def normalize_charset_name(charset):
    if charset:
        try:
            c = codecs.lookup(charset)
        except LookupError:
            return None
        else:
            return c.name

    return ''

def detect_file(f):
    """ In a single iteration over the file, calculate its SHA1 and detect
        its charset

        'f' should be a django.core.files.File (sub)class.
        'f' is not closed.
    """
    f.open()

    detector = UniversalDetector()
    sha1 = hashlib.sha1()

    binary, empty = False, True

    for chunk, data in enumerate(f.chunks(8192)):
        sha1.update(data) #pylint: disable=E1101

        if chunk<128:
            # Only check charset on the first megabyte
            detector.feed(data)

        binary = binary or ('\x00' in data)
        empty = empty and (data.strip()=='')

    detector.close()

    if not empty:
        result = detector.result
        confidence, charset = result['confidence'], result['encoding']

        if binary and confidence<0.9:
            charset = ''
        else:
            charset = normalize_charset_name(detector.result['encoding'])

            if confidence<1.0 and (charset=='cp1255' or charset.startswith('iso8859')):
                charset = 'iso8859-1'
    else:
        charset = 'ascii'

    return sha1.hexdigest(), charset

def sha1_file(f): #@ReservedAssignment
    """ Calculate file's SHA1

        'f' should be a django.core.files.File (sub)class
        'f' is not closed.
    """
    f.open()

    sha1 = hashlib.sha1()
    for data in f.chunks(8192):
        sha1.update(data) #pylint: disable=E1101

    return sha1.hexdigest()

def clean_filename(fn):
    fn = smart_str(fn, encoding='iso8859-1', errors='replace').translate(''
       '////////////////////////////////'
       '________//____._0123456789______'
       '@ABCDEFGHIJKLMNOPQRSTUVWXYZ/_//_'
       '_abcdefghijklmnopqrstuvwxyz/_/_/'
       '////////////////////////////////'
       '_____Y___ca___r__23_u___1_______'
       'AAAAAA_CEEEEIIIIDNOOOOOxOUUUUY_B'
       'aaaaaa_ceeeeiiiidnooooo_ouuuuy_y'
    )
    s, l = '', ''
    for c in fn:
        if c!='/':
            if c!='_' or l!='_':
                s+=c
                l=c

    return s.strip('_')

def create_filename(ext='', *args):
    """ Create a valid file name containing the arguments
    """
    procargs = []
    for arg in args:
        s = clean_filename(arg)
        if s:
            procargs.append(s)

    return '-'.join(procargs)+ext

def create_path(*args):
    procargs = []
    for arg in args:
        s = clean_filename(arg)
        if s:
            procargs.append(s)

    return AbstractPath(*procargs)

def rmdirs(root, path):
    " Delete empty directories from path down to root "

    root, path = Path(root), Path(path)
    try:
        while not root.same_file(path):
            path.rmdir(False)
            path = path.parent
    except OSError:
        pass
