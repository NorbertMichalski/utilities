from functools import wraps

def skip_raw_save(func):
    """ Decorator to decorate 'pre_save' and 'post_save' signal handlers to automatically
        skip these signal handlers when data is loaded using the 'loaddata' management
        command

        See:
            http://stackoverflow.com/questions/3499791/how-do-i-prevent-fixtures-from-conflicting-with-django-post-save-signal-code
    """
    @wraps(func)
    def wrapper(*args, **kwargs):
        if not kwargs.get('raw', False):
            return func(*args, **kwargs)
    return wrapper

