""" This file is part of PEACH.

    Copyright (C) 2006-2009 Eindhoven University of Technology
"""
from django.conf import settings
from django.contrib.auth.models import AnonymousUser
from django.core.cache import cache
from django.utils.encoding import smart_str, iri_to_uri

class Cacheable:
    def cache_key(self):
        raise NotImplementedError

def _cache_key_part(sep, *args):
    #pylint: disable=W0212

    parts = []
    for arg in args:
        if isinstance(arg, (list, tuple)):
            wrap = '[%s]' if isinstance(arg, list) else '(%s)'
            arg = wrap % _cache_key_part(',', *arg)
        elif isinstance(arg, dict):
            l=[]
            for key, value in arg.iteritems():
                l.append(_cache_key_part(':', key, value))
            l.sort()
            arg = '{%s}' % _cache_key_part(',', *l)
        elif hasattr(arg, '_meta') and hasattr(arg._meta, 'app_label') and hasattr(arg._meta, 'module_name'):
            subparts = [arg._meta.app_label, arg._meta.module_name]
            try:
                subparts.append(arg._get_pk_val())
            except TypeError:
                # TypeError occurs if arg isn't a model object but a Model class
                pass
            arg = _cache_key_part('.', *subparts)
        elif isinstance(arg, AnonymousUser):
            arg = 'anonymous'
        elif isinstance(arg, Cacheable):
            arg = arg.cache_key()
        assert arg is None or isinstance(arg, (basestring, int, long, bool,)), \
               'Wrong key-part type for %r'%arg
        parts.append(iri_to_uri(smart_str(arg)))
    return sep.join(parts)


def cache_key(*args):
    return _cache_key_part('/', *args)


#def cached_get_object_or_404(klass, **kwargs):
#    cache_timeout = kwargs.pop('cache_timeout', None)
#    cache_failure = kwargs.pop('cache_failure', False) # True to cache 404 results as well
#
#    key = cache_key('peach3.utils.cached_get_object_or_404', klass, kwargs)
#
#    item = cache.get(key)
#    if item is None:
#        try:
#            item = get_object_or_404(klass, **kwargs)
#        except Http404, e:
#            if cache_failure:
#                cache.set(key, e, cache_timeout)
#            raise
#
#        cache.set(key, item, cache_timeout)
#
#    elif isinstance(item, Http404):
#        raise item
#
#    return item

def unique_cache_hash(base_key, obj):
    digest = cache.get(base_key)

    if digest is None:
        import time, hashlib

        uk = cache_key('unique_key')
        try:
            unique = cache.incr(uk)
        except ValueError:
            cache.set(uk, 0)
            unique = 0

        h = hashlib.sha1(settings.SECRET_KEY)
        h.update('/%s/%s/%s' % (obj.pk, time.time(), unique)) #pylint: disable=E1101
        digest = h.hexdigest()

        cache.set(base_key, digest)

    return digest
