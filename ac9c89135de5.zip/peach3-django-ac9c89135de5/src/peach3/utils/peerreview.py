from peach3.models import SubmissionFile, PeerReview
from peach3.utils.permissions import get_current_user

def get_peerreview_objects(current_user=None, aeupr=None, when=None, **query):
    # aeupr: assignmentedition under peerreview
    if current_user is None:
        current_user = get_current_user()

    peerreviews = PeerReview.objects.filter(**query)

    if aeupr:
        peerreviews = peerreviews.filter(bundle__assignment__original_assignment=aeupr)

    if not (aeupr and aeupr.can_observe(current_user)):
        peerreviews = peerreviews.published(when)

    return peerreviews

#def get_peerreview_ranks_for_submission(submission, current_user=None, when=None): #pylint: disable=C0103
#    peerreviews = get_peerreview_objects(current_user,
#                                         submission.assignmentedition,
#                                         when,
#                                         submission=submission)
#
#    return peerreviews.order_by('rank').values_list('rank', flat=True)
#
#def get_peerreview_feedback_for_submission(submission, current_user=None, when=None): #pylint: disable=C0103
#    " Returns a QuerySet of feedback for the given submission "
#    peerreviews = get_peerreview_objects(current_user,
#                                         submission.assignmentedition,
#                                         when,
#                                         submission=submission)
#
#    return SubmissionFile.objects.filter(peerreview__in=peerreviews)

def get_peerreview_feedback_for_user(user, current_user=None, aeupr=None, when=None): #pylint: disable=C0103
    peerreviews = get_peerreview_objects(current_user,
                                         aeupr,
                                         when,
                                         submission__authors=user)

    return SubmissionFile.objects.filter(peerreview__in=peerreviews)

