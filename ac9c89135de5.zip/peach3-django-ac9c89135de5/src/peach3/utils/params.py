""" This file is part of PEACH.

    Copyright (C) 2006-2009 Eindhoven University of Technology
"""
from django.utils.encoding import smart_str
from fnmatch import fnmatchcase

def parse_parameters(parameters, seperator="\n"):
    result = {}
    for parameter in parameters.split(seperator):
        parameter = parameter.strip()
        if '=' in parameter:
            key, value = parameter.split('=', 1)
            result[smart_str(key.strip())]=value.strip()
        elif parameter:
            result[smart_str(parameter.strip())]=True
    return result

def parse_patterns(patterns, seperator="\n"):
    result = {}
    for pattern in patterns.split(seperator):
        if ';' in pattern:
            pattern, rawparameters = pattern.split(';', 1)
            parameters = parse_parameters(rawparameters,';')
        else:
            parameters = {}

        pattern = pattern.strip()
        if pattern:
            if 'q' in parameters:
                parameters['q'] = float(parameters['q'])

            result[pattern] = parameters
    return result

def match_patterns(patterns, value, casedifference_factor=None):
    result = 0.0

    for pattern, parameters in patterns.iteritems():
        if fnmatchcase(value, pattern):
            q = parameters.get('q', 1.0)
        elif casedifference_factor and fnmatchcase(value.lower(), pattern.lower()):
            q = parameters.get('q', 1.0)*casedifference_factor
        else:
            continue

        if q>result:
            result = q

    return result
