import re, unicodedata

def slugify(value):
    # Borrowed from django.templates.defaultfilters
    # Modified to remove whitespace from slugs, but accept underscores
    value = unicodedata.normalize('NFKD', value).encode('ascii', 'ignore')
    value = unicode(re.sub(r'[^\w_-]', '', value).lower())
    return value

def unique_slug(model, name, slugfield='slug', **extra_fields):
    # Convert a name into a unique slug for the model

    maxlen = model._meta.get_field_by_name(slugfield)[0].max_length #pylint: disable=W0212
    base = slugify(name)

    i = 0
    while True:
        if i>0:
            extra = '_%d' % i
        else:
            extra = ''

        slug = base[:maxlen-len(extra)]+extra

        extra_fields[slugfield] = slug
        if model.objects.filter(**extra_fields).count()==0:
            return slug

        i += 1
