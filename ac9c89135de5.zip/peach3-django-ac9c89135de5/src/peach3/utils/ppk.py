from django.conf import settings
from django.core.cache import cache
from django.db.models import Manager
from django.db.models.query import QuerySet
from django.utils.encoding import smart_str

from peach3.utils.cache import cache_key
from peach3.utils.permissions import get_current_user

import struct
import base64

from Crypto.Cipher import ARC2

__all__ = ['PPKQuerySetMixin', 'PPKManagerMixin', 'PPKModelMixin',
           'PPKQuerySet', 'PPKManager',
           'base64_encode_ppk', 'base64_decode_ppk',
           'base32_encode_ppk', 'base32_decode_ppk',
           'hex_encode_ppk', 'hex_decode_ppk',
          ]

def base64_encode_ppk(value):
    " Base64 encode a ppk "
    return base64.urlsafe_b64encode(value).strip('=')

def base64_decode_ppk(value):
    " Base64 decode a ppk "
    padlen = -len(value)%3
    padding = '='*padlen
    try:
        return base64.urlsafe_b64decode(smart_str(value+padding))
    except TypeError:
        raise ValueError, "Invalid ppk format"

def base32_encode_ppk(value):
    " Base32 encode a ppk "
    return base64.b32encode(value).strip('=')

def base32_decode_ppk(value):
    " Base32 decode a ppk "
    padlen = -len(value)%8
    padding = '='*padlen
    try:
        return base64.b32decode(smart_str(value+padding), True)
    except TypeError:
        raise ValueError, "Invalid ppk format"

hex_encode_ppk = base64.b16encode #pylint: disable=C0103
hex_decode_ppk = base64.b16decode #pylint: disable=C0103

def _encrypt_long(key, value):
    " Encrypt a 64-bit long unsigned integer "
    try:
        obj = ARC2.new(key)
        packed = struct.pack('>Q', value)
        return obj.encrypt(packed)
    except Exception, e:
        raise ValueError("Error encrypting ppk: %s" % str(e))

def _decrypt_long(key, encrypted):
    " Decrypt a 64-bit long unsigned integer "
    try:
        obj = ARC2.new(key)
        decrypted = obj.decrypt(encrypted)
        return struct.unpack('>Q', decrypted)[0]
    except Exception, e:
        raise ValueError("Error decrypting ppk: %s" % str(e))

def _get_user_secret(user):
    " Get the user's secret "
    if user and not user.is_anonymous():
        return user.secret + settings.SECRET_KEY

    return settings.SECRET_KEY

def _ppk_cache_key_by_object(pk, user):
    " Get ppk from cache based on pk and user"
    return cache_key('peach3.utils.ppk.by_object', user, pk)

def _ppk_cache_key_by_ppk(ppk, user):
    " Get object id from cache based on ppk and user"
    return cache_key('peach3.utils.ppk.by_ppk', user, hex_encode_ppk(ppk))

def pk_from_ppk(ppk, user=None):
    " Calculate pk from raw ppk "

    if user is None:
        user = get_current_user()

    key = _ppk_cache_key_by_ppk(ppk, user)
    pk = cache.get(key)

    if pk is None:
        secret = _get_user_secret(user)
        pk = _decrypt_long(secret, ppk)
        if key:
            cache.set(key, pk)

    return pk

def ppk_from_pk(pk, user=None):
    " Calculate ppk from raw pk "
    # model argument is not needed in the current implementation

    if user is None:
        user = get_current_user()

    key = _ppk_cache_key_by_object(pk, user)
    ppk = cache.get(key)
    if not ppk:
        secret = _get_user_secret(user)
        ppk = _encrypt_long(secret, pk)
        cache.set(key, ppk)

        # Also store reverse key in cache
        reverse_key = _ppk_cache_key_by_ppk(ppk, user)
        cache.set(reverse_key, pk)

    return ppk

class PPKQuerySetMixin: #pylint: disable=W0232
    def get_by_ppk(self, ppk, user=None):
        " Get an object by 'private primary key' (ppk), an 8-byte long identifier unique for each user "
        try:
            return self.get(pk=pk_from_ppk(ppk, user))
        except ValueError:
            raise self.model.DoesNotExist

class PPKManagerMixin: #pylint: disable=W0232
    def get_by_ppk(self, ppk, user=None):
        return self.get_query_set().get_by_ppk(ppk, user)
    get_by_ppk.__doc__ = PPKQuerySetMixin.get_by_ppk.__doc__

class PPKQuerySet(QuerySet, PPKQuerySetMixin): #pylint: disable=R0904,R0924
    pass

class PPKManager(Manager, PPKManagerMixin): #pylint: disable=R0904
    def get_query_set(self):
        return PPKQuerySet(self.model, using=self._db)

def _get_private_pk(obj, user=None):
    " Get the object's 'private primary key' (ppk), an 8-byte long identifier unique for each user "
    return ppk_from_pk(obj.pk, user)

class PPKModelMixin: #pylint: disable=R0903,W0232
    get_private_pk = _get_private_pk
