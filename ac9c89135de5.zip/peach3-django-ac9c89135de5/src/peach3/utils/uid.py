""" This file is part of PEACH.

    Copyright (C) 2006-2009 Eindhoven University of Technology
"""
from datetime import datetime

UID_SLASH = '|' # character that replaces '/'
UID_ESCAPE = '=' # cannot be UID_SLASH, '/', '#', '&', '?', '%', '+', '$' or space

def uidencode(s):
    """ Encode '/' as UID_SLASH, escape UID_SLASH and the escape character itself,
        encode the empty string with a single escape character, encode None
        with an escape character followed by 'N'
    """
    if isinstance(s, (int, long)):
        return str(s)
    if isinstance(s, datetime):
        return s.strftime("%Y%m%d%H%M%S")
    else:
        if s=='':
            return UID_ESCAPE
        elif s==UID_ESCAPE:
            return UID_ESCAPE*2
        elif s is None:
            return '%sN' % UID_ESCAPE

        t = ''
        for c in s:
            if c=='/':
                c = UID_SLASH
            elif c in [UID_SLASH, UID_ESCAPE]:
                c = UID_ESCAPE+c
            t = t+c
        if t.endswith(UID_ESCAPE*2):
            t = t[:-1]
        return t

def uiddecode(s):
    """ Decode UID_SLASH as '/' and unescape any escaped characters
    """

    # Handle the special cases of empty string and None
    if s==UID_ESCAPE:
        return ''
    elif s.upper()=='%sN' % UID_ESCAPE:
        return None

    t = ''
    while s!='':
        c, s = s[0], s[1:]
        if c==UID_SLASH:
            c = '/'
        elif c==UID_ESCAPE and s!='':
            c, s = s[0], s[1:]
        t = t+c
    return t

