""" This file is part of PEACH.

    Copyright (C) 2006-2009 Eindhoven University of Technology
"""
from django.conf import settings
from django.core.mail import send_mail
from django.template import Context, loader
from django.utils.translation import ugettext as _

import smtplib

def send_template_mail(email, subject, template, variables):
    t = loader.get_template(template)
    c = Context(variables)
    msg = t.render(c)

    if settings.MAIL_SUBJECT_PREFIX:
        subject = '%s %s' % (settings.MAIL_SUBJECT_PREFIX, subject)

    smtp_error = None
    try:
        send_mail(
            subject = subject,
            message = msg,
            from_email = settings.MAIL_FROM,
            recipient_list = [email],
            fail_silently = False,
        )

    except smtplib.SMTPSenderRefused:
        smtp_error = _(u"Server refused mail from us")

    except smtplib.SMTPRecipientsRefused, e:
        smtp_error = _(u"Server refused mail (reason %(nr)d '%(receipients)s')") \
                        % {'receipients':e.receipients.get(email, (0,_(u"unknown")))}

    except smtplib.SMTPResponseException, e:
        smtp_error = _(u"Sending mail failed (reason %(smtp_code)d '%(smtp_error)s')") \
                        % {'smtp_code':e.smtp_code, 'smtp_error':e.smtp_error}

    except:
        smtp_error = _(u"Sending mail failed (SMTP error)")

    return smtp_error

