""" This file is part of PEACH.

    Copyright (C) 2006-2009 Eindhoven University of Technology
"""
from django.utils import timezone

from datetime import datetime, timedelta
from pytz import utc

class TimeRange(object):
    # Values used to indicate "infinity"
    NEGINFDATE = timezone.make_aware(datetime(1899, 1, 1), utc)
    POSINFDATE = timezone.make_aware(datetime(3000, 12, 31, 23, 59, 59), utc)

    # Values used to detect "infinity". Should be far enough from the "infinity" value so
    # any timezone differences won't mess up the detection. A difference of a day doesn't suffice
    # (there can be more than a day difference) so lets make it a year.
    NEGINFDATEC = timezone.make_aware(datetime(1900, 1, 1), utc) # Negative infinity date
    POSINFDATEC = timezone.make_aware(datetime(2999, 12, 31, 23, 59, 59), utc) # Positive infinity date

    OPEN = (NEGINFDATE, POSINFDATE)
    CLOSED = (POSINFDATE, NEGINFDATE)

    def __init__(self, open=False, closed=False, begin=None, end=None): #@ReservedAssignment pylint: disable=W0622
        if closed:
            self.close()
        elif open:
            self.open()
        else:
            self._set_range(begin, end)

    def open(self): #@ReservedAssignment
        " Set this range open "
        self._range = TimeRange.OPEN
    open.alters_data=True

    def close(self):
        " Set this range closed "
        self._range = TimeRange.CLOSED
    close.alters_data=True

    def is_open(self):
        " Returns True if this range is open permanently "
        return not self.has_begin() and not self.has_end() and self._range[0] < self._range[1]

    def is_closed(self):
        " Returns True if this range is closed permanently "
        return not self.has_begin() and not self.has_end() and self._range[0] > self._range[1]

    def _set_range(self, begin, end):
        """ Set `begin` and `end` time for range; if both are None, the range is opened.
            If `begin` >= `end`, the range is closed.
        """

        if begin is None:
            begin = TimeRange.NEGINFDATE
        if end is None:
            end = TimeRange.POSINFDATE

        assert isinstance(begin, datetime)
        assert isinstance(end, datetime)

        #pylint: disable=W0201
        if begin < end:
            self._range = begin, end
        else:
            self._range = TimeRange.CLOSED
    _set_range.alters_data=True

    def _get_range(self):
        """ Get the range. If the range is closed, returns (None, None), otherwise returns
            a tuple (begin, end) where begin and end are both datetime objects
        """
        return self._range

    range = property(_get_range, _set_range) #@ReservedAssignment

    def _is_valid_date(self, d): #pylint: disable=R0201
        return TimeRange.NEGINFDATEC <= d <= TimeRange.POSINFDATEC

    def has_begin(self):
        return self._is_valid_date(self._range[0])

    def _get_begin(self):
        return self._range[0]

    def _set_begin(self, begin=None):
        " Set begin time for range "
        assert begin is None or isinstance(begin, datetime)

        if begin is None or begin<TimeRange.NEGINFDATEC:
            begin = TimeRange.NEGINFDATE

        self._range[0] = begin
    _set_begin.alters_data=True

    begin = property(_get_begin, _set_begin, _set_begin)

    def has_end(self):
        return self._is_valid_date(self._range[1])

    def _get_end(self):
        return self._range[1]

    def _set_end(self, end=None):
        " Set end time for range "
        assert end is None or isinstance(end, datetime)

        if end is None or end>TimeRange.POSINFDATEC:
            end = TimeRange.POSINFDATE

        self._range[1] = end
    _set_end.alters_data=True

    end = property(_get_end, _set_end, _set_end)

    def compare_time(self, when=None):
        """ Return -1 if date is before range,
            Returns 0 is date is in range,
            Return 1 if date is after range

            If when is None, the current time is used.
            If when is a datetime object, that date is used.
            If when is a timedelta object, now+when is used.
        """
        if when is None:
            when = timezone.now()
        elif isinstance(when, timedelta):
            when = timezone.now()+when
        elif not isinstance(when, datetime):
            raise TypeError, "Invalid type for when"

        if self._range[0] <= when <= self._range[1]:
            return 0
        elif when < self._range[1]:
            return 1
        else:
            return -1

    def is_before(self, when=None):
        """ Test whether given date is before this range
            An open range will always return False
            A closed range will always return True
        """
        return self.is_closed() or self.compare_time(when)>0

    def in_range(self, when=None):
        """ Test whether given date is in this range
            An open range will always return True
            A closed range will always return False
        """
        return self.compare_time(when)==0

    def is_after(self, when=None):
        """ Test whether given date is after this range
            An open range will always return False
            A closed range will always return True
        """
        return self.is_closed() or self.compare_time(when)<0

    def is_subrange(self, other):
        if other.is_closed():
            return False
        else:
            return other._range[0]>=self._range[0] and other._range[1]<=self._range[1] #pylint: disable=W0212

    @property
    def duration(self):
        if self.is_closed():
            return timedelta(0)
        return self._range[1]-self._range[0]

    def __add__(self, other):
        """ Add two timeranges.

            If either range is open, resulting range is open;
            If one range is closed, result is the other range;
            Otherwise, resulting range combines the two ranges.
        """
        if not isinstance(other, TimeRange):
            raise TypeError

        return TimeRange(begin=min(self.begin, other.begin),
                         end=max(self.end, other.end))

    def __sub__(self, other):
        """ Substract two timeranges.

            If either range is closed, resulting range is closed;
            If one range is open, result is the other range;
            Otherwise, resulting range is the overlap between the ranges.
            If the ranges do not overlap, the result is a closed range.
        """
        if not isinstance(other, TimeRange):
            raise TypeError

        return TimeRange(begin=max(self.begin, other.begin),
                         end=min(self.end, other.end))

    def __lt__(self, other):
        try:
            return self.__cmp__(other) < 0
        except TypeError:
            return False

    def __le__(self, other):
        try:
            return self.__cmp__(other) <= 0
        except TypeError:
            return False

    def __eq__(self, other):
        try:
            return self.__cmp__(other) == 0
        except TypeError:
            return False

    def __ne__(self, other):
        try:
            return self.__cmp__(other) != 0
        except TypeError:
            return True

    def __gt__(self, other):
        try:
            return self.__cmp__(other) > 0
        except TypeError:
            return False

    def __ge__(self, other):
        try:
            return self.__cmp__(other) >= 0
        except TypeError:
            return False

    def __cmp__(self, other): #pylint: disable=R0911,R0912
        if other is None:
            other = timezone.now()
        elif isinstance(other, timedelta):
            other = timezone.now()+other

        if isinstance(other, datetime):
            if self.in_range(other):
                return 0
            elif self.is_before(other):
                return -1
            else:
                return 1

        if isinstance(other, TimeRange):
            if self.is_open():
                if other.is_open():
                    return 0
                else:
                    return 1
            elif other.is_open():
                return -1

            if self.is_closed():
                if other.is_closed():
                    return 0
                else:
                    return -1
            elif other.is_closed():
                return 1

            return cmp( self.range, other.range )

        raise TypeError

    def __contains__(self, other):
        # "other in self"
        if isinstance(other, TimeRange):
            return self.is_subrange(other)
        else:
            return self.in_range(other)

    def __str__(self):
        if self.is_open():
            s = 'open'
        elif self.is_closed():
            s = 'closed'
        else:
            s = '%s .. %s' % (self._range[0] if self._range[0]>=TimeRange.NEGINFDATEC else '-INF',
                              self._range[1] if self._range[1]<=TimeRange.POSINFDATEC else '+INF')

        return s

    def __repr__(self):
        return 'TimeRange<%s>' % str(self)

    @classmethod
    def join(cls, *ranges):
        """ Calculate the combined timerange by overlapping the provided timeranges

        :param ranges: Two or more timeranges
        :return: TimeRange
        """
        # Collect the maximum begin and the minimum end date for all ranges.

        max_begin = cls.NEGINFDATE
        min_end = cls.POSINFDATE

        for r in ranges:
            max_begin = max(r.begin, max_begin)
            min_end = min(r.end, min_end)
            if max_begin > min_end:
                return TimeRange(closed=True)

        return TimeRange(begin=max_begin, end=min_end)

def queryset_filter_range(queryset, begin_field_name, end_field_name, date=None):
    """ Filter a queryset containing a range

    This will filter the queryset to return only those objects where the given date is in the range
    indicated by fields 'begin_field_name' and 'end_field_name'.

    If 'date' is None, current date and time is used.
    """

    from django.db.models import Q, F

    if date is None:
        date = timezone.now()

    #pylint: disable=C0103
    Qx = lambda f, q, v: Q(**{f+'__'+q: v})  # Qx(f,q,v) = Q(<f>__<q>=<v>)

    return queryset.filter(Qx(begin_field_name, 'lt', date) | Qx(begin_field_name, 'isnull', True))\
                   .filter(Qx(end_field_name, 'gt', date) | Qx(end_field_name, 'isnull', True))\
                   .exclude(Qx(begin_field_name, 'isnull', False) &
                            Qx(end_field_name, 'isnull', False) &
                            Qx(begin_field_name, 'gt', F(end_field_name)))
