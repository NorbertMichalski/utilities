from django.conf import settings
from django.core.exceptions import ImproperlyConfigured

# These are internal Django functions, so they could change with
# a newer version
from django.core.urlresolvers import get_mod_func
from django.utils.importlib import import_module
from django.utils.functional import memoize

from docutils.writers.html4css1 import Writer

from threading import local

#pylint: disable=C0103
_rstwriter_local = local()
_rstwriter_cache = {}

def set_rstwriter_class(name):
    _rstwriter_local.rstwriter_class = name

def import_rstwriter(name):
    #from peach3.core.rst.writers import RstWriterWrapper
    if name:
        mod_name, func_name = get_mod_func(name)
        return getattr(import_module(mod_name), func_name)()

import_rstwriter = memoize(import_rstwriter, _rstwriter_cache, 1)

def rst2html(source, source_path=None, language=None, writer=None):
    from docutils.core import publish_parts

    old_rstwriter_class = None

    if writer is None:
        rstwriter_class = getattr(_rstwriter_local, 'rstwriter_class', None)

        if isinstance(rstwriter_class, Writer):
            writer = rstwriter_class
        elif rstwriter_class:
            writer = import_rstwriter(rstwriter_class)

        if writer is None:
            raise ImproperlyConfigured, "rstwriter context not set up properly"

    else:
        old_rstwriter_class = getattr(_rstwriter_local, 'rstwriter_class')
        _rstwriter_local.rstwriter_class = writer

    docutils_settings = getattr(settings, 'RST_FILTER_SETTINGS', {})
    docutils_settings['halt_level']=5         # Don't throw exceptions
    docutils_settings['warning_stream']=''    # Don't produce output on stderr
    docutils_settings['language']=language    # Used to link to or include the correct language versions
    docutils_settings['id_prefix']='rst-'     # Prefix all generated ids with 'rst-'

    result = publish_parts(source=source, source_path=source_path,
                           writer=writer,
                           settings_overrides=docutils_settings)

    if old_rstwriter_class:
        _rstwriter_local.rstwriter_class = old_rstwriter_class

    return result

__all__=['rst2html']
