from django.contrib.contenttypes.models import ContentType
from django.core.cache import cache
from django.utils.translation import ugettext as _, get_language, activate

from peach3.utils.uid import uidencode, uiddecode, UID_ESCAPE
from peach3.utils.cache import cache_key

from datetime import datetime

def construct_full_path(parent, path, mustexist=False):
    path = path.strip(' /')

    if parent is None:
        return '/'+path
    else:
        if hasattr(parent, 'get_uid'):
            ouid = parent.get_uid()
        else:
            ouid = None

        if ouid:
            ouids = '/'.join(uidencode(i) for i in ouid)
        else:
            ouids = '%s%d' % (UID_ESCAPE, parent.pk)

        ct = ContentType.objects.get_for_model(parent)

        path = '%s%d' % (UID_ESCAPE, ct.id)+'/'+'/'.join((ouids, path,))

        if mustexist:
            from peach3.models.wiki import Page

            # Check if page actually exists
            try:
                Page.objects.get_by_path(path)
            except Page.DoesNotExist:
                return None

        return path

def decode_full_path(full_path):
    from peach3.models.wiki import Page

    key = cache_key('peach3.utils.wiki.decode_full_path', full_path)
    result = cache.get(key)

    if result is None:
        full_path = full_path.lstrip(' /')

        if not full_path.startswith(UID_ESCAPE):
            ptype = None
            pid = None
            path = full_path.rstrip(' /')
        else:
            path_parts = full_path.split('/')

            if len(path_parts)<3:
                raise Page.DoesNotExist, u'%s (%s)' % (_(u'Page matching query does not exist'), _(u'Path incomplete'))

            try:
                ctid = path_parts.pop(0)[len(UID_ESCAPE):]
                ptype = ContentType.objects.get(pk=ctid)
            except ValueError:
                raise Page.DoesNotExist, u'%s (%s)' % \
                    (_(u'Page matching query does not exist'), _(u'ContentType incomplete'))
            except ContentType.DoesNotExist:
                raise Page.DoesNotExist, u'%s (%s)' % \
                    (_(u'Page matching query does not exist'), _(u'ContentType invalid'))

            head = path_parts[0]
            if len(head)>1 and head[0]==UID_ESCAPE and head[1].isdigit():
                try:
                    pid = int(head[1:])
                except ValueError:
                    raise Page.DoesNotExist, u'%s (%s)' % (_(u'Page matching query does not exist'), _(u'ID invalid'))

                path_parts.pop(0)
            else:
                model = ptype.model_class()

                if not hasattr(model, 'get_uid_fields'):
                    raise Page.DoesNotExist, u'%s (%s)' % (_(u'Page matching query does not exist'), _(u'ID invalid'))

                fields = model.get_uid_fields()

                latest_by_created=False
                kwargs = {}
                for field in fields:
                    if path_parts:
                        value = uiddecode(path_parts.pop(0))
                    else:
                        value = ''

                    if value=='' and field=='created':
                        latest_by_created=True
                    elif value is None:
                        kwargs['%s__isnull' % field] = True
                    else:
                        if field=='created':
                            # Convert value to a datetime object
                            # Format of value 'YYYYMMDDhhmmss'
                            value = datetime.strptime(value, "%Y%m%d%H%M%S")
                        kwargs[field] = value

                pid = None
                try:
                    q = model.objects.filter(**kwargs)
                    if latest_by_created:
                        pid = q.latest().id
                    else:
                        ids = q.values_list('id', flat=True)
                        if len(ids)==1:
                            pid = ids[0]
                        elif len(ids)>1:
                            raise Page.DoesNotExist, u'%s (%s)' \
                                % (_(u'Page matching query does not exist'), _(u'Multiple parents match'))
                except model.DoesNotExist:
                    pass

                if pid is None:
                    raise Page.DoesNotExist, u'%s (%s)' % \
                        (_(u'Page matching query does not exist'), _(u'Parent not found'))

            while len(path_parts)>0 and path_parts[-1]=='':
                path_parts.pop()

            path = '/'.join(path_parts)

        if ptype:
            parent = ptype.get_object_for_this_type(pk=pid)
        else:
            parent = None

        result = parent, path

        cache.set(key, result)

    return result

def user_can_create_page(user, parent, path):
    if user.is_anonymous():
        return False
    elif user.is_superuser:
        return True
    elif user.has_perm('wiki.add_page'):
        return True

    if parent and hasattr(parent, 'has_access') and parent.has_access(user, 'createwiki'):
        return True

    # Find a parent page
    pathparts = path.strip(' /').split('/')
    if parent:
        args={'parent':parent}
    else:
        args={'parent__isnull':True}

    while len(pathparts)>0:
        from peach3.models.wiki import Page

        pathparts.pop()
        path = '/'.join(pathparts)
        try:
            parentpage = Page.objects.get(path=path, **args)
            if parentpage.is_editor(user):
                return True
        except Page.DoesNotExist:
            pass

    return False

def get_formatted_title(path):
    title = u''
    last_was_upper=None
    for c in path:
        if c=='/':
            break
        elif c.isupper() and last_was_upper is not None and not last_was_upper:
            title += ' '
        title += c
        last_was_upper = c.isupper()

    return title

def get_default_title(parent, path):
    # Generate default wiki title

    if parent:
        title = unicode(parent)
    else:
        title = ''

    if path:
        for part in path.split('/'):
            if part:
                parttitle = get_formatted_title(part)

                if title:
                    title += ': '+parttitle
                else:
                    title = parttitle

    if not title:
        title = _("No such page")

    return title

def get_initial_text(parent, path, lang=None):
    title = get_default_title(parent, path)

    # Get the body text in the correct language
    session_lang = get_language()
    if lang and lang != session_lang:
        activate(lang)
    body = _("This page has not been created yet.")
    if lang and lang != session_lang:
        activate(session_lang)

    sep = '='*(len(title)+2)
    return u'%s\n %s\n%s\n\n%s\n' % (sep, title, sep, body)
