from threading import local

# thread local support
_thread_locals = local() #pylint: disable=C0103

def set_current_user(user):
    """
    Assigns current user from request to thread_locals, used by
    CurrentUserMiddleware.
    """
    _thread_locals.user=user

def get_current_user():
    """
    Returns current user, or None
    """
    return getattr(_thread_locals, 'user', None)
