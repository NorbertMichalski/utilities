from django.conf import settings

class RedisFactory(object):
    "A factory to create a Redis connection"

    def __init__(self, redis_settings):
        self.settings = redis_settings
        self.redis = None

    def __call__(self):
        if self.redis is None:
            # Import redis using absolute import
            redis_mod = __import__('redis', globals(), locals(), [], 0)

            self.redis = redis_mod.StrictRedis(host=self.settings['host'],
                                               port=self.settings['port'],
                                               db=self.settings.get('db'),
                                               password=self.settings.get('password'))
        return self.redis

redis_factory = RedisFactory(settings.REDIS_CONNECTION_SETTINGS) #pylint: disable=C0103

def redis_key(*parts):
    prefix = settings.REDIS_CONNECTION_SETTINGS.get('prefix')
    key = ':'.join(str(x) for x in parts)
    if prefix:
        return prefix+':'+key
    return key
