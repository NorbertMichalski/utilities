""" This file is part of PEACH.

    Copyright (C) 2006-2009 Eindhoven University of Technology
"""
from __future__ import absolute_import # To import the system json module

from django.core.serializers import serialize
from django.core.serializers.json import DjangoJSONEncoder
from django.db.models.query import QuerySet
from django.http import HttpResponse
from django.test import TestCase

from peach3_ui_extjs2.utils.dates import format_date

from datetime import tzinfo, datetime
import json

__all__ = ('jsonencode', 'HttpResponseJSONbody', 'HttpResponseJSONheader')

class PeachJSONEncoder(DjangoJSONEncoder):
    def default(self, o):
        if isinstance(o, tzinfo):
            return str(o)

        elif isinstance(o, datetime):
            return format_date(o)

        else:
            return super(PeachJSONEncoder, self).default(o)

def jsonencode(obj, **jsonopts):
    """ JSON encode obj.
        obj can be a basic Python types or QuerySet
    """
    if isinstance(obj, QuerySet):
        return serialize('json', obj, **jsonopts)
    else:
        return json.dumps(obj, cls=PeachJSONEncoder, **jsonopts)

class HttpResponseJSONbody(HttpResponse): #pylint: disable=R0924
    """ Return a JSON response with the JSON encoded in the response body
    """
    def __init__(self, obj, mimetype="application/json; charset=utf-8", **jsonopts):
        HttpResponse.__init__(self,
                              content=jsonencode(obj, **jsonopts),
                              mimetype=mimetype)

class HttpResponseJSONheader(HttpResponse): #pylint: disable=R0924
    """ Return a JSON response with the JSON encoded in the X-JSON header,
        and content in the body
    """
    def __init__(self, obj, content='', mimetype=None, **jsonopts):
        HttpResponse.__init__(self,
                              content=content,
                              mimetype=mimetype)
        self.headers['X-JSON'] = jsonencode(obj, **jsonopts) #pylint: disable=E1101

class PeachTestCase(TestCase): #pylint: disable=R0904
    #pylint: disable=C0103

    def decodeJSON(self, response): #pylint: disable=R0201
        if not hasattr(response, 'decoded_json'):
            response.decoded_json = json.JSONDecoder().decode(response.content)
        return response.decoded_json

    def assertJSON(self, response, key, status_code=200):
        self.assertEqual(response.status_code, status_code,
            "Couldn't retrieve page: Response code was %d (expected %d)'" %
                (response.status_code, status_code))
        json = self.decodeJSON(response)

        self.assert_(key in json, "JSON response does not contain expected key %r" % key)
        self.assert_(json.get(key), "JSON response key %r failed" % key)

    def assertJSONFalse(self, response, key, status_code=200):
        self.assertEqual(response.status_code, status_code,
            "Couldn't retrieve page: Response code was %d (expected %d)'" %
                (response.status_code, status_code))
        json = self.decodeJSON(response)

        self.assert_(key in json, "JSON response does not contain expected key %r" % key)
        self.assertFalse(json.get(key), "JSON response key %r succeeded but should have failed" % key)

    def assertJSONEqual(self, response, key, value, status_code=200):
        self.assertEqual(response.status_code, status_code,
            "Couldn't retrieve page: Response code was %d (expected %d)'" %
                (response.status_code, status_code))
        json = self.decodeJSON(response)

        self.assert_(key in json, "JSON response does not contain expected key %r" % key)

        keyValue = json.get(key)
        self.assertEqual(keyValue, value,
                         "JSON response key %r was %r (expected %r)" % (key, value, keyValue))
