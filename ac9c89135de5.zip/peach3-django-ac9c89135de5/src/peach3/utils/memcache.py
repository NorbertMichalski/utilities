def make_memcache_key(*args):
    from django.core.cache.backends.base import default_key_func

    key = default_key_func(*args)

    if len(key) >= 250:
        # 250 is max length for a key in memcached
        import hashlib

        h = hashlib.md5(key).hexdigest()

        return key[:125 - len(h) / 2 - 1] + '|' + h + '|' + key[-125 + len(h) / 2 + 1:]

    return key
