""" This file is part of PEACH.

    Copyright (C) 2006-2009 Eindhoven University of Technology
"""
from django.contrib.auth import get_user_model
from django.db import transaction
from django.db.models import Q
from django.utils.translation import ugettext as _
from django.utils import timezone

def order_submissions(sb1, sb2):
    def _get_user_date(sb):
        " Get date of last manual action on submission "
        if sb and sb.submitted:
            # if submitted_by is None, the submit was done automatically
            if sb.submitted_by:
                return sb.submitted
            else:
                return sb.created

        return None

    d1, d2 = _get_user_date(sb1), _get_user_date(sb2)

    if d1 and d2:
        if d1==d2:
            return cmp(sb1.created, sb2.created)
        else:
            return cmp(d1, d2)
    else:
        return -cmp(d1 is None, d2 is None)

def get_submission_state(submission, user, author=None):
    """ Get submission state for 'author' as visible to 'user'.
    Author may be None; if the 'user' is an author, they will see their own state,
    if 'user' is not an author, they will see the global state for the submission.

    :param submission: Submission to get the state of
    :param user: Current user
    :param author: (optional) Author to show state of.
    :return: tuple: (state, last_review)
    :raises: AssertionError if 'author' is provided but not an author of the submission
    """
    if author is None:
        if submission.is_author(user):
            author = user
    else:
        assert submission.is_author(author)

    state = submission.get_state(author)

    try:
        last_review = submission.review_set.select_related('grade', 'created_by').latest()
    except submission.review_set.model.DoesNotExist:
        last_review = None

    if not submission.is_observer(user):
        # Authors can't see some states
        if state == 'SYSFAIL':
            state = 'CHECK'
        elif state == 'REVIEWING':
            state = 'REVIEW'
        elif last_review and not last_review.is_published():
            state = 'REVIEW'
            last_review = None

    elif last_review and last_review.visibilitylevel > (submission.get_reviewlevel(user) or 0):
        # Lower level reviewers cannot see draft reviews of higher level reviewers
        state = 'REVIEWING'

    return state, last_review

def visible_submission_state(state, last_review):
    icon = None
    if state=='':
        # Handle uninitialized state as NEW
        state='NEW'

    if state=='NEW':
        msg = _("New")
        longmsg = _("New submission in progress")

    elif state=='CHECK':
        msg = _("Queued")
        longmsg = _("Queued for processing")

    elif state=='SYSFAIL':
        msg = _("System failure")
        longmsg = msg

    elif state=='CHECKING':
        msg = _("Checking")
        longmsg = _("Being checked")

    elif state=='REVIEW':
        msg = _("Wait for review")
        longmsg = _("Waiting for review")

    elif state=='REVIEWING':
        msg = _("Reviewing")
        if last_review:
            longmsg = _("Being reviewed by %s") % last_review.created_by.get_full_name()
        else:
            longmsg = _("Being reviewed")

    elif state=='REVOKED':
        msg = _("Revoked")
        longmsg = _("Revoked by author")

    elif last_review:
        grade = last_review.grade
        if grade:
            icon, msg = grade.icon, grade.name
        else:
            icon, msg = 'reviewing', _("Reviewing")

        if not last_review.is_published():
            if grade:
                msg = '%s (%s)' % (msg, _("Draft"))
            longtxt = _("Being reviewed by %s")
        else:
            longtxt = _("Reviewed by %s")

        longmsg = "%s\n%s" % (msg, longtxt % last_review.created_by.get_full_name())

    elif state=='ACCEPTED':
        msg = _("Accepted")
        longmsg = _("Accepted automatically")

    elif state=='REJECTED':
        msg = _("Rejected")
        longmsg = _("Rejected automatically")

    else:
        raise ValueError, "Invalid submission state '%s'" % state

    if not icon:
        icon=state.lower()

    return icon, msg, longmsg

def filter_active_submission(subs, author):
    from peach3.models.submission import SubmissionAuthor
    try:
        return SubmissionAuthor.objects.get(author=author,
                                            submission__in=subs,
                                            active=True).submission
    except (SubmissionAuthor.DoesNotExist,
            SubmissionAuthor.MultipleObjectsReturned):
        latest = None
        for sb in subs:
            if not latest or order_submissions(sb, latest)>0:
                latest = sb
        return latest

def get_user_coauthors(user, ae, **sbfilter):
    """ Returns a User queryset of all co-authors of this user for the given assignment
        **sbfilter allows additional filtering of the submission
    """
    from peach3.models.submission import Submission

    sbs = Submission.objects.filter(assignmentedition=ae, authors=user, **sbfilter)

    return get_user_model().objects.filter(submission__in=sbs).exclude(pk=user.pk).distinct()

def get_available_coauthors(ae, before=None):
    """ Returns a User queryset of all available co-authors for the given assignment
            members of the same course that are not yet (co)author of a submission
            for the same assignment

        Argument "before" filters the submissions considered

        Course staff, members that have deactivated their membership and inactive users
        will not be listed
    """
    from peach3.models.submission import Submission

    # Available as co-author are:
    #  Active members of the course,
    #  that are not part of a group submission (ie a submission with more than one author)

    # Select all group submissions for this assignment
    sbs = Submission.objects.filter(assignmentedition=ae, is_group=True)

    # .filter(is_group=True) is identical, but faster, than
    # .annotate(authors_count=Count('authors').filter(authours_count__gt=1)

    if before:
        sbs = sbs.filter(submitted__lte=before)

    return ae.courseedition.get_active_members().exclude(submission__in=sbs)

@transaction.commit_on_success
def modify_authors(sb, authors):
    """ For a given submission and it's predecessors and successors, modify the
        authors such that the constraints remain correct.
    """
    from peach3.models.submission import Submission
    User = get_user_model()

    submitted = sb.submitted or timezone.now()

    new_authors = set(authors.values_list('pk', flat=True))
    old_authors = set(sb.authors.values_list('pk', flat=True))

    added = new_authors-old_authors
    removed = old_authors-new_authors

    all_submissions = Submission.objects.filter(assignmentedition=sb.assignmentedition,
                                                authors__in=sb.authors.all())

    updated_sbs = set()

    if added:
        added_users = User.objects.filter(pk__in=added)
        for newersb in all_submissions.exclude(submitted__lt=submitted):
            newersb.add_author(*added_users)

    if removed:
        older_submissions = all_submissions.exclude(submitted__gt=submitted)\
                                           .exclude(submitted__isnull=True)
        for au in User.objects.filter(pk__in=removed):
            for oldersb in older_submissions.filter(authors=au):
                if oldersb.authors.count()>1:
                    oldersb.remove_author(au)
                    updated_sbs.add(oldersb.pk)

    for sb in all_submissions.filter(pk__in=updated_sbs):
        sb.save(update_fields=['modified']) # Touch all submission's last modified timestamp

def get_submission_peerreviews(user, sb, with_flagged=False):
    from peach3.models.peerreview import PeerReviewAssignment

    is_observer = user.is_superuser or sb.is_observer(user)

    peerreviews = sb.peerreview_set.all()

    if not is_observer:
        # Filter out unpublished (#1) and empty (#2) peer reviews for authors
        published_prassignments = PeerReviewAssignment.objects\
                                                      .filter(original_assignment=sb.assignmentedition)\
                                                      .published()

        peerreviews = (peerreviews.filter(bundle__assignment__in=published_prassignments) #1
                                  .filter(Q(review__isnull=False)
                                         |Q(submission_grade__isnull=False)
                                         |Q(rank__isnull=False) #2
                      )                  )

    # Filter flagged peer reviews if 'with_flagged' is False
    if not with_flagged:
        peerreviews = peerreviews.filter(submission_flag__isnull=True)

    return peerreviews
