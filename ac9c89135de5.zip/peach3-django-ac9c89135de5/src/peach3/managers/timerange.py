from django.db.models import Manager
from django.db.models.query import QuerySet

from peach3.utils.dates import TimeRange, queryset_filter_range

class TimeRangeQuerySet(QuerySet): #pylint: disable=R0904,R0924
    def filter_in_range(self, date=None):
        """ Filters timeranges that are in range
        If date is None, current date is used
        """
        return queryset_filter_range(self, '_begin', '_end', date)

    def get_timerange(self):
        objs = list(self)

        if len(objs)==1:
            # Optimization for most common case
            return objs[0].range

        # Combine filtered timeranges
        tr = TimeRange(closed=True)
        for obj in objs:
            tr += obj.range

        return tr

class TimeRangeAbstractManager(Manager): #pylint: disable=R0904
    def get_query_set(self):
        return TimeRangeQuerySet(self.model, using=self._db)

    def filter_in_range(self, date=None):
        return self.get_query_set().filter_in_range(date)
    filter_in_range.__doc__ = TimeRangeQuerySet.filter_in_range.__doc__

    def get_timerange(self, **kwargs):
        return self.filter(**kwargs).get_timerange()

    def set_timerange(self, range, **kwargs): #@ReservedAssignment pylint: disable=W0622
        if range.is_closed():
            # Delete any existing row
            self.filter(**kwargs).delete()

        else:
            # Create new row or update existing row
            begin = range.begin if range.has_begin() else None
            end = range.end if range.has_end() else None

            obj, created = self.get_or_create(defaults={
                                                  '_begin' : begin,
                                                  '_end' : end,
                                              },
                                              **kwargs)
            if not created:
                #pylint: disable=W0212
                obj._begin = begin
                obj._end = end
                obj.save(update_fields=['_begin', '_end'])
