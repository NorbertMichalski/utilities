from django.contrib.contenttypes.models import ContentType
from django.core.exceptions import PermissionDenied
from django.db.models import Manager
from django.db.models.query import QuerySet
from django.utils import timezone

from peach3.utils.wiki import decode_full_path, user_can_create_page
from peach3.utils.ppk import PPKQuerySetMixin, PPKManagerMixin

class PageQuerySet(QuerySet, PPKQuerySetMixin): #pylint: disable=R0904,R0924
    def create(self, user, path='', parent=None, **kwarg):
        path = path.strip('/ ')

        # See http://code.djangoproject.com/ticket/7551
        if parent:
            kwarg['parent'] = parent

        if not user_can_create_page(user, parent, path):
            raise PermissionDenied

        return super(PageQuerySet, self).create(path = path,
                                                created = timezone.now(),
                                                created_by = user,
                                                **kwarg
                                               )

    def get(self, **kwarg):
        if 'parent' in kwarg:
            parent = kwarg.pop('parent')
            assert parent
            kwarg['parent_type'] = ContentType.objects.get_for_model(parent)
            kwarg['parent_id'] = parent.pk
        elif 'parent__isnull' in kwarg:
            kwarg['parent_type__isnull'] = kwarg.pop('parent__isnull')

        return super(PageQuerySet, self).get(**kwarg)

    def get_by_path(self, full_path):
        parent, path = decode_full_path(full_path)

        query = {'path':path}

        if parent:
            query['parent'] = parent
        else:
            query['parent__isnull'] = True

        return self.get(**query)

    def filter_parent(self, parent):
        if parent is None:
            return self.filter(parent_type__isnull=True)
        else:
            pt = ContentType.objects.get_for_model(parent)
            return self.filter(parent_type=pt, parent_id=parent.pk)

class PageManager(Manager, PPKManagerMixin): #pylint: disable=R0904
    def get_query_set(self):
        return PageQuerySet(self.model, using=self._db)

    def create(self, user, path='', parent=None, **kwarg):
        return self.get_query_set().create(user, path, parent, **kwarg)

    def get(self, **kwarg):
        return self.get_query_set().get(**kwarg)

    def get_by_path(self, full_path):
        return self.get_query_set().get_by_path(full_path)

    def filter_parent(self, parent):
        return self.get_query_set().filter_parent(parent)

class PageRevisionTextQuerySet(QuerySet): #pylint: disable=R0904,R0924
    def __update_arg(self, kwarg): #pylint: disable=R0201
        if 'content' in kwarg:
            kwarg['diff_base'] = None
            kwarg['content_or_diff'] = kwarg.pop('content')

    def create(self, **kwarg):
        self.__update_arg(kwarg)
        return super(PageRevisionTextQuerySet, self).create(**kwarg)

    def get_or_create(self, **kwarg):
        self.__update_arg(kwarg)
        if kwarg['diff_base'] is None:
            del kwarg['diff_base']
            kwarg['diff_base__isnull'] = True
            kwarg['defaults'] = {'diff_base':None}

        return super(PageRevisionTextQuerySet, self).get_or_create(**kwarg)

class PageRevisionTextManager(Manager): #pylint: disable=R0904
    def get_query_set(self):
        return PageRevisionTextQuerySet(self.model, using=self._db)

class PageRevisionQuerySet(QuerySet): #pylint: disable=R0904,R0924
    def create(self, *arg, **kwarg):
        from ..models.wiki import PageRevisionText

        if 'created' not in kwarg:
            kwarg['created'] = timezone.now()

        if 'content' in kwarg:
            #page = kwarg['page']
            content = kwarg.pop('content')
            markup = kwarg.pop('markup')
            assert markup, "Markup required in combination with content"
            kwarg['text'] = PageRevisionText.objects.get_or_create(markup=markup, content=content)[0]

        return super(PageRevisionQuerySet, self).create(*arg, **kwarg)

class PageRevisionManager(Manager): #pylint: disable=R0904
    def get_query_set(self):
        return PageRevisionQuerySet(self.model, using=self._db)

    def create(self, *arg, **kwarg):
        return self.get_query_set().create(*arg, **kwarg)

#    @transaction.commit_on_success
#    def revert_to(self, revision, user, reason):
#        assert isinstance(revision, PageRevision)
#
#        new_revision = super(PageRevisionManager, self).create(page=revision.page,
#                                                               created_by=user,
#                                                               changes=reason)
#
#        l = list(revision.pagerevisiontext_set.all())
#        new_revision.pagerevisiontext_set.add(*l)
#
#        return new_revision

