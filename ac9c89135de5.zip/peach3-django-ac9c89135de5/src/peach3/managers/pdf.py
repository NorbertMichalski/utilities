from django.db import models
from django.contrib.contenttypes.models import ContentType

from pdfviewer.models import PDFInfoManager

import os.path
import hashlib

class RefPDFInfoManager(PDFInfoManager): #pylint: disable=R0904
    def create(self, ref, path, **kwargs):
        try:
            ct = ContentType.objects.get_for_model(ref)
        except ContentType.DoesNotExist:
            raise TypeError

        path = os.path.abspath(path)
        pathhash = hashlib.md5(path).hexdigest()

        # Directly call models.Manager, skip PDFInfoManager.create
        obj = models.Manager.create(self, ref_ct=ct, ref_id=ref.pk,
                                          path=path, hash=pathhash,
                                          **kwargs)
        self._init_obj(path, obj)

        return obj

    def get_or_create(self, ref, path, **kwargs):
        try:
            ct = ContentType.objects.get_for_model(ref)
        except ContentType.DoesNotExist:
            raise TypeError

        path = os.path.abspath(path)
        pathhash = hashlib.md5(path).hexdigest()

        defaults = kwargs.pop('defaults', {})
        defaults['path'] = path
        defaults['hash'] = pathhash

        # Directly call models.Manager, skip PDFInfoManager.get_or_create
        obj, created = models.Manager.get_or_create(self, ref_ct=ct, ref_id=ref.pk,
                                                          defaults=defaults,
                                                          **kwargs)
        if created:
            self._init_obj(path, obj)

        elif obj.hash != pathhash or obj.path != path:
            obj.path = path
            obj.hash = pathhash
            obj.save(update_fields=['path', 'hash'])

        return obj, created
