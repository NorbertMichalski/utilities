from django.db.models import Manager, Q
from django.db.models.query import QuerySet

from peach3.utils.dates import queryset_filter_range
from peach3.utils.ppk import PPKQuerySetMixin, PPKManagerMixin

class PeerReviewAssignmentQuerySet(QuerySet, PPKQuerySetMixin): #pylint: disable=R0904,R0924
    def published(self, when=None):
        " Filter PeerReviewAssignments for which the reviews are to be published "
        return queryset_filter_range(self, '_review_result_visible_from', '_review_result_visible_until', when)\
                 .filter( Q(feedback_report=True)
                        | Q(feedback_rank=True)
                        | Q(feedback_grade=True)
                        )

class PeerReviewAssignmentManager(Manager, PPKManagerMixin): #pylint: disable=R0904
    def get_query_set(self):
        return PeerReviewAssignmentQuerySet(self.model, using=self._db)

    def published(self, when=None):
        return self.get_query_set().published(when)
    published.__doc__ = PeerReviewAssignmentQuerySet.published.__doc__

class PeerReviewQuerySet(QuerySet, PPKQuerySetMixin): #pylint: disable=R0904,R0924
    def published(self, when=None):
        " Filter PeerReviews for which the reviews are to be published "
        from peach3.models.peerreview import PeerReviewAssignment
        return self.filter(bundle__assignment__in=PeerReviewAssignment.objects.published(when))

class PeerReviewManager(Manager, PPKManagerMixin): #pylint: disable=R0904
    def get_query_set(self):
        return PeerReviewQuerySet(self.model, using=self._db)

    def published(self, when=None):
        return self.get_query_set().published(when)
    published.__doc__ = PeerReviewQuerySet.published.__doc__

