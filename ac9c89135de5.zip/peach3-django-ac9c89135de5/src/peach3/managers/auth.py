from django.contrib.auth.models import UserManager as OriginalUserManager
from django.db import IntegrityError, transaction, DatabaseError
from django.utils import timezone, six

from peach3.utils.ppk import PPKManagerMixin, PPKQuerySet

import sys

class UserManager(OriginalUserManager, PPKManagerMixin):
    def create_or_update_user(self, username, email=None, password=None,
                              is_active=None, is_staff=None, is_superuser=None,
                              **extra_fields):
        """
        Create a new user, if a user with the same username already exists, update that account.

        :param username: User's username
        :param email: User's email
        :param password: User's password
        :param is_active: User's is_active state (see note)
        :param is_staff: User's is_staff state (see note)
        :param is_superuser: User's is_superuser state (see note)
        :param extra_fields: Any other field to set or update on the User object
        :return: user, created

        Note for `is_active`, `is_staff` and `is_superuser`:
        If this is a boolean, the value will be set on the User object. If this value is None, it will default
        to False for a created User, but will not change the existing value for an updated user.
        """
        if not username:
            raise ValueError('The given username must be set')

        email = self.normalize_email(email)

        try:
            user = self.get(username=username)

        except self.model.DoesNotExist:
            try:
                # Create new user account
                now = timezone.now()
                user = self.model(
                    username=username,
                    email=email,
                    is_active=bool(is_active),
                    is_staff=bool(is_staff),
                    is_superuser=bool(is_superuser),
                    last_login=now,
                    date_joined=now,
                    **extra_fields
                )
                user.set_password(password)

                sid = transaction.savepoint(using=self._db)
                user.save(using=self._db)
                transaction.savepoint_commit(sid, using=self._db)
                return user, True

            except IntegrityError:
                # It seems the user was just created by another thread
                exc_info = sys.exc_info()

                try:
                    transaction.savepoint_rollback(sid, using=self._db)
                except DatabaseError:
                    pass

                try:
                    user = self.get(username=username)

                except self.model.DoesNotExist:
                    # Re-raise the IntegrityError with its original traceback.
                    six.reraise(*exc_info)

        # Update existing user's details
        for key, value in extra_fields.iteritems():
            setattr(user, key, value)

        # Only update 'is_active', 'is_staff' and 'is_superuser' if the values are not None
        if is_active is not None:
            user.is_active = is_active
        if is_staff is not None:
            user.is_staff = is_staff
        if is_superuser is not None:
            user.is_superuser = is_superuser

        user.email = email
        user.set_password(password)

        #noinspection PyBroadException
        try:
            sid = transaction.savepoint(using=self._db)
            user.save(using=self._db)
            transaction.savepoint_commit(sid, using=self._db)
            return user, False

        except:
            exc_info = sys.exc_info()

            try:
                transaction.savepoint_rollback(sid, using=self._db)
            except DatabaseError:
                pass

            six.reraise(*exc_info)

    def get_query_set(self):
        return PPKQuerySet(self.model, using=self._db)
