from django.db.models.query import QuerySet
from django.utils import timezone

from peach3.utils.dates import queryset_filter_range

from mptt.managers import TreeManager

class PeriodQuerySet(QuerySet): #pylint: disable=R0904,R0924
    def filter_active(self, date=None):
        """ Filters timeranges that are in range
        If date is None, current date is used
        """
        return queryset_filter_range(self, '_begin', '_end', date)

    def filter_available(self, date=None):
        """ Filters periods that are available ('open' ranges or end date has not passed)
        If date is None, current date is used
        """
        return self.filter(_end__gte=date or timezone.now())

class PeriodManager(TreeManager): #pylint: disable=R0904
    def get_query_set(self):
        return PeriodQuerySet(self.model, using=self._db)

    def filter_active(self, date=None):
        return self.get_query_set().filter_active(date)
    filter_active.__doc__ = PeriodQuerySet.filter_active.__doc__

    def filter_available(self, date=None):
        return self.get_query_set().filter_available(date)
    filter_available.__doc__ = PeriodQuerySet.filter_available.__doc__

    def rebuild(self):
        " Rebuild tree based on period dates "
        tree = []

        def _insert(t, p):
            # Insert period `p` in parent tree `t`
            # Requires that periods will be inserted with increasing begin dates and decreasing end dates
            for c in t:
                if p.range in c[0].range:
                    _insert(c[1], p)
                    return

            t.append((p, []))

        def _update(t, parent=None):
            # Make objects in `t` children of `parent` if they are not already
            reparent = []
            for c in t:
                # Recursively update children
                _update(c[1], c[0])

                # Check if `c` needs to be reparented
                if c[0].parent != parent:
                    reparent.append(c[0].pk)

            if reparent:
                self.filter(pk__in=reparent).update(parent=parent)

        # Build tree
        for p in self.all().order_by('_begin', '-_end'):
            _insert(tree, p)

        # Update database
        _update(tree)

        # Rebuild all the MPTT helper fields
        # Need to do this even if no reparenting was done, as the ordering could have changed
        super(PeriodManager, self).rebuild()
