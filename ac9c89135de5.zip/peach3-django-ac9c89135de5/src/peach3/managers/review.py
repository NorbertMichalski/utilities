from django.db.models import Manager, Q

from peach3.utils.permissions import get_current_user

from peach3.utils.ppk import PPKQuerySet, PPKManagerMixin

class ReviewQuerySet(PPKQuerySet): #pylint: disable=R0904,R0924
    def filter_visible_as_staff(self, user=None):
        """ Filter reviews that are visible to the provided user as staff
        """
        if user is None:
            user = get_current_user()

        if user.is_superuser:
            return self
        elif user.is_anonymous():
            return self.none()

        # subquery to get staff user's level
        staff_level_subquery = '''
            SELECT peach3_clusterstaff.level
              FROM peach3_clusterstaff
             WHERE peach3_clusterstaff.user_id = %s
               AND EXISTS (
                     SELECT 1
                       FROM peach3_submission_clusters
                      WHERE peach3_submission_clusters.cluster_id = peach3_clusterstaff.cluster_id
                        AND peach3_submission_clusters.submission_id = peach3_review.submission_id
                   )
        '''

        as_staff = self.extra(
                       where=['visibilitylevel <= ANY (%s)' % staff_level_subquery],
                       params=[user.id],
                   ).distinct()

        return self.filter(Q(created_by=user) | Q(pk__in=as_staff)).distinct()

class ReviewManager(Manager, PPKManagerMixin): #pylint: disable=R0904
    def get_query_set(self):
        return ReviewQuerySet(self.model, using=self._db)

    def filter_visible_as_staff(self, user=None):
        return self.get_query_set().filter_visible_as_staff(user)
    filter_visible_as_staff.__doc__= ReviewQuerySet.filter_visible_as_staff.__doc__
