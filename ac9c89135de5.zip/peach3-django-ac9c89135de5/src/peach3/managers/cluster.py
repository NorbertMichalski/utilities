from django.db import transaction
from django.db.models import Manager, Q

from peach3.utils.dates import TimeRange, queryset_filter_range
from peach3.utils.ppk import PPKQuerySet, PPKManagerMixin

class ClusterQuerySet(PPKQuerySet): #pylint: disable=R0904,R0924
    def filter_active(self, date=None):
        """ Filters clusters that are active (date in "active" range)
        If date is None, current date is used
        """
        return queryset_filter_range(self, '_active_from', '_active_until', date)

    def filter_joinable(self, date=None):
        """ Filters clusters that are joinable (date in "joinable" range)
        If date is None, current date is used
        """
        return queryset_filter_range(self, '_joinable_from', '_joinable_until', date).filter(admin_cluster=False,
                                                                                             test_cluster=False)

    def filter_user_is_member_of(self, user, include_admin=False):
        """ Filter clusters user is member of
        If `include_admin` is False (default), admin clusters are not included
        """
        if not include_admin:
            admin_filter = {'admin_cluster':False}
        else:
            admin_filter = {}

        return self.filter(clustermember__user=user, **admin_filter)

    def filter_user_is_staff_of(self, user, include_admin=False):
        """ Filter clusters user is staff of
        If `include_admin` is False (default), admin clusters are not included
        """
        q = Q(admin_cluster=False, clusterstaff__user=user)
        if include_admin:
            q |= Q(admin_cluster=True, clustermember__user=user)

        return self.filter(q)

class ClusterManager(Manager, PPKManagerMixin): #pylint: disable=R0904
    def get_query_set(self):
        return ClusterQuerySet(self.model, using=self._db)

    def filter_active(self, date=None):
        return self.get_query_set().filter_active(date)
    filter_active.__doc__= ClusterQuerySet.filter_active.__doc__

    def filter_joinable(self, date=None):
        return self.get_query_set().filter_joinable(date)
    filter_joinable.__doc__= ClusterQuerySet.filter_joinable.__doc__

    def filter_user_is_member_of(self, user, include_admin=False):
        return self.get_query_set().filter_user_is_member_of(user, include_admin)
    filter_user_is_member_of.__doc__= ClusterQuerySet.filter_user_is_member_of.__doc__

    def filter_user_is_staff_of(self, user, include_admin=False):
        return self.get_query_set().filter_user_is_staff_of(user, include_admin)
    filter_user_is_staff_of.__doc__= ClusterQuerySet.filter_user_is_staff_of.__doc__

    def get_aggregated_active(self, **kwargs): #@ReservedAssignment
        objs = self.filter(**kwargs)

        if len(objs)==1:
            return objs[0].active_range

        # Combine filtered timeranges
        tr = TimeRange(closed=True)
        for obj in objs:
            tr += obj.active_range

        return tr

    CLONED_FIELDS = [
        'courseedition',
        '_joinable_from',
        '_joinable_until',
        '_active_from',
        '_active_until',
        'default_name',
        'default_language',
    ]

    CLONED_M2M = [
        'realms',
        'subcodes',
    ]

    @transaction.commit_on_success
    def clone_from(self, old_cluster, **modified_fields):
        # Create a new cluster, based on the settings of an existing cluster
        ce = old_cluster.courseedition

        fields = {}
        for field_name in self.CLONED_FIELDS:
            fields[field_name] = modified_fields.get(field_name, getattr(old_cluster, field_name))

        # Make sure 'default_name' is unique
        base, postfix, postcounter = fields['default_name'], '', 0
        if '-' in base:
            # Continue on existing postcounter
            left, right = base.rsplit('-', 1)
            try:
                postcounter = int(right)
                base, postfix = left, '-%d' % postcounter
            except ValueError:
                pass

        while ce.cluster_set.filter(default_name=base+postfix).count()>0:
            postcounter += 1
            postfix = '-%d' % postcounter

        fields['default_name'] = base+postfix

        cluster = self.create(**fields)

        # Clone M2M fields
        for m2m in self.CLONED_M2M:
            setattr(cluster, m2m, modified_fields.get(m2m, getattr(old_cluster, m2m).all()))

        # Clone staff
        for staff in modified_fields.get('staff', old_cluster.clusterstaff_set.all()):
            if cluster.clusterstaff_set.filter(user=staff.user).count()==0:
                cluster.clusterstaff_set.create(
                    user=staff.user,
                    role=staff.role,
                    level=staff.level,
                    extend_deadline=staff.extend_deadline,
                )

        # Clone assignment deadlines
        for ae in ce.assignmentedition_set.all():
            ae.clone_timeranges(old_cluster, cluster)

        return cluster
