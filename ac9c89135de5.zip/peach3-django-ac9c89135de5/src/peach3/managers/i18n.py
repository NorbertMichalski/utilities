from django.db.models import Manager
from django.contrib.contenttypes.models import ContentType

class TranslatedNameManager(Manager): #pylint: disable=R0904
    def create_for_object(self, object, *args, **kwargs): #@ReservedAssignment pylint: disable=W0622
        return self.create(content_type = ContentType.objects.get_for_model(object),
                           object_id = object.pk,
                           *args, **kwargs)

    def get_by_object(self, object, *args, **kwargs): #@ReservedAssignment pylint: disable=W0622
        return self.get(content_type = ContentType.objects.get_for_model(object),
                        object_id = object.pk,
                        *args, **kwargs)

    def filter_by_object(self, object, *args, **kwargs): #@ReservedAssignment pylint: disable=W0622
        return self.filter(content_type = ContentType.objects.get_for_model(object),
                           object_id = object.pk,
                           *args, **kwargs)

    def get_or_create_by_object(self, object, *args, **kwargs): #@ReservedAssignment pylint: disable=W0622
        return self.get_or_create(content_type = ContentType.objects.get_for_model(object),
                                  object_id = object.pk,
                                  *args, **kwargs)

