from django.contrib.auth import get_user_model
from django.db.models import Q
from django.db.models.query import QuerySet
from django.utils import timezone

from peach3.utils.ppk import PPKQuerySetMixin, PPKManagerMixin

from mptt.managers import TreeManager

class AssignmentEditionQuerySet(QuerySet, PPKQuerySetMixin): #pylint: disable=R0904,R0924
    def _filter_range(self, rangetype, userOrCluster=None, date=None):
        from peach3.models.timerange import ClusterTimeRange, IndividualTimeRange
        User = get_user_model()

        if date is None:
            date = timezone.now()

        cluster_range = ClusterTimeRange.objects.filter(type=rangetype).filter_in_range(date)
        if userOrCluster is None:
            return self.filter(clustertimerange__in=cluster_range)

        elif isinstance(userOrCluster, User):
            cluster_range = cluster_range.filter(cluster__clustermember__user=userOrCluster)

            individual_range = IndividualTimeRange.objects.filter_in_range(date)\
                                                          .filter(type=rangetype, user=userOrCluster)

            return self.filter( Q(clustertimerange__in=cluster_range) | Q(individualtimerange__in=individual_range) )

        else:
            cluster_range = cluster_range.filter(cluster=userOrCluster)

            return self.filter(clustertimerange__in=cluster_range)

    def filter_open(self, userOrCluster=None, date=None):
        """ Filters assignments that are open (date in "open" range) for given user or cluster
        If clusterOrRange is None, filters for assignments that are open for at least one cluster
        If date is None, current date is used
        """
        from peach3.models.timerange import TimeRangeAbstractModel

        return self._filter_range(TimeRangeAbstractModel.TYPE_OPEN, userOrCluster, date)

    def filter_visible(self, userOrCluster=None, date=None):
        """ Filters assignments that are visible (date in "visible" range) for given user or cluster
        If clusterOrRange is None, filters for assignments that are visible for at least one cluster
        If date is None, current date is used
        """
        from peach3.models.timerange import TimeRangeAbstractModel

        return self._filter_range(TimeRangeAbstractModel.TYPE_VISIBLE, userOrCluster, date)

    def _annotate_range(self, name, rangetype, userOrCluster, date=None):
        candidates = list(self._filter_range(rangetype, userOrCluster, date).values_list('id', flat=True))
        if not candidates:
            subquery = '0'
        else:
            subquery = '`%s`.`id` IN (%s)' % (self.model._meta.db_table, #pylint: disable=W0212
                                              ','.join(str(cid) for cid in candidates)
                                             ) #@ReservedAssignment

        return self.extra(select={name:subquery})

    def annotate_open(self, name, userOrCluster=None, date=None):
        """ Annotate queryset with a boolean indicating if the assignment is open for the given user or
        cluster on the given date.
        If clusterOrRange is None, assignments that are open for at least one cluster are annotated with 'true'
        If date is None, current date is used
        """
        from peach3.models.timerange import TimeRangeAbstractModel

        return self._annotate_range(name, TimeRangeAbstractModel.TYPE_OPEN, userOrCluster, date)

    def annotate_visible(self, name, userOrCluster=None, date=None):
        """ Annotate queryset with a boolean indicating if the assignment is visible for the given user or
        cluster on the given date.
        If clusterOrRange is None, assignments that are visible for at least one cluster are annotated with 'true'
        If date is None, current date is used
        """
        from peach3.models.timerange import TimeRangeAbstractModel

        return self._annotate_range(name, TimeRangeAbstractModel.TYPE_VISIBLE, userOrCluster, date)

class AssignmentEditionManager(TreeManager, PPKManagerMixin): #pylint: disable=R0904
    def get_query_set(self):
        return AssignmentEditionQuerySet(self.model, using=self._db)

    def filter_open(self, userOrCluster=None, date=None):
        return self.get_query_set().filter_open(userOrCluster, date)
    filter_open.__doc__ = AssignmentEditionQuerySet.filter_open.__doc__

    def filter_visible(self, userOrCluster=None, date=None):
        return self.get_query_set().filter_visible(userOrCluster, date)
    filter_visible.__doc__ = AssignmentEditionQuerySet.filter_visible.__doc__

    def annotate_open(self, userOrCluster=None, date=None):
        return self.get_query_set().annotate_open(userOrCluster, date)
    annotate_open.__doc__ = AssignmentEditionQuerySet.annotate_open.__doc__

    def annotate_visible(self, userOrCluster=None, date=None):
        return self.get_query_set().annotate_visible(userOrCluster, date)
    annotate_visible.__doc__ = AssignmentEditionQuerySet.annotate_visible.__doc__
