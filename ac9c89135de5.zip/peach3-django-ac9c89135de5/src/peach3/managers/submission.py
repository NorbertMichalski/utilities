from django.contrib.auth import get_user_model
from django.core.cache import cache
from django.db import models
from django.db.models.query import QuerySet

from peach3.models.cluster import ClusterStaff
from peach3.utils.cache import cache_key
from peach3.utils.ppk import PPKQuerySetMixin, PPKManagerMixin

class SubmissionQuerySet(QuerySet, PPKQuerySetMixin): #pylint: disable=R0904,R0924
    " QuerySet for Submission "

    def __staff_action_by(self, field, user, role=None):
        " Internal generic function to handle all filter_XYZ_by functions "

        # subquery to get assignment's level
        assignment_level_subquery = '''
            SELECT peach3_assignmentedition.%s
              FROM peach3_assignmentedition
             WHERE peach3_assignmentedition.id = peach3_submission.assignmentedition_id
        ''' % field

        # subquery to get staff user's level
        staff_level_subquery = '''
            SELECT peach3_clusterstaff.level
              FROM peach3_clusterstaff
             WHERE peach3_clusterstaff.user_id = %s
               AND EXISTS (
                     SELECT 1
                       FROM peach3_submission_clusters
                      WHERE peach3_submission_clusters.cluster_id = peach3_clusterstaff.cluster_id
                        AND peach3_submission_clusters.submission_id = peach3_submission.id
                   )
        '''
        params = [user.id]

        if role:
            staff_level_subquery += ' AND peach3_clusterstaff.role = %s'
            params.append(role)

        # initial filtering on submissions to clusters user has staff access on
        if role:
            clusterstaff = ClusterStaff.objects.filter(user=user, role=role)
            q = self.filter(clusters__clusterstaff__in=clusterstaff)
        else:
            q = self.filter(clusters__clusterstaff__user=user)

        # filter remaining submissions on user's level
        return q.extra(
                   where=['(%s) <= ANY (%s)' % (assignment_level_subquery, staff_level_subquery)],
                   params=params,
               ).distinct()

    def filter_observable_by(self, user):
        " Filter submissions that are observable (as staff) by given user "
        return self.__staff_action_by('observelevel', user)

    def filter_reviewable_by(self, user):
        " Filter submissions that are reviewable by given user "
        return self.__staff_action_by('reviewlevel', user, ClusterStaff.ROLE_REVIEW)

    def filter_publishable_by(self, user):
        " Filter submissions that are reviewable by given user "
        return self.__staff_action_by('reviewpublishlevel', user)

class SubmissionManager(models.Manager, PPKManagerMixin): #pylint: disable=R0904
    " Manager for Submission "

    def get_query_set(self):
        return SubmissionQuerySet(self.model, using=self._db)

    def filter_observable_by(self, user): #pylint: disable=C0111
        return self.get_query_set().filter_observable_by(user)
    filter_observable_by.__doc__ = SubmissionQuerySet.filter_observable_by.__doc__

    def filter_reviewable_by(self, user): #pylint: disable=C0111
        return self.get_query_set().filter_reviewable_by(user)
    filter_reviewable_by.__doc__ = SubmissionQuerySet.filter_reviewable_by.__doc__

    def filter_publishable_by(self, user): #pylint: disable=C0111
        return self.get_query_set().filter_publishable_by(user)
    filter_publishable_by.__doc__ = SubmissionQuerySet.filter_publishable_by.__doc__

class SubmissionAuthorManager(models.Manager): #pylint: disable=R0904
    def __get_submission_state(self, sb, is_latest, autoaccept): #pylint: disable=R0911,R0912
        # If there is a review with a grade, that sets the state
        try:
            rev = sb.review_set.latest()
        except sb.review_set.model.DoesNotExist:
            pass
        else:
            if rev.grade:
                if rev.grade.passing:
                    return self.model.STATE_ACCEPTED
                else:
                    return self.model.STATE_REJECTED
            else:
                return self.model.STATE_REVIEWING

        # If there is a checkresult with a grade, that sets the state
        try:
            scr = sb.checkresult_set.latest()
        except sb.checkresult_set.model.DoesNotExist:
            pass
        else:
            if not scr.state:
                return self.model.STATE_CHECK
            elif scr.state=='SYSFAIL':
                return self.model.STATE_SYSFAIL
            elif scr.state=='CHECKING':
                return self.model.STATE_CHECKING
            elif scr.grade and not scr.grade.passing:
                return self.model.STATE_REJECTED

        if autoaccept:
            return self.model.STATE_ACCEPTED
        elif not is_latest:
            return self.model.STATE_REVOKED
        else:
            return self.model.STATE_REVIEW

    def update_assignmentedition(self, assignmentedition, users=None, exclude_pks=None): #pylint: disable=R0912,R0914
        """ Update the SubmissionAuthor objects for an assignment

        If `users` is provided and not None, only the SubmissionAuthor objects for
        those users are updated, otherwise all of them are updated.

        If `exclude_pks` is not None, it is a list of submissions ids to exclude,
        as if they do not exist
        """
        if users is None:
            users = get_user_model().objects.filter(submissionauthor__submission__assignmentedition=assignmentedition)\
                                            .distinct().iterator()

        autoaccept = bool(assignmentedition.has_option('REVIEW')
                          and assignmentedition.get_option_parameter('REVIEW',
                                                                     'autoaccept'))

        for user in users:
            states = {}            # Dict to collect the state of each submission
            active = None          # The active submission (most recent)
            latest_accepted = None # The most recent accepted submission

            submissions = assignmentedition.submission_set\
                                           .filter(submitted__isnull=True,
                                                   authors=user)

            if exclude_pks:
                submissions = submissions.exclude(pk__in=exclude_pks)

            # Handle 'NEW' submissions separately
            for sbpk in submissions.values_list('id', flat=True)\
                                   .order_by('-created'):

                states[sbpk] = self.model.STATE_NEW
                if not active:
                    active = sbpk

            # Iterate over each submitted submission, in reverse order
            submissions = assignmentedition.submission_set\
                                           .filter(submitted__isnull=False,
                                                   authors=user)

            if exclude_pks:
                submissions = submissions.exclude(pk__in=exclude_pks)

            is_latest = True
            for sb in submissions.select_related('review',
                                                 'review__grade',
                                                 'checkresult',
                                                 'checkresult__grade')\
                                 .order_by('-submitted')\
                                 .iterator():

                sbpk, state = sb.pk, self.__get_submission_state(sb, is_latest, autoaccept)

                states[sbpk], is_latest = state, False

                if not active:
                    active = sbpk

                if not latest_accepted and state in [self.model.STATE_ACCEPTED,
                                                     self.model.STATE_REVIEW]:
                    latest_accepted = sbpk

            sbaus = self.filter(submission__assignmentedition=assignmentedition,
                                author=user)

            for sbau in sbaus.iterator():
                sbpk = sbau.submission_id
                is_active = sbpk == active
                is_latest_accepted = sbpk == latest_accepted
                state = states.get(sbpk, sbau.state)

                # Update cached state
                key = cache_key('peach3.models.Submission.state', sbpk, user)
                cache_time = self.model.STATE_CACHE_TIME.get(state, 0)
                if cache_time>0:
                    cache.set(key, state, cache_time*60)
                else:
                    cache.delete(key)

                key = cache_key('peach3.models.Submission.state', sbpk, None)
                cache.delete(key)

                # Update SubmissionAuthor objects if any attribute has changed
                if state!=sbau.state \
                        or is_active!=sbau.active \
                        or is_latest_accepted!=sbau.latest_accepted:

                    sbau.state = state
                    sbau.active = is_active
                    sbau.latest_accepted = is_latest_accepted
                    sbau.save(update_fields=['state', 'active', 'latest_accepted'])

    def update_submission(self, submission, users=None, for_delete=False):
        """ Update the SubmissionAuthor objects for a submission

        If `users` is provided and not None, only the SubmissionAuthor objects for those users
        are updated, otherwise the objects of all the submission's authors are updated.

        If `for_delete` is True, the provided submission itself is assumed to not exist
        (as if already deleted)
        """
        if users is None:
            users = submission.authors.all()

        if for_delete:
            exclude_pks = [submission.pk]
        else:
            exclude_pks = None

        self.update_assignmentedition(submission.assignmentedition, users, exclude_pks)
