from django.db.models import Manager

from string import Template

class ReasonManager(Manager): #pylint: disable=R0904
    class NumTemplate(Template):
        """ A string.Template subclass accepting numbers as placeholder ids """
        idpattern=r"[0-9]+"

    def _get_by_code(self, code, **kwarg):
        codeparts = code.split(':')
        code = codeparts.pop(0)

        param = codeparts
        while len(param)<2:
            param.append('')

        try:
            reason = self.get(code=code, param1=param[0], param2=param[1], **kwarg)
        except self.model.DoesNotExist:
            pass
        else:
            return reason, param

        if param[0]:
            try:
                reason = self.get(code=code, param1='', param2=param[1], **kwarg)
            except self.model.DoesNotExist:
                pass
            else:
                return reason, param

        if param[1]:
            try:
                reason = self.get(code=code, param1=param[0], param2='', **kwarg)
            except self.model.DoesNotExist:
                pass
            else:
                return reason, param

        reason = self.get(code=code, param1='', param2='', **kwarg)
        return reason, param

    def create(self, code, **kwarg):
        codeparts = code.split(':')
        code = codeparts.pop(0)

        param = codeparts
        while len(param)<2:
            param.append('')

        return super(ReasonManager, self).create(code=code, param1=param[0], param2=param[1], **kwarg)

    def get_description(self, code, **kwarg):
        try:
            reason, param = self._get_by_code(code, **kwarg)
        except self.model.DoesNotExist:
            reason = self.create(code=code, default_description=code)
            param = '',''

        kws = {'0':param[0],
               '1':param[1]
              }
        return ReasonManager.NumTemplate(reason.description).safe_substitute(kws)

