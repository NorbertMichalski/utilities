from django.db.models import Manager
from django.contrib.contenttypes.models import ContentType
from django.utils.timezone import now

from datetime import timedelta

class NewsItemManager(Manager): #pylint: disable=R0904
    def create(self, **kwargs):
        rnow = now()

        kwargs.setdefault('created', rnow)
        kwargs.setdefault('appears', rnow)

        # Expires attribute can be a timedelta object which will be converted into a datetime object
        expires = kwargs.get('expires', timedelta(days=365))
        if isinstance(expires, timedelta):
            kwargs['expires'] = kwargs['appears'] + expires

        if kwargs['expires'] > rnow:
            return super(NewsItemManager, self).create(**kwargs)

    def filter_related(self, related, id=None): #@ReservedAssignment pylint: disable=W0622
        # Can be called in 3 ways:
        #    filter_related(object)
        #    filter_related(class)
        #    filter_related(class, id)
        q={
            'related_content_type' : ContentType.objects.get_for_model(related)
        }

        if hasattr(related, '__base__'):
            if id is not None:
                q['related_id'] = id
        else:
            q['related_id'] = related.pk

        return self.filter(**q)

