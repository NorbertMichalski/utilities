from peach3.utils.ppk import PPKManager

class GradeManager(PPKManager): #pylint: disable=R0904
    def get_boolean_accept(self):
        if not hasattr(self, '_accept'):
            self._accept = self.get(system__id=1, passing=True) #pylint: disable=W0201
        return self._accept
    accept = property(get_boolean_accept)

    def get_boolean_reject(self):
        if not hasattr(self, '_reject'):
            self._reject = self.get(system__id=1, passing=False) #pylint: disable=W0201
        return self._reject
    reject = property(get_boolean_reject)

