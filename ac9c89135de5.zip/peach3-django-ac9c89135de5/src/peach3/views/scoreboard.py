""" This file is part of PEACH.

    Copyright (C) 2006-2009 Eindhoven University of Technology
    Copyright (C) 2009 Eljakim Information Technology bv.
"""
from django.contrib.auth.decorators import login_required
from django.http import HttpResponse, HttpResponseForbidden
from django.shortcuts import get_object_or_404
from django.views.decorators.cache import cache_control, cache_page

from peach3.core.scoreboard import get_scores, get_assignments, get_assignmentsets
from peach3.models import CourseEdition

from csv import DictWriter
from StringIO import StringIO

@login_required
@cache_control(private=True, must_revalidate=True)
@cache_page(60*60)
def download(request, ceid, name): #pylint: disable=W0613
    user = request.user
    ce = get_object_or_404(CourseEdition, pk=ceid)

    # Check if user is observer of this course
    if ce.get_observelevel(user, '*') is None:
        return HttpResponseForbidden()

    scores = get_scores(ce, user)

    fields = ['rank', 'cluster', 'auid', 'user', 'name']
    captions = {
        'rank': 'Rank',
        'cluster': 'Cluster',
        'auid': 'UserID',
        'user': 'User',
        'name': 'Full name',
        'score': 'Score'
    }

    for ae in get_assignments(ce, user):
        fields.append("score%d" % ae.id)
        captions["score%d" % ae.id] = ae.get_display_name()

    for ass in get_assignmentsets(get_assignments(ce, user)):
        fields.append("scoreset%d" % ass.id)
        captions["scoreset%d" % ass.id] = ass.get_display_name()

    fields.append('score')

    outp = StringIO()
    writer = DictWriter(outp, fields)
    writer.writerow(captions)
    writer.writerows(scores)

    response = HttpResponse(outp.getvalue(), mimetype='text/csv')
    response['Content-Disposition'] = 'attachment; filename="%s";' % 'scores.csv'
    return response
