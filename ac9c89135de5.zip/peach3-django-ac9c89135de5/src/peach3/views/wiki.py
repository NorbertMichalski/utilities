""" This file is part of PEACH.

    Copyright (C) 2006-2009 Eindhoven University of Technology
"""
from peach3.models import Page, PageRevision
from peach3.utils.rst import rst2html

from django.http import Http404, HttpResponseForbidden
from django.shortcuts import render_to_response
from django.template import RequestContext

def view(request, path, startPrint=False):
    user = request.user

    try:
        page = Page.objects.get_by_path(path)
    except Page.DoesNotExist:
        raise Http404()

    if not page.has_access(user):
        return HttpResponseForbidden()

    lang = request.GET.get('lang')

    try:
        text = page.get_latest(language=lang).text
        if text:
            content = text.content
        else:
            content = None
    except PageRevision.DoesNotExist:
        content = None

    if content is None:
        raise Http404

    try:
        parsed = rst2html(content, path, lang)
    except: #pylint: disable=W0702
        import traceback, cgi
        html = '<pre>%s</pre>' % cgi.escape(traceback.format_exc())
        title = 'Wiki load failed'
    else:
        html = parsed['html_body']
        title = parsed['title']

    return render_to_response('peach3/wiki/view.html',
                              {'title':title,
                               'content':html,
                               'print':startPrint,
                              },
                              context_instance=RequestContext(request))

