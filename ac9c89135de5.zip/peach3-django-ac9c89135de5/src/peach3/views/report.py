""" This file is part of PEACH.

    Copyright (C) 2006-2009 Eindhoven University of Technology
"""
from django.http import StreamingHttpResponse, HttpResponseForbidden, HttpResponseNotModified
from django.shortcuts import get_object_or_404

from peach3.models import Report

def download(request, rid, filename):
    user = request.user
    if user.is_anonymous():
        return HttpResponseForbidden()
    elif user.is_superuser:
        report = get_object_or_404(Report, pk=rid)
    else:
        report = get_object_or_404(Report, pk=rid, users=user)

    etag = report.hash
    if etag == request.META.get("HTTP_IF_NONE_MATCH"):
        return HttpResponseNotModified()

    response = StreamingHttpResponse(report.file, mimetype=report.mimetype)
    response['Content-Disposition'] = 'attachment; filename="%s"' % filename
    response['Content-Length'] = report.file.size
    response['ETag'] = etag

    return response
