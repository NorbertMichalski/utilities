from __future__ import with_statement

from django.http import StreamingHttpResponse, HttpResponseRedirect, HttpResponseForbidden,\
    HttpResponseNotModified, Http404
from django.shortcuts import render_to_response
from django.template import RequestContext
from django.utils.encoding import iri_to_uri
from django.views.decorators.cache import cache_control, cache_page

from peach3.utils.ppk import base32_decode_ppk
from peach3.shortcuts import get_object_by_ppk_or_404
from peach3.models import SubmissionFile

from pygments import highlight
from pygments.formatters import HtmlFormatter #@UnresolvedImport pylint: disable=E0611

try:
    from peach3_ui_2012.api.base.authentication import use_apikey_authentication
except ImportError:
    from functools import wraps
    def use_apikey_authentication(auth=None): #pylint: disable=W0613
        " Dummy decorator "
        def decorator(view_func):
            @wraps(view_func)
            def _wrapped_view(request, *args, **kwargs):
                return view_func(request, *args, **kwargs)
            return _wrapped_view
        return decorator

@use_apikey_authentication
def download_file(request, sbfppk, name): #pylint: disable=W0613
    user = request.user

    try:
        sbfppk = base32_decode_ppk(sbfppk)
    except ValueError:
        raise Http404

    fileslot = get_object_by_ppk_or_404(SubmissionFile, sbfppk, user)

    sb = fileslot.submission
    if not sb.has_access(user):
        return HttpResponseForbidden()

    filerev = fileslot.file

    etag = filerev.sha1
    if etag == request.META.get("HTTP_IF_NONE_MATCH"):
        return HttpResponseNotModified()

    mimetype = filerev.filetype.mimetype or fileslot.provided_mimetype

    response = StreamingHttpResponse(filerev.file, mimetype=mimetype)
    response['Content-Disposition'] = 'attachment; filename*=UTF-8\'\''+iri_to_uri(fileslot.name)
    response['Content-Length'] = filerev.file.size
    response['ETag'] = etag

    return response

@cache_control(max_age=24*60*60)
@cache_page(60*60)
def print_file(request, sbfppk, name): #pylint: disable=W0613
    user = request.user

    try:
        sbfppk = base32_decode_ppk(sbfppk)
    except ValueError:
        raise Http404

    fileslot = get_object_by_ppk_or_404(SubmissionFile, sbfppk, user)

    sb = fileslot.submission
    if not sb.has_access(user):
        return HttpResponseForbidden()

    filerev = fileslot.file

    if filerev.filetype.binary_content:
        return HttpResponseRedirect(fileslot.get_download_url())

    l = filerev.filetype.get_lexer()
    text = filerev.get_unicode()
    if l:
        f = HtmlFormatter(style='default',
                          cssclass="source highlight",
                          linenos='inline',
                          lineanchors='src',
                          lineseperator='<br/>',
                         )
        content = highlight(text, l, f)
    else:
        content = text

    return render_to_response('peach3/submission/print.html',
                              {'content':content,
                              },
                              context_instance=RequestContext(request))

