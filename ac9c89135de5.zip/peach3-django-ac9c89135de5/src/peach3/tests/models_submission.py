" TestCases for Submission "
# pylint: disable=C0103,R0904

from django.test import TestCase

from django.contrib.auth import get_user_model
from django.contrib.sites.models import Site
from django.utils.timezone import make_aware, UTC

from peach3.models import (Period, Realm,
                           Submission, SubmissionAuthor,
                           AssignmentEdition, CourseEdition,
                           Cluster, ClusterStaff,
                           GradingSystem)

import datetime

class SubmissionAuthorsTestCase(TestCase):  # pylint: disable=R0902
    " Test cases pertaining to Submission.authors "
    def setUp(self):
        # Create a period and default realm
        self.period = Period.objects.create(slug='period',
                                            default_name='period')
        self.realm = Realm.objects.create(site=Site.objects.get_current(),
                                          default_name='realm')

        # Create users: a manager, and some students
        User = get_user_model()
        self.manager = User.objects.create_user('manager', 'manager@peach3.nl')
        self.student1 = User.objects.create_user('student1', 'student1@peach3.nl')
        self.student2 = User.objects.create_user('student2', 'student2@peach3.nl')

        # One course with one cluster
        self.course = CourseEdition.objects.create(period=self.period,
                                                   default_name='course',
                                                   created_by=self.manager)

        self.cluster = Cluster.objects.create(courseedition=self.course,
                                              default_name='cluster')
        self.cluster.realms = [self.realm]

        self.course.add_manager(self.manager)

        # One assignment
        self.assignment = AssignmentEdition.objects.create(slug='assignment',
                                                           default_name='assignment',
                                                           courseedition=self.course)

        # Add students to cluster
        assert self.course.join_cluster('test', self.student1, self.realm, self.cluster)
        assert self.course.join_cluster('test', self.student2, self.realm, self.cluster)

    def test_creator_is_author(self):
        " Submission.authors is correctly initialized with Submission.created_by "
        submission = Submission.objects.create(courseedition=self.course,
                                               assignmentedition=self.assignment,
                                               created_by=self.student1)

        self.assertQuerysetEqual(
            submission.authors.all(),
            [repr(self.student1)]
        )

    def test_manager_is_not_author(self):
        " Submission.authors is not initialized when a staff member creates the submission "
        submission = Submission.objects.create(courseedition=self.course,
                                               assignmentedition=self.assignment,
                                               created_by=self.manager)

        self.assertQuerysetEqual(
            submission.authors.all(),
            []
        )

    def test_new_submission_inherits_authors_1(self):
        " Submission.authors is correctly inherited when a new submission is created "
        submission1 = Submission.objects.create(courseedition=self.course,
                                                assignmentedition=self.assignment,
                                                created_by=self.student1)
        submission1.add_author(self.student2)

        submission2 = Submission.objects.create(courseedition=self.course,
                                                assignmentedition=self.assignment,
                                                created_by=self.student1)

        self.assertQuerysetEqual(
            submission2.authors.all(),
            [repr(self.student1), repr(self.student2)],
            ordered=False,
        )

    def test_new_submission_inherits_authors_2(self):
        """ Submission.authors is correctly inherited when a new submission is created,
            even when created by another author, and not the initial creator
        """
        submission1 = Submission.objects.create(courseedition=self.course,
                                                assignmentedition=self.assignment,
                                                created_by=self.student1)
        submission1.add_author(self.student2)

        submission2 = Submission.objects.create(courseedition=self.course,
                                                assignmentedition=self.assignment,
                                                created_by=self.student2)

        self.assertQuerysetEqual(
            submission2.authors.all(),
            [repr(self.student1), repr(self.student2)],
            ordered=False,
        )

    def test_manager_submission_does_not_inherit(self):
        " When a managers creates a new submission, authors are not inherited "
        submission1 = Submission.objects.create(courseedition=self.course,
                                                assignmentedition=self.assignment,
                                                created_by=self.manager)
        submission1.add_author(self.student1, self.student2)

        submission2 = Submission.objects.create(courseedition=self.course,
                                                assignmentedition=self.assignment,
                                                created_by=self.manager)

        self.assertQuerysetEqual(
            submission2.authors.all(),
            [],
        )

class SubmissionAutoUpdateClustersTestCase(TestCase):  # pylint: disable=R0902
    """ TestCase to verify that submission.clusters is automatically updated
        for any change in submission.authors, and for author cluster
        changes
    """
    def setUp(self):
        # Create a period and default realm
        self.period = Period.objects.create(slug='default')
        self.realm = Realm.objects.create(site=Site.objects.get_current())

        # Create users: a manager, and some 4 students
        User = get_user_model()
        self.manager = User.objects.create_user('manager', 'manager@peach3.nl')
        self.student1 = User.objects.create_user('student1', 'student1@peach3.nl')
        self.student2 = User.objects.create_user('student2', 'student2@peach3.nl')
        self.student3 = User.objects.create_user('student3', 'student3@peach3.nl')

        # One course with 2 clusters
        self.course = CourseEdition.objects.create(period=self.period,
                                                   created_by=self.manager)
        self.cluster1 = Cluster.objects.create(courseedition=self.course, default_name='cluster 1')
        self.cluster1.realms = [self.realm]
        self.cluster2 = Cluster.objects.create(courseedition=self.course, default_name='cluster 2')
        self.cluster2.realms = [self.realm]

        self.course.add_manager(self.manager)

        # One assignment
        self.assignment = AssignmentEdition.objects.create(slug='assignment1',
                                                           courseedition=self.course)

        # Add students to clusters:
        #   Student 1 in cluster 1
        #   Student 2 in cluster 2
        #   Student 3 in cluster 2
        assert self.course.join_cluster('test', self.student1, self.realm, self.cluster1)
        assert self.course.join_cluster('test', self.student2, self.realm, self.cluster2)
        assert self.course.join_cluster('test', self.student3, self.realm, self.cluster1)

        # Create submission
        self.submission = Submission.objects.create(courseedition=self.course,
                                                    assignmentedition=self.assignment,
                                                    created_by=self.student1)

    def test_cluster_initialized(self):
        " Submission.clusters is correctly initialized for the initial author "
        self.assertQuerysetEqual(
            self.submission.clusters.all(),
            [repr(self.cluster1)]
        )

    def test_cluster_updated(self):
        " Submission.clusters is updated when an author from another cluster is added "
        self.submission.add_author(self.student2)

        self.assertQuerysetEqual(
            self.submission.clusters.all().order_by('default_name'),
            [repr(self.cluster1), repr(self.cluster2)],
        )

    def test_cluster_not_duplicate(self):
        " Submission.clusters does not contain duplicate clusters "
        self.submission.add_author(self.student3)

        self.assertQuerysetEqual(
            self.submission.clusters.all(),
            [repr(self.cluster1)]
        )

    def test_cluster_not_duplicate_2(self):
        " Submission.clusters does not contain duplicate clusters, for multiple users "
        self.submission.add_author(self.student2, self.student3)

        self.assertQuerysetEqual(
            self.submission.clusters.all().order_by('default_name'),
            [repr(self.cluster1), repr(self.cluster2)],
        )

    def test_cluster_updated_when_user_moves(self):
        " Submission.clusters is correctly updated when a member is moved to another cluster "

        # Move student 1 to cluster 2
        self.cluster1.move_member(self.student1, self.cluster2, self.realm)

        # Submission now belongs to cluster 2
        self.assertQuerysetEqual(
            self.submission.clusters.all(),
            [repr(self.cluster2)]
        )

    def test_cluster_not_updated_when_user_moves(self):
        """ Submission.clusters is not updated when a member is moved to another cluster,
            but there are still members of all current clusters
        """
        self.submission.add_author(self.student2, self.student3)

        # Move student 3 to from cluster 1 cluster 2
        self.cluster1.move_member(self.student3, self.cluster2, self.realm)

        # Submission's clusters do not change
        self.assertQuerysetEqual(
            self.submission.clusters.all().order_by('default_name'),
            [repr(self.cluster1), repr(self.cluster2)],
        )

    def test_cluster_removed(self):
        " Submission.clusters is updated when a member is removed "
        self.submission.add_author(self.student2)
        self.submission.remove_author(self.student1)

        self.assertQuerysetEqual(
            self.submission.clusters.all(),
            [repr(self.cluster2)],
        )

def xform_sb(sb):
    " Transform function to create readable submission identifier "
    return '%s:%s' % (sb.assignmentedition.slug, ','.join(au.username for au in sb.authors.all().order_by('username')))

class SubmissionFilterByTestCase(TestCase):  # pylint: disable=R0902
    " TestCase to verify the correctness of Submission.objects.filter_XYZ_by "

    def setUp(self):
        # Create a period and default realm
        self.period = Period.objects.create(slug='period',
                                            default_name='period')
        self.realm = Realm.objects.create(site=Site.objects.get_current(),
                                          default_name='realm')

        # Create users: a manager, 2 staff members and 2 students
        User = get_user_model()
        self.manager = User.objects.create_user('manager', 'manager@peach3.nl')
        self.staff1 = User.objects.create_user('staff1', 'staff1@peach3.nl')
        self.staff2 = User.objects.create_user('staff2', 'staff1@peach3.nl')
        self.student1 = User.objects.create_user('student1', 'student1@peach3.nl')
        self.student2 = User.objects.create_user('student2', 'student2@peach3.nl')

        # One course with 2 clusters
        self.course = CourseEdition.objects.create(period=self.period,
                                                   default_name='course 1',
                                                   created_by=self.manager)
        self.cluster1 = Cluster.objects.create(courseedition=self.course, default_name='cluster 1')
        self.cluster1.realms.add(self.realm)
        self.cluster2 = Cluster.objects.create(courseedition=self.course, default_name='cluster 2')
        self.cluster2.realms.add(self.realm)

        self.course.add_manager(self.manager)
        self.course.add_to_admincluster(self.staff1)
        self.course.add_to_admincluster(self.staff2)

        # Cluster 1:
        #   Student 1 as member
        #   Manager as reviewer level 10 (automatically added)
        #   Staff 1 as reviewer level 5
        #   Staff 2 as observer level 1
        assert self.course.join_cluster('test', self.student1, self.realm, self.cluster1)
        self.cluster1reviewer = ClusterStaff.objects.create(cluster=self.cluster1,
                                                            user=self.staff1,
                                                            role=ClusterStaff.ROLE_REVIEW,
                                                            level=5)
        self.cluster1observer = ClusterStaff.objects.create(cluster=self.cluster1,
                                                            user=self.staff2,
                                                            role=ClusterStaff.ROLE_OBSERVE,
                                                            level=1)

        # Cluster 2:
        #   Student 2 as member
        #   Manager as reviewer level 10 (automatically added)
        #   Staff 1 as observer level 5
        #   Staff 2 as reviewer level 5
        assert self.course.join_cluster('test', self.student2, self.realm, self.cluster2)
        self.cluster2observer = ClusterStaff.objects.create(cluster=self.cluster2,
                                                            user=self.staff1,
                                                            role=ClusterStaff.ROLE_OBSERVE,
                                                            level=5)
        self.cluster2reviewer = ClusterStaff.objects.create(cluster=self.cluster2,
                                                            user=self.staff2,
                                                            role=ClusterStaff.ROLE_REVIEW,
                                                            level=5)

        # Assignment 1:
        #    Observelevel 1
        #    Reviewlevel 5
        self.assignment1 = AssignmentEdition.objects.create(slug='assignment1',
                                                            default_name='assignment 1',
                                                            courseedition=self.course,
                                                            observelevel=1,
                                                            reviewlevel=5,
                                                            reviewpublishlevel=10)

        # Assignment 2:
        #    Observelevel 5
        #    Reviewlevel 5
        self.assignment2 = AssignmentEdition.objects.create(slug='assignment2',
                                                            default_name='assignment 2',
                                                            courseedition=self.course,
                                                            observelevel=5,
                                                            reviewlevel=5,
                                                            reviewpublishlevel=5)

        # Submission 1_1
        #    Assignment 1 (observelevel 1, reviewlevel 5)
        #    Student 1 (in Cluster 1 [staff1: reviewer lvl 5, staff2: observer lvl 1])
        #
        # Should be observable by manager and both staff
        # Should be reviewable by manager and staff1
        # Should be publishable by manager only
        self.submission1_1 = Submission.objects.create(courseedition=self.course,
                                                       assignmentedition=self.assignment1,
                                                       created_by=self.student1)

        # Submission 1_2
        #    Assignment 1 (observelevel 1, reviewlevel 5)
        #    Student 2 (in Cluster 2 [staff1: observer lvl 5, staff2: reviewer lvl 5])
        #
        # Should be observable by manager and both staff
        # Should be reviewable by manager and staff2
        # Should be publishable by manager only
        self.submission1_2 = Submission.objects.create(courseedition=self.course,
                                                       assignmentedition=self.assignment1,
                                                       created_by=self.student2)

        # Submission 2_1
        #    Assignment 2 (observelevel 5, reviewlevel 5)
        #    Student 1 (in Cluster 1 [staff1: reviewer lvl 5, staff2: observer lvl 1])
        #
        # Should be observable by manager and staff1
        # Should be reviewable by manager and staff1
        # Should be publishable by manager only
        self.submission2_1 = Submission.objects.create(courseedition=self.course,
                                                       assignmentedition=self.assignment2,
                                                       created_by=self.student1)

        # Submission 2_2
        #    Assignment 2 (observelevel 5, reviewlevel 5)
        #    Student 2 (in Cluster 2 [staff1: observer lvl 5, staff2: reviewer lvl 5])
        #
        # Should be observable by manager and both staff
        # Should be reviewable by manager and staff2
        # Should be publishable by manager and staff2
        self.submission2_2 = Submission.objects.create(courseedition=self.course,
                                                       assignmentedition=self.assignment2,
                                                       created_by=self.student2)

        # Submission 2_both
        #    Assignment 2 (observelevel 5, reviewlevel 5)
        #    Student 1 (in Cluster 1 [staff1: reviewer lvl 5, staff2: observer lvl 1])
        #    Student 2 (in Cluster 2 [staff1: observer lvl 5, staff2: reviewer lvl 5])
        #
        # Should be observable by everyone
        # Should be reviewable by everyone
        # Should be publishable by everyone
        self.submission2_both = Submission.objects.create(courseedition=self.course,
                                                          assignmentedition=self.assignment2,
                                                          created_by=self.student1)
        self.submission2_both.add_author(self.student2)

    def test_observable_by_manager(self):
        " All submission are observable by the manager "
        self.assertQuerysetEqual(
            Submission.objects.filter_observable_by(self.manager),
            [
                xform_sb(self.submission1_1),
                xform_sb(self.submission1_2),
                xform_sb(self.submission2_1),
                xform_sb(self.submission2_2),
                xform_sb(self.submission2_both),
            ],
            transform=xform_sb,
            ordered=False,
        )

    def test_observable_by_staff1(self):
        " All submission are observable by staff1 "
        self.assertQuerysetEqual(
            Submission.objects.filter_observable_by(self.staff1),
            [
                xform_sb(self.submission1_1),
                xform_sb(self.submission1_2),
                xform_sb(self.submission2_1),
                xform_sb(self.submission2_2),
                xform_sb(self.submission2_both),
            ],
            transform=xform_sb,
            ordered=False,
        )

    def test_observable_by_staff2(self):
        " Some submission are observable by staff2 "
        self.assertQuerysetEqual(
            Submission.objects.filter_observable_by(self.staff2),
            [
                xform_sb(self.submission1_1),
                xform_sb(self.submission1_2),
                xform_sb(self.submission2_2),
                xform_sb(self.submission2_both),
            ],
            transform=xform_sb,
            ordered=False,
        )

    def test_reviewable_by_manager(self):
        " All submission are reviewable by the manager "
        self.assertQuerysetEqual(
            Submission.objects.filter_reviewable_by(self.manager),
            [
                xform_sb(self.submission1_1),
                xform_sb(self.submission1_2),
                xform_sb(self.submission2_1),
                xform_sb(self.submission2_2),
                xform_sb(self.submission2_both),
            ],
            transform=xform_sb,
            ordered=False,
        )

    def test_reviewable_by_staff1(self):
        " Some submission are reviewable by staff1 "
        self.assertQuerysetEqual(
            Submission.objects.filter_reviewable_by(self.staff1),
            [
                xform_sb(self.submission1_1),
                xform_sb(self.submission2_1),
                xform_sb(self.submission2_both),
            ],
            transform=xform_sb,
            ordered=False,
        )

    def test_reviewable_by_staff2(self):
        " Some submission are reviewable by staff2 "
        self.assertQuerysetEqual(
            Submission.objects.filter_reviewable_by(self.staff2),
            [
                xform_sb(self.submission1_2),
                xform_sb(self.submission2_2),
                xform_sb(self.submission2_both),
            ],
            transform=xform_sb,
            ordered=False,
        )

    def test_publishable_by_manager(self):
        " All submission are publishable by the manager "
        self.assertQuerysetEqual(
            Submission.objects.filter_publishable_by(self.manager),
            [
                xform_sb(self.submission1_1),
                xform_sb(self.submission1_2),
                xform_sb(self.submission2_1),
                xform_sb(self.submission2_2),
                xform_sb(self.submission2_both),
            ],
            transform=xform_sb,
            ordered=False,
        )

    def test_publishable_by_staff1(self):
        " Some submission are publishable by staff1 "
        self.assertQuerysetEqual(
            Submission.objects.filter_publishable_by(self.staff1),
            [
                xform_sb(self.submission2_1),
                xform_sb(self.submission2_2),
                xform_sb(self.submission2_both),
            ],
            transform=xform_sb,
            ordered=False,
        )

    def test_publishable_by_staff2(self):
        " Some submission are publishable by staff2 "
        self.assertQuerysetEqual(
            Submission.objects.filter_publishable_by(self.staff2),
            [
                xform_sb(self.submission2_2),
                xform_sb(self.submission2_both),
            ],
            transform=xform_sb,
            ordered=False,
        )

    def test_not_observable_by_students(self):
        " No submissions are observable by students "
        self.assertQuerysetEqual(
            Submission.objects.filter_observable_by(self.student1),
            [],
        )
        self.assertQuerysetEqual(
            Submission.objects.filter_observable_by(self.student2),
            [],
        )

    def test_not_reviewable_by_students(self):
        " No submissions are observable by students "
        self.assertQuerysetEqual(
            Submission.objects.filter_reviewable_by(self.student1),
            [],
        )
        self.assertQuerysetEqual(
            Submission.objects.filter_reviewable_by(self.student2),
            [],
        )

    def test_not_publishable_by_students(self):
        " No submissions are publishable by students "
        self.assertQuerysetEqual(
            Submission.objects.filter_publishable_by(self.student1),
            [],
        )
        self.assertQuerysetEqual(
            Submission.objects.filter_publishable_by(self.student2),
            [],
        )

class SubmissionActiveTestCase(TestCase):  # pylint: disable=R0902
    " Test cases to test active/latest_accepted submissions are correctly tracked "

    def setUp(self):
        # Create a period and default realm
        self.period = Period.objects.create(slug='period',
                                            default_name='period')
        self.realm = Realm.objects.create(site=Site.objects.get_current(),
                                          default_name='realm')

        # Create users: a manager, and some 4 students
        User = get_user_model()
        self.manager = User.objects.create_user('manager', 'manager@peach3.nl')
        self.student1 = User.objects.create_user('student1', 'student1@peach3.nl')
        self.student2 = User.objects.create_user('student2', 'student2@peach3.nl')

        # One course with one cluster
        self.course = CourseEdition.objects.create(period=self.period,
                                                   default_name='course',
                                                   created_by=self.manager)

        self.cluster = Cluster.objects.create(courseedition=self.course,
                                              default_name='cluster')
        self.cluster.realms = [self.realm]

        self.course.add_manager(self.manager)

        # One assignment
        self.assignment = AssignmentEdition.objects.create(slug='assignment',
                                                           default_name='assignment',
                                                           courseedition=self.course)

        # Add students to cluster
        assert self.course.join_cluster('test', self.student1, self.realm, self.cluster)
        assert self.course.join_cluster('test', self.student2, self.realm, self.cluster)

        # Grades
        gs = GradingSystem.objects.create(
            default_name='default'
        )
        self.accepted = gs.grade_set.create(
            value_low=100,
            passing=True,
            default_name='accepted',
        )
        self.rejected = gs.grade_set.create(
            value_low=0,
            passing=False,
            default_name='rejected',
        )

        self.clock = make_aware(datetime.datetime(2012, 12, 1), UTC())

    def __get_clock(self):
        " A clock that gets incremented with one second for each access "
        try:
            return self.clock
        finally:
            self.clock += datetime.timedelta(seconds=1)

    def __add_submission_state(self, submission, *states):
        # Add one or more states to a submission
        #
        # possible states are:
        #    CHECK      : Checking not started
        #    CHECKING   : Checking running
        #    SYSFAIL    : Checking failed
        #    PASSED     : Has a passing CheckResult
        #    FAILED     : Has a rejecting CheckResult
        #
        #    ACCEPTED   : Has a passing Review
        #    REJECTED   : Has a rejecting Review

        for state in states:
            assert state in ['ACCEPTED', 'REJECTED',
                             'CHECK', 'CHECKING',
                             'SYSFAIL',
                             'PASSED', 'FAILED']

            if state in ['ACCEPTED', 'REJECTED']:
                review = submission.review_set.create(
                    created=self.__get_clock(),
                    created_by=self.manager,
                    reviewlevel=10,
                    visibilitylevel=10,
                    grade=self.accepted if state == 'ACCEPTED' else self.rejected,
                )
                review.authors = submission.authors.all()

            else:
                checkresult_args = {
                    'created': self.__get_clock()
                }

                if state not in ['CHECK', 'CHECKING']:
                    checkresult_args.update(
                        checked=self.__get_clock(),
                        checked_level=10,
                    )

                if state == 'CHECK':
                    checkresult_args['state'] = ''
                elif state in ['SYSFAIL', 'CHECKING']:
                    checkresult_args['state'] = state
                else:
                    checkresult_args.update(
                        state='CHECKED',
                        grade=self.accepted if state == 'PASSED' else self.rejected,
                    )

                submission.checkresult_set.create(**checkresult_args)

    def __setup_submissions(self, students, states):
        # Create multiple submissions for the assignment with the list of students as authors
        # state is a list indicating the state of the submission.
        #
        # possible states are:
        #    NEW        : Not submitted
        #    WAITING    : Submitted, nothing else
        #
        #    CHECK      : Checking not started
        #    CHECKING   : Checking running
        #    SYSFAIL    : Checking failed
        #    PASSED     : Has a passing CheckResult
        #    FAILED     : Has a rejecting CheckResult
        #
        #    ACCEPTED   : Has a passing Review
        #    REJECTED   : Has a rejecting Review
        #
        #  some states can be combined, where that would make sense:
        #    PASSED+FAILED+ACCEPTED : A submission that is first automatically passed, then automatically failed
        #                             but finally is manually accepted

        submissions = []
        for state in states:
            assert '+' in state or state in ['NEW', 'WAITING',
                                             'ACCEPTED', 'REJECTED',
                                             'CHECK', 'CHECKING',
                                             'SYSFAIL',
                                             'PASSED', 'FAILED']

            submission = Submission.objects.create(
                courseedition=self.course,
                assignmentedition=self.assignment,
                created_by=students[0],
                created=self.__get_clock(),
                submitted_by=students[0] if state != 'NEW' else None,
                submitted=self.__get_clock() if state != 'NEW' else None,
            )
            submission.add_author(*students)

            if state not in ['NEW', 'WAITING']:
                if '+' in state:
                    substates = state.split('+')
                else:
                    substates = [state]

                self.__add_submission_state(submission, *substates)

            submissions.append(submission)

        return submissions

    def __assert_flags(self, author, submissions, expected):
        for num, submission in enumerate(submissions):
            sba = SubmissionAuthor.objects.get(submission=submission,
                                               author=author)

            flags = (sba.state, sba.active, sba.latest_accepted)
            self.assertEqual(
                flags,
                expected[num],
                'Flags for submission %d incorrect: flags=%r, expected=%r' % (num, flags, expected[num])
            )

    def __test_submissions_flags(self, *tests):
        submissions = self.__setup_submissions([self.student1], [t[0] for t in tests])
        self.__assert_flags(self.student1, submissions, [t[1] for t in tests])

    def test_single_waiting_submission(self):
        self.__test_submissions_flags(
            ('WAITING', ('REVIEW', True, True)),
        )

    def test_single_accepted_submission(self):
        self.__test_submissions_flags(
            ('ACCEPTED', ('ACCEPTED', True, True)),
        )

    def test_multiple_waiting_submissions(self):
        self.__test_submissions_flags(
            ('WAITING', ('REVOKED', False, False)),
            ('WAITING', ('REVIEW', True, True)),
        )

    def test_multiple_waiting_submissions_autoaccept(self):
        self.assignment.set_option('REVIEW', autoaccept=True)
        self.__test_submissions_flags(
            ('WAITING', ('ACCEPTED', False, False)),
            ('WAITING', ('ACCEPTED', True, True)),
        )

    def test_multiple_submissions_first_manual_accepted(self):
        self.__test_submissions_flags(
            ('ACCEPTED', ('ACCEPTED', False, False)),
            ('WAITING', ('REVIEW', True, True)),
        )

    def test_multiple_submissions_first_manual_accepted_autoaccept(self):
        self.assignment.set_option('REVIEW', autoaccept=True)
        self.__test_submissions_flags(
            ('ACCEPTED', ('ACCEPTED', False, False)),
            ('WAITING', ('ACCEPTED', True, True)),
        )

    def test_accepted_rejected(self):
        self.__test_submissions_flags(
            ('ACCEPTED', ('ACCEPTED', False, True)),
            ('REJECTED', ('REJECTED', True, False)),
        )

    def test_waiting_waiting_rejected(self):
        self.__test_submissions_flags(
            ('WAITING', ('REVOKED', False, False)),
            ('WAITING', ('REVOKED', False, False)),
            ('REJECTED', ('REJECTED', True, False)),
        )

    def test_new_is_active(self):
        self.__test_submissions_flags(
            ('ACCEPTED', ('ACCEPTED', False, True)),
            ('REJECTED', ('REJECTED', False, False)),
            ('NEW', ('NEW', True, False)),
        )

    def test_accepted_then_rejected(self):
        self.__test_submissions_flags(
            ('ACCEPTED+REJECTED', ('REJECTED', True, False)),
        )

    def test_failed_is_rejected(self):
        self.__test_submissions_flags(
            ('FAILED', ('REJECTED', True, False)),
        )

    def test_passed_is_waiting(self):
        self.__test_submissions_flags(
            ('PASSED', ('REVIEW', True, True)),
        )

    def test_passed_is_autoaccepted(self):
        self.assignment.set_option('REVIEW', autoaccept=True)
        self.__test_submissions_flags(
            ('PASSED', ('ACCEPTED', True, True)),
        )

    def test_checking_states(self):
        submissions = self.__setup_submissions([self.student1], ['CHECK'])
        check = submissions[0].checkresult_set.all()[0]
        self.assertEqual(check.state, '')

        self.__assert_flags(self.student1, submissions, [('CHECK', True, False)])

        check.state = 'CHECKING'
        check.save()

        self.__assert_flags(self.student1, submissions, [('CHECKING', True, False)])

        check.state = 'CHECKED'
        check.grade = self.accepted
        check.save()

        self.__assert_flags(self.student1, submissions, [('REVIEW', True, True)])

        self.assignment.set_option('REVIEW', autoaccept=True)

        self.__assert_flags(self.student1, submissions, [('ACCEPTED', True, True)])
