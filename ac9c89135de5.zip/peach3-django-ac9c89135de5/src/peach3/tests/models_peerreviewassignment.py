" TestCases for PeerReviewAssignment models "
#pylint: disable=C0103
from django.test import TestCase

from django.contrib.auth import get_user_model
from django.contrib.sites.models import Site
from django.utils.timezone import make_aware, UTC

from peach3.utils.dates import TimeRange
from peach3.models import (Period, Realm, Submission, SubmissionAuthor,
                           AssignmentEdition, CourseEdition,
                           Cluster, GradingSystem, PeerReviewAssignment, PeerReviewBundle)

import random, datetime

NUM_ASSIGNMENTS = 2

XND = {
    1:'1st',
    2:'2nd',
    3:'3rd',
}

OPEN_RANGE = TimeRange(open=True)

def _readable_submission_id(submission):
    " Get a human readable submission id ('xxx's 2nd submission (of 3)') "
    created_by = submission.created_by
    username = created_by.username
    submissions = created_by.submission_set.order_by('submitted')
    num = len(submissions)

    count = 1
    for s in submissions:
        if submission.pk == s.pk:
            break
        count += 1

    if count>num:
        return '<Invalid submission for %s>' % username

    if count==num:
        label = 'last'
    else:
        label = XND.get(count, '%dth' % count)

    return "%s's %s submission (of %d)" % (username, label, num)


class DistributionTestCase(TestCase): #pylint: disable=R0902,R0904
    " Test cases pertaining to the distribution of peer review work "
    def setUp(self):
        # Create a period and default realm
        self.period = Period.objects.create(slug='period',
                                            default_name='period')
        self.realm = Realm.objects.create(site=Site.objects.get_current(),
                                          default_name='realm')

        # Create manager
        User = get_user_model()
        self.manager = User.objects.create_user('manager', 'manager@peach3.nl')

        # One course
        self.course = CourseEdition.objects.create(period=self.period,
                                                   default_name='course',
                                                   created_by=self.manager)

        self.course.add_manager(self.manager)

        # Assignments
        self.assignments = [
            AssignmentEdition.objects.create(
                slug='assignment%d' % i,
                default_name='assignment%d' % i,
                courseedition=self.course
            )
            for i in xrange(NUM_ASSIGNMENTS)
        ]

        # Grades
        gs = GradingSystem.objects.create(
            default_name = 'default'
        )
        self.accepted = gs.grade_set.create(
            value_low = 100,
            passing = True,
            default_name = 'accepted',
        )
        self.rejected = gs.grade_set.create(
            value_low = 0,
            passing = False,
            default_name = 'rejected',
        )
        self.waiting = None # For clarity, the "waiting" grade is no grade

        self.clock = make_aware(datetime.datetime(2012, 12, 1), UTC())

    def __get_clock(self):
        " A clock that gets incremented with one second for each access "
        try:
            return self.clock
        finally:
            self.clock += datetime.timedelta(seconds=1)

    def __setup_clusters(self, *sizes):
        # Setup clusters
        for i, size in enumerate(sizes):
            cluster = Cluster.objects.create(courseedition=self.course,
                                             default_name='cluster%s' % i
                                            )
            cluster.realms = [self.realm]

            User = get_user_model()
            for j in xrange(size):
                name = 'student%d_%03d' % (i, j)
                student = User.objects.create_user(name, '%s@peach3.nl' % name)
                assert self.course.join_cluster('test', student, self.realm, cluster)

                yield student

    def __setup_submissions(self, students, grade=None):
        # Create submissions for the original assignment for each of the given students
        for student in students:
            submission = Submission.objects.create(
                courseedition = self.course,
                assignmentedition = self.assignments[0],
                created = self.__get_clock(),
                created_by = student,
                submitted = self.__get_clock(),
                submitted_by = student,
            )
            if grade:
                review = submission.review_set.create(
                    created = self.__get_clock(),
                    created_by = self.manager,
                    reviewlevel = 10,
                    visibilitylevel = 10,
                    grade = grade,
                )
                review.authors.add(student)

    def __setup_peerreview(self, bundle_size, by_group=False):
        return PeerReviewAssignment.objects.create(
            original_assignment = self.assignments[0],
            review_assignment = self.assignments[1],
            bundle_size = bundle_size,
            reviewed_by_group = by_group,
            _review_result_visible_from = OPEN_RANGE.begin,
            _review_result_visible_until = OPEN_RANGE.end,
        )

    def __test_distribution(self, pra, students, bundle_size1, bundle_size2): #pylint: disable=R0914
        # Dictionaries to collect the graph
        reviewers = dict((student.username, []) for student in students)
        reviewees = dict((student.username, []) for student in students)

        # Make random always return the same sequence
        random.seed(0)

        # For each reviewer, get the submissions to review
        for reviewer in students:
            bundle = pra.get_or_create_bundle(reviewer)
            if bundle:
                for review in bundle.peerreview_set.all():
                    submission = review.submission
                    submission_label = _readable_submission_id(submission)
                    reviewee = submission.created_by

                    # Test that the assigned submission is the latest accepted one
                    self.assert_(SubmissionAuthor.objects.filter(submission=submission,
                                                                 latest_accepted=True)\
                                                         .exists())

                    # Test that submissions cluster's and reviewer's cluster match
                    cluster = self.course.get_user_cluster(reviewer).default_name # Reviewer's cluster
                    clusters = submission.clusters.values_list('default_name', flat=True) # Submission's clusters
                    self.assertIn(cluster, clusters,
                                  "Reviewer %r: %s is in wrong cluster: reviewer-cluster=%r, submission-clusters=%r"
                                    % (reviewer, submission_label, cluster, clusters)
                                 )

                    # Collect review-graph
                    reviewers[reviewer.username].append(reviewee.username)
                    reviewees[reviewee.username].append(reviewer.username)

        # Test that everybody reviews required number of submissions
        bundle_size = {}
        for username, reviews in reviewers.iteritems():
            # Test that reviewer does not review themselves
            self.assertNotIn(username, reviews,
                             "%s reviews themselves: %r" % (username, reviews))

            # Get total number of reviews
            num_reviews = len(reviews)

            # Check that they are unique
            num_unique = len(set(reviews))
            self.assertEqual(num_unique, num_reviews,
                             "%s should review %d unique, but reviews %d: %r"
                                % (username, num_reviews, num_unique, sorted(reviews))
                            )

            if num_reviews in bundle_size:
                bundle_size[num_reviews] += 1
            else:
                bundle_size[num_reviews] = 1

        self.assertDictEqual(bundle_size, bundle_size1,
                             "Unexpected bundle_size for reviewers. "
                             "Expected bundle_size: %r, Actual bundle_size: %r" %
                                (bundle_size1, bundle_size)
                            )

        # Test that every submission receives the required number of reviews
        bundle_size = {}
        for username, reviews in reviewees.iteritems():
            # Get total number of reviews
            num_reviews = len(reviews)

            # Check that they are unique
            num_unique = len(set(reviews))
            self.assertEqual(num_unique, num_reviews,
                             "%s should be reviewed by %d unique, but is reviewed by %d: %r"
                                % (username, num_reviews, num_unique, sorted(reviews))
                            )

            if num_reviews in bundle_size:
                bundle_size[num_reviews] += 1
            else:
                bundle_size[num_reviews] = 1

        self.assertDictEqual(bundle_size, bundle_size2,
                             "Unexpected bundle_size for reviewees. "
                             "Expected bundle_size: %r, Actual bundle_size: %r" %
                                (bundle_size2, bundle_size)
                            )

    def __do_distribution_test(self, s, d, d1, d2):
        """ Generic function to execute all tests
             s: Number of students in each cluster
             d: PeerReviewAssignment bundle_size parameter
             d1: The expected bundle_size for reviews
             d2: The expected bundle_size for reviewed_by
        """

        students = list(self.__setup_clusters(*s))
        self.__setup_submissions(students)
        pra = self.__setup_peerreview(d)
        self.__test_distribution(pra, students, d1, d2)

    def test_distribution_1_submissions_30(self):
        " Test distribution for peer reviews with a distribution spread of 1 for 30 submissions "

        self.__do_distribution_test([30], 1, {1:30}, {1:30})

    def test_distribution_2_submissions_30(self):
        " Test distribution for peer reviews with a distribution spread of 2 for 30 submissions  "

        self.__do_distribution_test([30], 2, {2:30}, {2:30})

    def test_distribution_5_submissions_30(self):
        " Test distribution for peer reviews with a distribution spread of 5 for 30 submissions  "

        self.__do_distribution_test([30], 5, {5:30}, {5:30})

    def test_distribution_30_submissions_30(self):
        " Test distribution for peer reviews with a distribution spread of 30 for 30 submissions  "

        self.__do_distribution_test([30], 29, {29:30}, {29:30})

    def test_distribution_5_submissions_26(self):
        " Test distribution for peer reviews with a distribution spread of 5 for 26 submissions  "

        self.__do_distribution_test([26], 5, {5:26}, {5:26})

    def test_distribution_5_submissions_15_15(self):
        " Test distribution for peer reviews with a distribution spread of 3 for 15/15 submissions "

        self.__do_distribution_test([15, 15], 3, {3: 30}, {3:30})

    def test_distribution_5_submissions_13_17(self):
        " Test distribution for peer reviews with a distribution spread of 3 for 13/17 submissions  "

        self.__do_distribution_test([13, 17], 3, {3: 30}, {3:30})

    def test_distribution_5_submissions_9_10_11(self):
        " Test distribution for peer reviews with a distribution spread of 3 for 9/10/11 submissions  "

        self.__do_distribution_test([9, 10, 11], 3, {3: 30}, {3:30})

    def __test_dual_grades(self, grade1, grade2):
        students = list(self.__setup_clusters(10))
        self.__setup_submissions(students, grade1)
        self.__setup_submissions(students, grade2)
        pra = self.__setup_peerreview(9)
        self.__test_distribution(pra, students, {9:10}, {9:10})

    def test_accepted_accepted(self):
        " Test with 2 submissions for each student: 2x accepted "

        self.__test_dual_grades(self.accepted, self.accepted)

    def test_waiting_waiting(self):
        " Test with 2 submissions for each student: 2x waiting "

        self.__test_dual_grades(self.waiting, self.waiting)

    def test_rejected_accepted(self):
        " Test with 2 submissions for each student: rejected, accepted "

        self.__test_dual_grades(self.rejected, self.accepted)

    def test_accepted_rejected(self):
        " Test with 2 submissions for each student: accepted, rejected "

        self.__test_dual_grades(self.accepted, self.rejected)

    def test_rejected_waiting(self):
        " Test with 2 submissions for each student: rejected, waiting "

        self.__test_dual_grades(self.rejected, self.waiting)

    def test_accepted_waiting(self):
        " Test with 2 submissions for each student: accepted, waiting "

        self.__test_dual_grades(self.accepted, self.waiting)

    def test_waiting_accepted(self):
        " Test with 2 submissions for each student: waiting, accepted "

        self.__test_dual_grades(self.waiting, self.accepted)

    def test_mixed(self):
        " Test with mixed submissions "

        students = list(self.__setup_clusters(32))

        # Set up submissions for 32 students, with up to 5 submissions for
        # each student, with varying grades, like this:
        #
        # Student    Grades
        # 0
        # 1         [accepted]
        # 2                    rejected
        # 3         [accepted] rejected
        # 4                             [waiting]
        # 5          accepted           [waiting]
        # 6                    rejected [waiting]
        # 7          accepted  rejected [waiting]
        # 8                                       rejected
        # 9         [accepted]                    rejected
        # 10                   rejected           rejected
        # 11        [accepted] rejected           rejected
        # 12                             waiting  rejected
        # 13        [accepted]           waiting  rejected
        # 14                   rejected  waiting  rejected
        # 15        [accepted] rejected  waiting  rejected
        # 16                                               [accepted]
        # 17         accepted                              [accepted]
        # 18                   rejected                    [accepted]
        # 19         accepted  rejected                    [accepted]
        # 20                             waiting           [accepted]
        # 21         accepted            waiting           [accepted]
        # 22                   rejected  waiting           [accepted]
        # 23         accepted  rejected  waiting           [accepted]
        # 24                                      rejected [accepted]
        # 25         accepted                     rejected [accepted]
        # 26                   rejected           rejected [accepted]
        # 27         accepted  rejected           rejected [accepted]
        # 28                             waiting  rejected [accepted]
        # 29         accepted            waiting  rejected [accepted]
        # 30                   rejected  waiting  rejected [accepted]
        # 31         accepted  rejected  waiting  rejected [accepted]
        #
        # The submission with the grade decorated with brackets (if any)
        # is that user's submission to be reviewed.
        #
        # There are 6 students that did not complete this 'assignment',
        # the other 26 have a reviewable submission.

        reviewers = []
        for i, student in enumerate(students):
            grades = []
            if i&1:
                grades.append(self.accepted)
            if i&2:
                grades.append(self.rejected)
            if i&4:
                grades.append(self.waiting)
            if i&8:
                grades.append(self.rejected)
            if i&16:
                grades.append(self.accepted)

            for grade in grades:
                self.__setup_submissions([student], grade)

            if i&17 or i&12==4:
                # This student has an accepted submission, and can therefore review
                reviewers.append(student)

        nr = len(reviewers)
        self.assertEqual(nr, 26)

        # Everyone reviews everyone
        pra = self.__setup_peerreview(nr-1)

        # There are 'nr' reviewers, everybody has to review each other, so they can review 'nr-1'
        # work
        self.__test_distribution(pra, reviewers, {nr-1:nr}, {nr-1:nr})

    def test_not_enough_work(self):
        " Test that no review work is distributed if there is not enough work "

        # 10 students
        students = list(self.__setup_clusters(10))

        # Distribution spread is 5
        pra = self.__setup_peerreview(5)

        # Five students submit work
        self.__setup_submissions(students[:5], self.accepted)

        # These 5 all have no works to review
        self.__test_distribution(pra, students[:5], {0:5}, {0:5})

        # No bundles should have been created for them either
        self.assertQuerysetEqual(PeerReviewBundle.objects.all(), [])

        # The other 5 submit their work
        self.__setup_submissions(students[5:], self.accepted)

        # Now everyone can review 5
        self.__test_distribution(pra, students, {5:10}, {5:10})
