# This file is part of PEACH.
#
# Copyright (C) 2006-2009 Eindhoven University of Technology
TIMERANGE_TEST = """
>>> from django.utils.timezone import make_aware
>>> from peach3.utils.dates import TimeRange
>>> from datetime import datetime
>>> from pytz import utc

>>> t0=make_aware(datetime(2008,1,1,0,0,0), utc)
>>> t1=make_aware(datetime(2008,2,1,0,0,0), utc)
>>> t2=make_aware(datetime(2008,3,1,0,0,0), utc)
>>> t3=make_aware(datetime(2008,4,1,0,0,0), utc)
>>> times=[t0,t1,t2,t3]

>>> r0=TimeRange()
>>> r1=TimeRange(open=True)
>>> r2=TimeRange(closed=True)
>>> r3=TimeRange(begin=t0)
>>> r4=TimeRange(end=t3)
>>> r5=TimeRange(begin=t0, end=t3)
>>> r6=TimeRange(begin=t3)
>>> r7=TimeRange(end=t0)
>>> r8=TimeRange(begin=t1, end=t2)
>>> ranges=[r0,r1,r2,r3,r4,r5,r6,r7,r8]

# States
>>> r0
TimeRange<open>
>>> r0.is_open()
True
>>> r0.is_closed()
False
>>> r0.has_begin()
False
>>> r0.has_end()
False

>>> r1
TimeRange<open>
>>> r1.is_open()
True
>>> r1.is_closed()
False
>>> r1.has_begin()
False
>>> r1.has_end()
False

>>> r2
TimeRange<closed>
>>> r1!=r2
True
>>> r2.is_open()
False
>>> r2.is_closed()
True
>>> r2.has_begin()
False
>>> r2.has_end()
False

>>> r3
TimeRange<2008-01-01 00:00:00+00:00 .. +INF>
>>> r3.is_open()
False
>>> r3.is_closed()
False
>>> r3.has_begin()
True
>>> r3.has_end()
False

>>> r4
TimeRange<-INF .. 2008-04-01 00:00:00+00:00>
>>> r4.is_open()
False
>>> r4.is_closed()
False
>>> r4.has_begin()
False
>>> r4.has_end()
True

>>> r5
TimeRange<2008-01-01 00:00:00+00:00 .. 2008-04-01 00:00:00+00:00>
>>> r5.is_open()
False
>>> r5.is_closed()
False
>>> r5.has_begin()
True
>>> r5.has_end()
True

# Intersection and merging
>>> r1+r2
TimeRange<open>
>>> r1-r2
TimeRange<closed>
>>> r3+r4
TimeRange<open>
>>> r3-r4
TimeRange<2008-01-01 00:00:00+00:00 .. 2008-04-01 00:00:00+00:00>
>>> r6+r7
TimeRange<open>
>>> r6-r7
TimeRange<closed>
>>> r3+r8
TimeRange<2008-01-01 00:00:00+00:00 .. +INF>
>>> r3-r8
TimeRange<2008-02-01 00:00:00+00:00 .. 2008-03-01 00:00:00+00:00>
>>> r5+r8
TimeRange<2008-01-01 00:00:00+00:00 .. 2008-04-01 00:00:00+00:00>
>>> r5-r8
TimeRange<2008-02-01 00:00:00+00:00 .. 2008-03-01 00:00:00+00:00>

# Before
>>> [r1.is_before(t) for t in times]
[False, False, False, False]
>>> [r2.is_before(t) for t in times]
[True, True, True, True]
>>> [r8.is_before(t) for t in times]
[True, False, False, False]

# After
>>> [r1.is_after(t) for t in times]
[False, False, False, False]
>>> [r2.is_after(t) for t in times]
[True, True, True, True]
>>> [r8.is_after(t) for t in times]
[False, False, False, True]

# Contains (single date)
>>> [t in r1 for t in times]
[True, True, True, True]
>>> [t in r2 for t in times]
[False, False, False, False]
>>> [t in r3 for t in times]
[True, True, True, True]
>>> [t in r4 for t in times]
[True, True, True, True]
>>> [t in r5 for t in times]
[True, True, True, True]
>>> [t in r6 for t in times]
[False, False, False, True]
>>> [t in r7 for t in times]
[True, False, False, False]
>>> [t in r8 for t in times]
[False, True, True, False]

# Contains (range)
>>> [r1 in r for r in ranges]
[True, True, False, False, False, False, False, False, False]
>>> [r2 in r for r in ranges]
[False, False, False, False, False, False, False, False, False]
>>> [r3 in r for r in ranges]
[True, True, False, True, False, False, False, False, False]
>>> [r4 in r for r in ranges]
[True, True, False, False, True, False, False, False, False]
>>> [r5 in r for r in ranges]
[True, True, False, True, True, True, False, False, False]
>>> [r6 in r for r in ranges]
[True, True, False, True, False, False, True, False, False]
>>> [r7 in r for r in ranges]
[True, True, False, False, True, False, False, True, False]
>>> [r8 in r for r in ranges]
[True, True, False, True, True, True, False, False, True]

# Contains (None)
>>> [None in r for r in ranges]
[True, True, False, True, False, False, True, False, False]

# Ordering
>>> for r in sorted(ranges):
...     print repr(r)
TimeRange<closed>
TimeRange<-INF .. 2008-01-01 00:00:00+00:00>
TimeRange<-INF .. 2008-04-01 00:00:00+00:00>
TimeRange<2008-01-01 00:00:00+00:00 .. 2008-04-01 00:00:00+00:00>
TimeRange<2008-01-01 00:00:00+00:00 .. +INF>
TimeRange<2008-02-01 00:00:00+00:00 .. 2008-03-01 00:00:00+00:00>
TimeRange<2008-04-01 00:00:00+00:00 .. +INF>
TimeRange<open>
TimeRange<open>

# __eq__ etc

>>> r9=TimeRange(begin=t0, end=t1)
>>> r9a=TimeRange(begin=t0, end=t1)
>>> r10=TimeRange(begin=t2, end=t3)

>>> r9 == r9a
True

>>> r9 != r9a
False

>>> r9 < r10
True

>>> r10 < r9
False

>>> r8 > r9
True

>>> r8 < r10
True

>>> r9 == ''
False

"""
