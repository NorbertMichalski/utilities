from django.conf.urls import patterns, url

APP_NAME = 'peach3-core'

#pylint: disable=C0103
urlpatterns = (patterns('peach3.views',
    # Views defined in peach3-core

    url(r'^download/report/(?P<rid>[^/]*)/(?P<filename>[^/]*)$', 'report.download',
            name='report.download'),
    url(r'^download/submission/file/(?P<sbfppk>[^/]+)/(?P<name>.*)$', 'submission.download_file',
            name='submission.download_file'),
    url(r'^download/scoreboard/(?P<ceid>[^/]*)/(?P<name>.*)$', 'scoreboard.download',
            name='scoreboard.download'),

    url(r'^print/submission/file/(?P<sbfppk>[^/]+)/(?P<name>.*)$', 'submission.print_file',
            name='submission.print_file'),
    url(r'^print/wiki/(?P<path>.*)$', 'wiki.view', {'startPrint':True},
            name='wiki.print'),

    # Will most likely get overridden by a UI
    url(r'^wiki/(?P<path>.*)$', 'wiki.view', {'startPrint':False},
            name='wiki.view'),

), APP_NAME, APP_NAME)
