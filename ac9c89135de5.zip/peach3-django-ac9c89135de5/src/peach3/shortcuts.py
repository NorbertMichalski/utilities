from django.http import Http404
from django.shortcuts import _get_queryset

def get_object_by_ppk_or_404(klass, ppk, user, *args, **kwargs):
    """
    Identical to 'django.shortcuts.get_object_or_404', but gets object by ppk

    klass may be a Model, Manager, or QuerySet object. All other passed
    arguments and keyword arguments are used in the get() query.

    Note: Like with get(), an MultipleObjectsReturned will be raised if more than one
    object is found.
    """
    queryset = _get_queryset(klass)
    if args or kwargs:
        queryset = queryset.filter(*args, **kwargs)
    try:
        return queryset.get_by_ppk(ppk, user)
    except queryset.model.DoesNotExist:
        raise Http404('No %s matches the given query.' % queryset.model._meta.object_name) #pylint: disable=W0212
