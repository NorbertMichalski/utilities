from django.conf import settings
from django.utils.encoding import smart_str
from django.utils.translation import check_for_language

class LocaleMiddleware(object):
    def _validate_language(self, lang): #pylint: disable=R0201
        if lang and check_for_language(smart_str(lang)):
            return lang
        return None

    def _get_user_language(self, user):
        return self._validate_language(user.preference.language)

    def _get_request_language(self, request):
        language = self._validate_language(request.GET.get('lang'))
        if not language:
            language = self._get_user_language(request)
        return language

    def process_request(self, request):
        # If there is a 'lang' parameter in the request, set the session language variable to that value
        language = self._validate_language(request.GET.get('lang'))
        if language:
            request.session['django_language'] = language

    def process_response(self, request, response):
        # Copy user's language preference to the language cookie
        user = getattr(request, 'user', None)
        if user and user.is_authenticated():
            user_lang = self._get_user_language(user)

            cookie_lang = request.COOKIES.get(settings.LANGUAGE_COOKIE_NAME)
            if user_lang:
                if cookie_lang != user_lang:
                    response.set_cookie(settings.LANGUAGE_COOKIE_NAME, user_lang)
            else:
                if cookie_lang:
                    response.delete_cookie(settings.LANGUAGE_COOKIE_NAME)

        return response
