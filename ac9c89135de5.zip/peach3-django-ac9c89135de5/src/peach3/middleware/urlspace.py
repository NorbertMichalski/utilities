from django.conf import settings

class UrlSpaceMiddleware(object):
    def process_request(self, request): #pylint: disable=R0201
        for path, config in settings.URLSPACE_CONFIG:
            if request.path.startswith(path):
                absurlmap_name = config.get('absolute_url_map')
                if absurlmap_name:
                    from peach3.core.modelurl import set_absolute_url_map
                    set_absolute_url_map(absurlmap_name)

                rstwriter_class = config.get('rstwriter_class')
                if rstwriter_class:
                    from peach3.utils.rst import set_rstwriter_class
                    set_rstwriter_class(rstwriter_class)

                for key, value in config.get('settings', {}).items():
                    setattr(settings, key, value)

                return
