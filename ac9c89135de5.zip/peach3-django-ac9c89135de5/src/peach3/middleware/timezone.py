from django.utils import timezone

class TimezoneMiddleware(object):
    def process_request(self, request): #pylint: disable=R0201
        if request.user and not request.user.is_anonymous():
            tz = request.user.preference.get_timezone()
            if tz:
                timezone.activate(tz)
