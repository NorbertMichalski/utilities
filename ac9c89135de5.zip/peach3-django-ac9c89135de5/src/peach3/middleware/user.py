
class CurrentUserMiddleware(object):
    def process_request(self, request): #pylint: disable=R0201
        from peach3.utils.permissions import set_current_user
        set_current_user(getattr(request, 'user', None))

