from django.conf import settings

def urlspace(request):
    for path, config in settings.URLSPACE_CONFIG:
        if request.path.startswith(path):
            return config.get('context', {})

    return {}
