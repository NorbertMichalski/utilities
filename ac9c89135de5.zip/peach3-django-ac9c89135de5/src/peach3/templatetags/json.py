from django import template
from django.utils.safestring import mark_safe

from peach3.utils.json import jsonencode as _jsonencode

register = template.Library()

@register.filter
def jsonencode(content):
    return mark_safe(_jsonencode(content))

@register.filter(is_safe=True)
def jsonescape(content):
    return content.replace('</',r'<\/')
