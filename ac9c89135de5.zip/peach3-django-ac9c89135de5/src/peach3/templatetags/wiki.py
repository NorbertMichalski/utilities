""" This file is part of PEACH.

    Copyright (C) 2006-2009 Eindhoven University of Technology
"""
from django import template
from django.template.defaultfilters import stringfilter
from django.template.loader import render_to_string
from django.utils.encoding import smart_str
from django.utils.safestring import mark_safe

from peach3.models import Page
from peach3.utils.rst import rst2html
from peach3.utils.wiki import construct_full_path, user_can_create_page
from peach3.utils.permissions import get_current_user

from classytags.arguments import MultiKeywordArgument, StringArgument, Argument
from classytags.core import Tag, Options
from classytags.exceptions import TooManyArguments
from classytags.values import StringValue

register = template.Library()

class TupleValue(tuple, StringValue):
    """
    A tuple of template variables for easy resolving
    """
    def __init__(self, value):
        tuple.__init__(self, value)

    def resolve(self, context):
        resolved = tuple(item.resolve(context) for item in self)
        return self.clean(resolved)


#class WikiPathArgument(KeywordArgument):
#    parent_class = StringValue
#    path_class = StringValue
#    wrapper_class = TupleValue
#
#    def __init__(self, name):
#        super(WikiPathArgument, self).__init__(name, splitter=':', defaultkey='')
#
#    def parse_token(self, parser, token):
#        parent_name, path = super(WikiPathArgument, self).parse_token(parser, token)
#
#        parent = parser.compile_filter(parent_name)
#        return self.parent_class(parent), self.path_class(path)
#
#    def parse(self, parser, token, tagname, kwargs):
#        if self.name in kwargs:  # pragma: no cover
#            return False
#        else:
#            tup = self.parse_token(parser, token)
#            kwargs[self.name] = self.wrapper_class(tup)
#            return True

class Wiki(Tag):
    """ Tag to render a wiki page

        Usage:
            {% wiki <path> [keyword-arguments] [as <varname>] %}
                ...Template to render wiki page...
            {% endwiki %}

            Parent and path are the arguments to select the page.

            Optional keyword arguments:
                parent: The parent object
                template: Use specified templated instead of block
                type: rST document type to render (defaults to 'fragment')

            Rendered wiki page is inlined, or written to <varname> context variable.

            The inline block or specified template is called with one extra
            context variable: 'wiki', a dictionary containing:

                page: The page. Can be None, indicating a non-existant page, or a page
                        where user has no access
                exists: Boolean to distinguish between non-existing page and a page the
                        user has no access to.
                link: The full wiki path, including the encoded parent.
                type: The 'type' parameter of the wiki tag
                can_edit: Boolean indicating that the current user can edit this page.
                node_content: (Only for external templates) the rendered content of the {% wiki %} node

    """
    name = 'wiki'
    options = Options(
        StringArgument('path', required=True, resolve=True),
        MultiKeywordArgument('keywords', required=False),
        'as',
        Argument('varname', required=False, resolve=False),
        blocks=[('endwiki','nodelist')]
    )

    def render_tag(self, context, path, keywords, varname, nodelist):
        user = context.get('user', get_current_user())

        wikitype = keywords.pop('type', 'fragment')
        template_name = keywords.pop('template', None)
        parent = keywords.pop('parent', None)
        if keywords:
            raise TooManyArguments(self.name, keywords.keys())

        kwargs = {
            'path' : path
        }

        if parent:
            kwargs['parent'] = parent
        else:
            kwargs['parent__isnull'] = True
            parent = None

        try:
            page = Page.objects.get(**kwargs)
        except Page.DoesNotExist:
            page = None

        if page is None:
            exists = False
        else:
            exists = True
            if not page.has_access(user):
                page = None

        if page:
            link = page.full_path
            can_edit = page.is_editor(user)
        else:
            link = construct_full_path(parent, path)
            can_edit = user_can_create_page(user, parent, path)

        wiki_context = {
            'page' : page,
            'parent': parent,
            'path' : path,
            'exists' : exists,
            'link' : link,
            'type' : wikitype,
            'can_edit' : can_edit,
        }

        context.push()
        context['wiki'] = wiki_context
        result = nodelist.render(context)
        if template_name:
            context['wiki']['node_content'] = result
            result = render_to_string(template_name, {}, context)

        context.pop()

        if varname:
            context[varname] = result
            return ''

        return result

register.tag(Wiki)

class DefaultWikiContent(Tag):
    name = 'default_wiki_content'
    options = Options(
        Argument('parent', required=True, resolve=True),
        Argument('path', required=True, resolve=True),
        'into',
        Argument('varname', required=False, resolve=False),
    )

    def render_tag(self, context, parent, path, varname):
        from peach3.utils.wiki import get_initial_text

        result = get_initial_text(parent, path)

        if varname:
            context[varname] = result
            return ''

        return result

register.tag(DefaultWikiContent)

@register.filter
def get_revision(page, rev):
    if not isinstance(page, Page):
        raise template.TemplateSyntaxError, 'get_revision filter input must be a Page instance'

    if rev is not None:
        return page.get_revision(rev)

    return page.latest

class SafeRstResult(object):
    def __init__(self, parse_result):
        self.parse_result = parse_result

    def __get__(self, key):
        if isinstance(self.parse_result, basestring):
            if key=='title':
                return ''
            return mark_safe(self.parse_result)

        return mark_safe(self.parse_result.get(key,''))

@register.filter
def rst2parts(rst, path=None):
    try:
        return rst2html(smart_str(rst), path)
    except:
        import traceback, cgi
        return mark_safe('<pre>%s</pre>' % cgi.escape(traceback.format_exc()))

@register.filter(is_safe=True)
def rstpart(parts, part):
    if isinstance(parts, dict):
        return mark_safe(parts.get(part))
    else:
        return mark_safe(parts)

@register.filter
@stringfilter
def wiki_path_for_url(path):
    return path.lstrip('/')
