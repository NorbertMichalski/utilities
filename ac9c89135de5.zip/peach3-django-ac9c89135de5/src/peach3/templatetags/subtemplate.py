from django import template
from django.template import TemplateDoesNotExist
from django.template.loader import get_template

from classytags.arguments import Argument
from classytags.core import Tag, Options

register = template.Library()

class IfTemplate(Tag):
    """ A small helper to include optional templates, with the possibility to wrap the
        template if it exists, or to output alternative content if the template does not exist.

        Example:
            {% iftemplate "non-existant-template.html" as tmpl %}
                This will never be printed.
            {% else %}
                This will be printed
            {% endiftemplate %}

            {% iftemplate "existing-template.html" as tmpl %}
                <div class="wrapper>{{ tmpl }}</div>
            {% else %}
                This will not be printed
            {% endif %}
    """

    name = 'iftemplate'

    options = Options(
        Argument('template_path'),
        'as',
        Argument('varname', resolve=False),
        blocks=[('else', 'nodelist_true'), ('endiftemplate', 'nodelist_false')],
    )

    def render_tag(self, context, template_path, varname, nodelist_true, nodelist_false):
        try:
            template = get_template(template_path)
        except TemplateDoesNotExist:
            template = None

        context.push()
        try:
            if template:
                context[varname] = template.render(context)
                return nodelist_true.render(context)
            else:
                return nodelist_false.render(context)
        finally:
            context.pop()

register.tag(IfTemplate)
