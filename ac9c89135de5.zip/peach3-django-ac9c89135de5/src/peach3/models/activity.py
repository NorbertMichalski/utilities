"""
Combine all sorts of signals into a single activity stream for other
modules to register to, eg. for logging or live client updates
"""

from django.conf import settings
from django.core.exceptions import ObjectDoesNotExist
from django.dispatch import receiver
from django.db.models.signals import post_save, pre_delete, m2m_changed

from peach3.core.activity import ActivityCode
from peach3.core.signals import activity
from peach3.utils.decorators import skip_raw_save

__ALL__ = []

DISPATCH_UID = 'peach3.models.activity'

def send_activity(sender, code, user, course, cluster, assignment, **parameters):
    if settings.DEBUG:
        send = activity.send
    else:
        send = activity.send_robust

    send(sender, code=code, user=user, course=course, cluster=cluster,
         assignment=assignment, parameters=parameters)

# USER

from django.contrib.auth.signals import user_logged_in, user_logged_out

from peach3.models.auth import User

@receiver(post_save, dispatch_uid=DISPATCH_UID, sender=User)
@skip_raw_save
def user_post_save(sender, instance, created, **kwargs): #pylint: disable=W0613
    user_activity(ActivityCode.created_or_changed(ActivityCode.USER, created),
                  instance)

@receiver(pre_delete, dispatch_uid=DISPATCH_UID, sender=User)
def user_pre_delete(sender, instance, **kwargs): #pylint: disable=W0613
    user_activity(ActivityCode.USER_DELETED, instance)

@receiver(user_logged_in, dispatch_uid=DISPATCH_UID)
def user_logged_in_handler(sender, user, **kwargs): #pylint: disable=W0613
    user_activity(ActivityCode.USER_LOGIN, user)

@receiver(user_logged_out, dispatch_uid=DISPATCH_UID)
def user_logged_out_handler(sender, user, **kwargs): #pylint: disable=W0613
    user_activity(ActivityCode.USER_LOGOUT, user)

def user_activity(code, user):
    send_activity(User, code,
                  user, None, None, None)

# COURSE

from peach3.models.course import CourseEdition

@receiver(post_save, dispatch_uid=DISPATCH_UID, sender=CourseEdition)
@skip_raw_save
def courseedition_post_save(sender, instance, created, **kwargs): #pylint: disable=W0613
    courseedition_activity(ActivityCode.created_or_changed(ActivityCode.COURSE, created),
                           instance)

@receiver(post_save, dispatch_uid=DISPATCH_UID, sender=CourseEdition)
@skip_raw_save
def courseedition_pre_delete(sender, instance, **kwargs): #pylint: disable=W0613
    courseedition_activity(ActivityCode.COURSE_DELETED, instance)

@receiver(m2m_changed, dispatch_uid=DISPATCH_UID, sender=CourseEdition.managers.through) #@UndefinedVariable
def courseedition_managers_changed(sender, instance, action, reverse, pk_set, **kwargs): #pylint: disable=W0613
    if not reverse and action in ['post_add', 'pre_remove', 'pre_clear']:
        try:
            courseedition_activity(ActivityCode.COURSE_CHANGED, instance)
        except ObjectDoesNotExist:
            pass

def courseedition_activity(code, courseedition):
    send_activity(CourseEdition, code,
                  None, courseedition, None, None)

# CLUSTER

from peach3.models.cluster import Cluster, ClusterMember, ClusterStaff

@receiver(post_save, dispatch_uid=DISPATCH_UID, sender=Cluster)
@skip_raw_save
def cluster_post_save(sender, instance, created, **kwargs): #pylint: disable=W0613
    cluster_activity(ActivityCode.created_or_changed(ActivityCode.CLUSTER, created),
                     instance)

@receiver(pre_delete, dispatch_uid=DISPATCH_UID, sender=Cluster)
def cluster_pre_delete(sender, instance, **kwargs): #pylint: disable=W0613
    cluster_activity(ActivityCode.CLUSTER_DELETED, instance)

@receiver(m2m_changed, dispatch_uid=DISPATCH_UID, sender=Cluster.realms.through) #@UndefinedVariable
def cluster_realms_changed(sender, instance, action, reverse, pk_set, **kwargs): #pylint: disable=W0613
    if not reverse and action in ['post_add', 'pre_remove', 'pre_clear']:
        try:
            cluster_activity(ActivityCode.CLUSTER_CHANGED, instance)
        except ObjectDoesNotExist:
            pass

@receiver([post_save, pre_delete], dispatch_uid=DISPATCH_UID, sender=ClusterMember)
@skip_raw_save
def clustermember_activity(sender, instance, **kwargs): #pylint: disable=W0613
    cluster = instance.cluster
    cluster_activity(ActivityCode.CLUSTER_CHANGED, cluster, instance.user,
                     role=None, level=0)

@receiver([post_save, pre_delete], dispatch_uid=DISPATCH_UID, sender=ClusterStaff)
@skip_raw_save
def clusterstaff_activity(sender, instance, **kwargs): #pylint: disable=W0613
    cluster = instance.cluster
    cluster_activity(ActivityCode.CLUSTER_CHANGED, cluster, instance.user,
                     role=instance.role, level=instance.level)

def cluster_activity(code, cluster, user=None, **parameters):
    send_activity(Cluster, code,
                  user, cluster.courseedition, cluster, None,
                  **parameters)

# ASSIGNMENT

from peach3.models.assignment import AssignmentEdition
from peach3.models.timerange import ClusterTimeRange, IndividualTimeRange

@receiver(post_save, dispatch_uid=DISPATCH_UID, sender=AssignmentEdition)
@skip_raw_save
def assignmentedition_post_save(sender, instance, created, **kwargs): #pylint: disable=W0613
    assignmentedition_activity(ActivityCode.created_or_changed(ActivityCode.ASSIGNMENT, created),
                               instance)

@receiver(pre_delete, dispatch_uid=DISPATCH_UID, sender=AssignmentEdition)
def assignmentedition_pre_delete(sender, instance, **kwargs): #pylint: disable=W0613
    assignmentedition_activity(ActivityCode.ASSIGNMENT_DELETED, instance)

@receiver([post_save, pre_delete], dispatch_uid=DISPATCH_UID, sender=ClusterTimeRange)
@receiver([post_save, pre_delete], dispatch_uid=DISPATCH_UID, sender=IndividualTimeRange)
@skip_raw_save
def timerange_changed(sender, instance, **kwargs): #pylint: disable=W0613
    assignmentedition_activity(ActivityCode.ASSIGNMENT_CHANGED,
                               instance.assignmentedition,
                               getattr(instance, 'user', None),
                               getattr(instance, 'cluster', None))

def assignmentedition_activity(code, assignmentedition, user=None, cluster=None):
    send_activity(AssignmentEdition, code,
                  user, assignmentedition.courseedition, cluster, assignmentedition)

# SUBMISSION

from peach3.models.checking import CheckResult, CheckResultStep, CheckResultStepIO
from peach3.models.forum import CommentRevision
from peach3.models.review import Review
from peach3.models.submission import Submission, SubmissionFile

@receiver(post_save, dispatch_uid=DISPATCH_UID, sender=Submission)
@skip_raw_save
def submission_post_save(sender, instance, created, **kwargs): #pylint: disable=W0613
    submission_activity(ActivityCode.created_or_changed(ActivityCode.SUBMISSION, created),
                        instance)

@receiver(pre_delete, dispatch_uid=DISPATCH_UID, sender=Submission)
def submission_pre_delete(sender, instance, **kwargs): #pylint: disable=W0613
    submission_activity(ActivityCode.SUBMISSION_DELETED, instance)

#TODO:
#@receiver(m2m_changed, dispatch_uid=DISPATCH_UID, sender=Submission.authors.through) #@UndefinedVariable
#def submision_authors_changed(sender, instance, action, reverse, pk_set, **kwargs): #pylint: disable=W0613
#    # One or more authors were added or deleted from an existing submission
#    # Send a SUBMISSION_CREATED/DELETED action for these users
#    if not reverse:
#        try:
#            if action=='post_add':
#                code = ActivityCode.SUBMISSION_CREATED
#            elif action in ['pre_remove', 'pre_clear']:
#                code = ActivityCode.SUBMISSION_DELETED
#            else:
#                return
#
#            if action in ['post_add', 'pre_remove']:
#                users = User.objects.filter(pk__in=pk_set)
#            else: # pre_clear
#                users = instance.authors.all()
#
#            submission_activity(code, instance, users)
#        except ObjectDoesNotExist:
#            pass

@receiver([post_save, pre_delete], dispatch_uid=DISPATCH_UID, sender=CommentRevision)
@skip_raw_save
def commentrevision_activity(sender, instance, **kwargs): #pylint: disable=W0613
    comment = instance.comment
    parent_model_class = comment.parent_content_type.model_class

    if parent_model_class==Submission:
        submission_activity(ActivityCode.SUBMISSION_CHANGED, instance.parent)

    elif parent_model_class==Review:
        submission_activity(ActivityCode.SUBMISSION_CHANGED, instance.parent.submission)

@receiver([post_save, pre_delete], dispatch_uid=DISPATCH_UID, sender=CheckResultStepIO)
@skip_raw_save
def checkresultstepio_activity(sender, instance, **kwargs): #pylint: disable=W0613
    checkresultstep_activity(sender, instance.checkresultstep)

@receiver([post_save, pre_delete], dispatch_uid=DISPATCH_UID, sender=CheckResultStep)
@skip_raw_save
def checkresultstep_activity(sender, instance, **kwargs): #pylint: disable=W0613
    submission_foreignkey_activity(sender, instance.checkresult)

@receiver([post_save, pre_delete], dispatch_uid=DISPATCH_UID, sender=SubmissionFile)
@receiver([post_save, pre_delete], dispatch_uid=DISPATCH_UID, sender=Review)
@receiver([post_save, pre_delete], dispatch_uid=DISPATCH_UID, sender=CheckResult)
@skip_raw_save
def submission_foreignkey_activity(sender, instance, **kwargs): #pylint: disable=W0613
    submission_activity(ActivityCode.SUBMISSION_CHANGED, instance.submission)

def submission_activity(code, submission, users=None):
    courseedition = submission.courseedition
    assignmentedition = submission.assignmentedition

    if users is None:
        users = submission.authors.all()

    for user in users:
        cluster = courseedition.get_user_cluster(user)
        try:
            send_activity(Submission, code,
                          user, courseedition, cluster, assignmentedition,
                          submission=submission)
        except ObjectDoesNotExist:
            pass

# Name changes

from peach3.models.i18n import TranslatedName

@receiver([post_save, pre_delete], dispatch_uid=DISPATCH_UID, sender=TranslatedName)
@skip_raw_save
def translatedname_activity(sender, instance, **kwargs): #pylint: disable=W0613
    try:
        model_class = instance.content_type.model_class

        if model_class==CourseEdition:
            courseedition_activity(ActivityCode.COURSE_CHANGED, instance.object)

        elif model_class==Cluster:
            cluster_activity(ActivityCode.CLUSTER_CHANGED, instance.object)

        elif model_class==AssignmentEdition:
            assignmentedition_activity(ActivityCode.ASSIGNMENT_CHANGED, instance.object)

    except ObjectDoesNotExist:
        pass
