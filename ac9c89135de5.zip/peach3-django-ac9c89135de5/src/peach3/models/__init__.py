""" This file is part of PEACH.

    Copyright (C) 2006-2012 Eindhoven University of Technology
"""
APP_LABEL = 'peach3'

#pylint: disable=W0401
from peach3.models.activity import *
from peach3.models.assignment import *
from peach3.models.cache import *
from peach3.models.checking import *
from peach3.models.cluster import *
from peach3.models.course import *
from peach3.models.files import *
from peach3.models.flag import *
from peach3.models.forum import *
from peach3.models.grade import *
from peach3.models.i18n import *
from peach3.models.news import *
from peach3.models.pdf import *
from peach3.models.peerreview import *
from peach3.models.period import *
from peach3.models.auth import *
from peach3.models.proglang import *
from peach3.models.realm import *
from peach3.models.report import *
from peach3.models.review import *
from peach3.models.submission import *
from peach3.models.timerange import *
from peach3.models.wiki import *
