from django.db import models
from django.core.exceptions import ValidationError
from django.utils.translation import ugettext as _, ugettext_lazy

from south.modelsinspector import add_introspection_rules

__all__ = ('ClusterStaffLevelField',)

class ClusterStaffLevelField(models.PositiveSmallIntegerField):
    description = ugettext_lazy("Integer")

    def formfield(self, **kwargs):
        defaults = {'min_value': 1, 'max_value': 10}
        defaults.update(kwargs)
        return super(ClusterStaffLevelField, self).formfield(**defaults)

    def clean(self, value, modelinstance):
        value = super(ClusterStaffLevelField, self).clean(value, modelinstance)
        if value<1 or value>10:
            raise ValidationError, _("Invalid level (acceptable levels are 1 to 10)")
        return value

add_introspection_rules([], [r"^peach3\.models\.fields\.ClusterStaffLevelField"])
