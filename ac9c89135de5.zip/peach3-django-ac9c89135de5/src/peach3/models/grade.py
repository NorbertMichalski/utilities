""" This file is part of PEACH.

    Copyright (C) 2006-2012 Eindhoven University of Technology
"""
from django.db import models

from peach3.managers.grade import GradeManager
from peach3.models import APP_LABEL
from peach3.models.i18n import I18NMixin
from peach3.utils.ppk import PPKModelMixin, PPKManager

# Create your models here.

__all__ = ('GradingSystem', 'Grade',)

class GradingSystem(models.Model, I18NMixin, PPKModelMixin):
    default_name = models.CharField(max_length=100, unique=True)
    default_language = models.CharField(max_length=16,
                                        choices=I18NMixin.LANGUAGE_CHOICES,
                                        default=I18NMixin.LANGUAGE_DEFAULT)

    objects = PPKManager()

    class Meta: #pylint: disable=W0232,C0111,R0903
        app_label = APP_LABEL
        ordering = 'default_name',

class Grade(models.Model, I18NMixin, PPKModelMixin):
    system = models.ForeignKey(GradingSystem)
    icon = models.CharField(max_length=80, blank=True)

    value_low = models.DecimalField(max_digits=7, decimal_places=2)
    value_high = models.DecimalField(max_digits=7, decimal_places=2, null=True, blank=True)

    passing = models.NullBooleanField()

    default_name = models.CharField(max_length=100, unique=False)
    default_language = models.CharField(max_length=16,
                                        choices=I18NMixin.LANGUAGE_CHOICES,
                                        default=I18NMixin.LANGUAGE_DEFAULT)

    objects = GradeManager()

    class Meta: #pylint: disable=W0232,C0111,R0903
        app_label = APP_LABEL
        unique_together = ('system', 'default_name')
        ordering = 'system', 'value_low'

