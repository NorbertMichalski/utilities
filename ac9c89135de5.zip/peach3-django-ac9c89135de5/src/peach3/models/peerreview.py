from django.conf import settings
from django.contrib.contenttypes import generic
from django.contrib.contenttypes.models import ContentType
from django.db import models, transaction, DatabaseError
from django.db.models import Q
from django.utils.datastructures import SortedDict
from django.utils.translation import ugettext_lazy as _
from django.utils import timezone, six

from peach3.core.modelurl import get_model_absolute_url
from peach3.managers.peerreview import PeerReviewAssignmentManager, PeerReviewManager
from peach3.models import APP_LABEL
from peach3.models.assignment import AssignmentEdition
from peach3.models.flag import Flag, FlaggedObject
from peach3.models.grade import GradingSystem, Grade
from peach3.models.submission import Submission, SubmissionFile, SubmissionAuthor
from peach3.utils.dates import TimeRange
from peach3.utils.permissions import get_current_user
from peach3.utils.ppk import PPKModelMixin, PPKManager
from peach3.utils.submission import get_user_coauthors

import random
import sys
import time

__all__ = ('PeerReviewAssignment', 'PeerReviewBundle', 'PeerReview', 'PeerReviewGrade')

def number_to_letters(n):
    """
        Convert a number to a letter sequence of the alphabet
        0 -> A
        ...
        25 -> Z
        26 -> AA
        27 -> AB
        ...
    """
    assert n >= 0
    letters = ""
    while True:
        n, mod = divmod(n, 26)
        letters = chr(mod + ord('A')) + letters
        if not n:
            break
    return letters

class PeerReviewAssignment(models.Model, PPKModelMixin):
    """ The PeerReviewAssignment is a special type of assignment where the submission is a peer review
    of a work that was submitted in another assignment (the original assignment)
    """
    NOT_AVAILABLE = 0
    OPTIONAL = 1
    REQUIRED = 2

    REPORTING_OPTIONS = [
        (NOT_AVAILABLE, _("No reporting")),
        (OPTIONAL, _("Optional reporting")),
        (REQUIRED, _("Reporting required")),
    ]

    REPORTING_TYPE_ALL = 'all'
    REPORTING_TYPE_PDF = 'pdf'
    REPORTING_TYPE_TEXT = 'text'
    REPORTING_TYPE_CHOICES = [
        (REPORTING_TYPE_ALL, _("Text and PDF")),
        (REPORTING_TYPE_PDF, _("Only PDF")),
        (REPORTING_TYPE_TEXT, _("Only Text")),
    ]

    RANKING_OPTIONS = [
        (NOT_AVAILABLE, _("No ranking")),
        (REQUIRED, _("Ranking required")),
    ]

    GRADING_OPTIONS = [
        (NOT_AVAILABLE, _("No grading")),
        (OPTIONAL, _("Optional grading")),
        (REQUIRED, _("Grading required")),
    ]

    # The assignment that is the peer review
    review_assignment = models.OneToOneField(AssignmentEdition, primary_key=True)

    # The original assignment where the work that needs to be peer-reviewed was submitted
    original_assignment = models.ForeignKey(
        AssignmentEdition, related_name='peerreviewed_via_set', db_index=True,
        verbose_name=_("Assignment under Review"),
    )

    # The distribution spread determines how many review work each reviewer has to do
    bundle_size = models.IntegerField(default=3)

    # Determines whether the submission that needs to be peer-reviewed is reviewed by a single User
    # or by a group of Users. If it is reviewed as a group it is enforced that this can only be done by the same
    # group composition that submitted in the original assignment
    reviewed_by_group = models.BooleanField(default=True)

    # Types of peer reviewing enabled
    ranking = models.IntegerField(choices=RANKING_OPTIONS, default=NOT_AVAILABLE)
    reporting = models.IntegerField(choices=REPORTING_OPTIONS, default=REQUIRED)
    grading = models.IntegerField(choices=GRADING_OPTIONS, default=NOT_AVAILABLE)

    # The grading system and flags used for grading submissions (done by the reviewer)
    submission_gradingsystem = models.ManyToManyField(
        GradingSystem, blank=True, related_name='peerreviewassignment_submission_set',
        verbose_name=_("Grading system for reviewer to grade submissions"),
    )
    submission_flags = models.ManyToManyField(
        Flag, related_name='peerreviewassignment_submission_set', blank=True,
        verbose_name=_("Flags available for reviewer to flag inappropriate submissions"),
    )

    # The type of reports to accept
    reporting_type = models.CharField(
        max_length=4, choices=REPORTING_TYPE_CHOICES, default=REPORTING_TYPE_ALL,
        verbose_name=_("Report file type")
    )

    # The maximum amount of equally grouped student groups.
    # A None value means no restriction is enforced.
    ranking_max_equal_groups = models.IntegerField(null=True, blank=True)

    # The maximum amount of students that can be equally grouped
    # A None value means no restriction is enforced.
    ranking_max_equal_group_size = models.IntegerField(null=True, blank=True)

    # Self-reviewing options
    self_review = models.BooleanField()
    self_reporting = models.IntegerField(choices=REPORTING_OPTIONS, default=NOT_AVAILABLE)

    ### Peer review feedback to original author

    # Timerange for the release of the peer review feedback
    _review_result_visible_from = models.DateTimeField(
        null=True, blank=True, db_column='review_result_visible_from'
    )
    _review_result_visible_until = models.DateTimeField(
        null=True, blank=True, db_column='review_result_visible_until'
    )

    # Peer review types for feedback
    feedback_report = models.BooleanField(default=False)
    feedback_rank = models.BooleanField(default=False)
    feedback_grade = models.BooleanField(default=False)

    ### Peer review rating by original author

    # Timerange to enable review rating
    _review_rating_enabled_from = models.DateTimeField(
        null=True, blank=True, db_column='review_rating_enabled_from'
    )
    _review_rating_enabled_until = models.DateTimeField(
        null=True, blank=True, db_column='review_rating_enabled_until'
    )

    # The grading system and flags used for grading reviews feedback (by the original submission author)
    review_gradingsystem = models.ManyToManyField(
        GradingSystem, blank=True, related_name='peerreviewassignment_review_set',
        verbose_name=_("Grading systems for original author"),
    )

    review_grades_distributed_min = models.PositiveIntegerField(
        default=0,
        verbose_name=_("Distribution minimum sum"),
        help_text=_("Minimum sum of grade values original author should assign (distribution) [0 to disable]"),
    )

    review_grades_distributed_max = models.PositiveIntegerField(
        default=0,
        verbose_name=_("Distribution maximum sum"),
        help_text=_("Maximum sum of grade values original author can assign (distribution) [0 to disable]"),
    )

    review_grades_required = models.BooleanField(
        default=False,
        verbose_name=_("All reviews must be provided with a feedback grade or flag"),
    )

    review_grades_unique = models.BooleanField(
        default=False,
        verbose_name=_("All review grades must be unique"),
    )

    review_flags = models.ManyToManyField(
        Flag, blank=True, related_name = 'peerreviewassignment_review_set',
        verbose_name=_("Flags available for original author"),
    )

    objects = PeerReviewAssignmentManager()

    get_absolute_url = get_model_absolute_url

    class Meta: #pylint: disable=W0232,C0111,R0903
        app_label = APP_LABEL
        db_table = APP_LABEL+'_peerreview_assignment'
        unique_together = ('review_assignment', 'original_assignment')
        index_together = [
            ('review_assignment', 'original_assignment'),
        ]

    def __unicode__(self):
        return u"'%s' reviews '%s'" % (self.review_assignment, self.original_assignment)

    ### Model methods
    def set_review_result_visible_range(self, rng):
        self._review_result_visible_from = rng.begin
        self._review_result_visible_until = rng.end
    set_review_result_visible_range.alters_data = True

    def get_review_result_visible_range(self):
        return TimeRange(begin=self._review_result_visible_from, end=self._review_result_visible_until)

    review_result_visible_range = property(get_review_result_visible_range, set_review_result_visible_range)

    def is_published(self, user, when=None):
        return self.review_result_visible_range.in_range(when)

    def reporting_available(self):
        " Returns whether the user is able to do an individual review of a submission "

        return self.reporting != PeerReviewAssignment.NOT_AVAILABLE

    def reporting_required(self):
        " Returns whether the user is required to do an individual review of a submission "

        return self.reporting == PeerReviewAssignment.REQUIRED

    def self_reporting_available(self):
        " Returns whether the user is able to do an individual review of a submission "

        return self.self_reporting != PeerReviewAssignment.NOT_AVAILABLE

    def self_reporting_required(self):
        " Returns whether the user is required to do an individual review of a submission "

        return self.self_reporting == PeerReviewAssignment.REQUIRED

    def reporting_type_allowed(self, rtype):
        return self.reporting_available() and self.reporting_type in [rtype, PeerReviewAssignment.REPORTING_TYPE_ALL]

    def ranking_available(self):
        " Returns whether the user is able to do a ranking "

        return self.ranking != PeerReviewAssignment.NOT_AVAILABLE

    def ranking_required(self):
        " Returns whether the user is able to do a ranking "

        return self.ranking == PeerReviewAssignment.REQUIRED

    def grading_available(self):
        " Returns whether the user is able to do grading "

        return self.grading != PeerReviewAssignment.NOT_AVAILABLE

    def grading_required(self):
        " Returns whether the user is able to do grading "

        return self.grading == PeerReviewAssignment.REQUIRED

    def submission_flagging_available(self):
        return self.submission_flags.exists()

    def get_bundle(self, reviewer, select_related=None):
        bundles = self.peerreviewbundle_set
        if select_related:
            bundles = bundles.select_related(*select_related)

        try:
            return bundles.get(reviewer=reviewer)
        except self.peerreviewbundle_set.model.DoesNotExist:
            return None

    def is_complete(self, reviewer):
        """ Returns:
        None: User has not retrieved a bundle
        False: Bundle retrieved, but review work not yet completed.
        True: completed.
        """

        bundle = self.get_bundle(reviewer)
        if not bundle:
            return None

        reviewed, ranked, graded = bundle.get_all_states()

        # Check if the user has done all review work (if required)
        if self.reporting_required() and not reviewed:
            return False

        # Check if the user has done his ranking work (if required)
        if self.ranking_required() and not ranked:
            return False

        # Check if the user has done his grading work (if required)
        if self.grading_required() and not graded:
            return False

        return True

    def feedback_grade_distribution_state(self, reviewee):
        """
        Returns the state of the feedback grade distribution.
        Returns a tuple (min_done, sum_left).
        The first item is a boolean indicating whether the minimum grade amount and values have been assigned
        (ie. user is done),
        the second value indicates the total value left to be assigned, or None if no maximum exists.

        :param reviewee: The peer reviewed user
        :return: tuple (min_done, sum_left)
        """

        # Need to exclude all flagged peer reviews
        flagged_ids = FlaggedObject.objects.filter(
            parent_content_type = ContentType.objects.get_for_model(PeerReview)
        ).values_list('parent_id', flat=True)

        # Get reviewee's reviews (but not the flagged ones or the self-review)
        reviews = PeerReview.objects.filter(
            bundle__assignment=self,
            submission__submisionauthor__author=reviewee,
        ).exclude(
            pk__in=flagged_ids
        ).exclude(
            identifier=''
        )

        grades = [
            review.get_review_grade()
            for review in reviews
        ]

        if self.review_grades_required:
            min_done = None not in grades
        else:
            min_done = True

        if (min_done and self.review_grades_distributed_min > 0) or self.review_grades_distributed_max > 0:
            grade_value_sum = sum(
                grade.value_low for grade in grades if grade
            )

        if min_done and self.review_grades_distributed_min > 0:
            min_done = grade_value_sum >= self.review_grades_distributed_min

        if self.review_grades_distributed_max > 0:
            sum_left = self.review_grades_distributed_max - grade_value_sum
        else:
            sum_left = None

        return min_done, sum_left

    def set_review_rating_enabled_range(self, rng):
        self._review_rating_enabled_from = rng.begin
        self._review_rating_enabled_until = rng.end

    set_review_rating_enabled_range.alters_data = True

    def get_review_rating_enabled_range(self):
        return TimeRange(begin=self._review_rating_enabled_from, end=self._review_rating_enabled_until)

    review_rating_enabled_range = property(get_review_rating_enabled_range, set_review_rating_enabled_range)

    def user_can_review(self, reviewer):
        """ Returns true if users can peer-reviewing other submissions.
        They need either need to have an assigned peer review bundle or
        have an accepted submission for the original assignment
        (This does not check for the review assignment's deadline!)
        """
        return self.user_started_reviewing(reviewer) or \
               SubmissionAuthor.objects.filter(
                   submission__assignmentedition=self.original_assignment,
                   author=reviewer,
                   latest_accepted=True,
               ).exists()

    def user_started_reviewing(self, reviewer):
        " Check to see if someone already has peer reviews distributed to him. "
        return self.peerreviewbundle_set.filter(reviewer=reviewer).exists()

    #noinspection PyBroadException
    def create_review_submission(self, authors):
        """ Create an artificial submission created by the peer review system, to store the review
        files / text / order from the user.
        Note that this submission is still an actual submission in Peach for the review assignment,
        as if it was submitted by the user himself.
        """
        attempt = 0
        while True:
            sid = transaction.savepoint()
            try:
                submissions = Submission.objects.filter(assignmentedition=self.review_assignment,
                                                        authors__in=authors).distinct()[:1]

                if submissions:
                    submission = submissions[0]

                else:
                    submission = Submission.objects.create(
                        assignmentedition=self.review_assignment,
                        courseedition=self.review_assignment.courseedition,
                    )

                submission.add_author(*authors)

                submission.submitted = timezone.now()
                submission.submitted_by = get_current_user()
                submission.save(update_fields=['submitted', 'submitted_by'])

                transaction.savepoint_commit(sid)
                return submission

            except:
                exc_info = sys.exc_info()

                try:
                    # A deadlock can end a transaction prematurely, so the savepoint might be invalid
                    transaction.savepoint_rollback(sid)
                except DatabaseError:
                    pass

                attempt += 1
                if attempt >= 10:
                    # ReRaise the original exception
                    six.reraise(*exc_info)

                time.sleep(attempt * 0.2)

    @transaction.commit_on_success
    def get_or_create_bundle(self, reviewer):
        """ This is the core of the peer review system submission distribution system
        A reviewer comes here to get a list of submissions he has to review.

        The reviewer is normally a single User, but if the reviewed_by_group option is on
        the reviewer may represent a group of Users. This group is the same as the group he submitted
        his work in

        In doing so the system returns the submissions that are allocated to him, or if there aren't yet any
        submissions allocated to the reviewer, the system allocates them right there and then. Right here
        in this very function

        Returns an initialized PeerReviewBundle object, or None if there were insufficient
        submissions available for review
        """
        # If the reviewer already has peer reviews allocated to him, return it
        try:
            return self.peerreviewbundle_set.get(reviewer=reviewer)
        except PeerReviewBundle.DoesNotExist:
            pass

        sid = transaction.savepoint()

        # Get the list of all submissions that are subject to peer reviewing
        submissions = Submission.objects.filter(assignmentedition=self.original_assignment,
                                                submissionauthor__latest_accepted=True)\
                                        .distinct()

        # Filter submissions in the same cluster as the reviewer
        submissions = submissions.filter(clusters__clustermember__user=reviewer)

        # alternative when Clusters are ignored (should be made configurable)
        #submissions = submissions.filter(clusters__clustermember__isnull=False)

        # Exclude submissions by reviewer
        submissions = submissions.exclude(authors=reviewer)

        # Annotate the submissions with
        # * submission_bundle_count: how many times they have been distributed to be peer-reviewed
        # * author_bundle_count: whether the author of that submission has already retrieved his own peer review work
        submissions = submissions.extra(
            select=SortedDict([
                ('submission_bundle_count',
                    'SELECT Count(*) '
                    'FROM   peach3_peerreview '
                    '       INNER JOIN peach3_peerreviewbundle '
                    '               ON ( peach3_peerreview.bundle_id = peach3_peerreviewbundle.id ) '
                    'WHERE  ( peach3_peerreviewbundle.assignment_id = %s '
                    '         AND peach3_peerreview.submission_id = peach3_submission.id )'
                ),
                ('author_bundle_count',
                    'SELECT Count(*) '
                    'FROM   peach3_peerreviewbundlereviewer '
                    'WHERE  ( peach3_peerreviewbundlereviewer.assignment_id = %s '
                    '         AND  peach3_peerreviewbundlereviewer.reviewer_id IN '
                    '              ( SELECT U0.id '
                    '                  FROM  peach3_user U0 '
                    '                        INNER JOIN peach3_submissionauthor U1 '
                    '                                ON ( U0.id = U1.author_id ) '
                    '                  WHERE U1.submission_id = peach3_submission.id ) )'
                )
            ]),
            select_params=[self.pk, self.pk]
        )

        # Group the submissions in order of "urgency", the more urgent it is a submission gets
        # peer-reviewed, the lower the index will be
        grouped_submissions = []
        available_submissions = 0
        for submission in submissions.select_for_update().iterator():
            # .select_for_update() will lock the selected submissions,
            # causing any concurrent access to these submissions to lock.
            # This is needed to prevent handing out the same submission
            # multiple times by accident

            available_submissions += 1
            index = submission.submission_bundle_count*2 + min(submission.author_bundle_count, 1)

            while len(grouped_submissions)<=index:
                grouped_submissions.append([])

            grouped_submissions[index].append(submission)

        # If there are not enough submissions to fill a bundle, return None
        if available_submissions < self.bundle_size:
            return None

        # Create the Bundle
        bundle = self.peerreviewbundle_set.create()
        reviewers = [reviewer]
        if self.reviewed_by_group:
            reviewers.extend(get_user_coauthors(reviewer, self.original_assignment))

        for r in reviewers:
            prbr, created = PeerReviewBundleReviewer.objects.get_or_create(
                assignment = self,
                reviewer = r,
                defaults = {
                    'bundle': bundle,
                }
            )

            if not created:
                bundle.delete()
                try:
                    transaction.savepoint_rollback(sid)
                except DatabaseError:
                    pass
                return prbr.bundle

        identifiers = [number_to_letters(i) for i in xrange(self.bundle_size)]
        random.shuffle(identifiers)

        for identifier in identifiers:
            # Skip empty groups
            while not grouped_submissions[0]:
                grouped_submissions.pop(0)

            # The head of 'grouped_submissions' contains the set of submissions we
            # need to pick one of
            head = grouped_submissions[0]

            # Randomly pick one of the available submissions
            item = random.randrange(len(head))

            # Add submission to the bundle
            bundle.peerreview_set.create(
                submission = head.pop(item),
                identifier = identifier,
            )

        # Add reviewer's own submission to the bundle, if self-review is enabled
        if self.self_review:
            try:
                own_submission = Submission.objects.filter(
                    assignmentedition = self.original_assignment,
                    submissionauthor__author = reviewer,
                    submissionauthor__latest_accepted = True,
                ).latest('submitted')

            except Submission.DoesNotExist:
                pass

            else:
                bundle.peerreview_set.create(
                    submission = own_submission,
                    identifier = '',
                )

        return bundle

#    def getPeerReviewsByReviewer(self):
#        """ Get a list of user(-groups) coupled to the submissions they have to review
#        Returns a generator that returns items in the following format:
#        ( [user1, user2, ...], # reviewer
#          [peerreview1, peerreview2, ...]) # reviews he has to do
#        """
#        submissions = self.getReviewableSubmissions()
#        peer_reviews = PeerReview.objects.filter(bundle__assignment=self.review_assignment)\
#                                         .prefetch_related('submission__authors__profile__user',
#                                                           'reviewer__profile__user')
#
#        for submission in submissions:
#            yield (submission.authors.all(),
#                   filter(lambda peer_review: Set(peer_review.reviewer.all()) == Set(submission.authors.all()),
#                          peer_reviews))
#
#    def getPeerReviewsBySubmission(self):
#        """ Get a list of submission-authors coupled to the peer reviews objects that they have to be
#        reviewed by
#
#        Returns a generator that returns items in the following format:
#        ( [user1, user2, ...], # submission authors
#          [peerreview1, peerreview2, ...] # review-assignment that have to peer review the submission authors
#        """
#        submissions = self.getReviewableSubmissions()
#        peer_reviews = PeerReview.objects.filter(bundle__assignment=self.review_assignment)\
#                                         .prefetch_related('submission__authors__profile__user',
#                                                           'reviewer__profile__user')
#
#        for submission in submissions:
#            yield (submission.authors.all(),
#                   filter(lambda peer_review: peer_review.submission == submission, peer_reviews))


class PeerReviewBundleReviewer(models.Model):
    """ Additional model to enforce the unique relationship between PeerReviewAssignment and the reviewer

    Used as a replacement of the ManyToMany relationship on a bundle
    """
    assignment = models.ForeignKey(PeerReviewAssignment)
    bundle = models.ForeignKey("PeerReviewBundle")
    reviewer = models.ForeignKey(settings.AUTH_USER_MODEL)

    class Meta:
        app_label = APP_LABEL
        unique_together = 'assignment', 'reviewer'
        index_together = ('bundle', 'reviewer'),


class PeerReviewBundle(models.Model, PPKModelMixin):
    """ A bundle of PeerReviews for a group of users
    """
    # The peer-review assignment context
    assignment = models.ForeignKey(PeerReviewAssignment, db_index=True)

    # The reviewer(s) that should review the submission
    # A reviewer could be a single user a group of users depending on the reviewed_by_group setting
    # Groups must always be the same group composition as in the original assignment
    reviewer = models.ManyToManyField(settings.AUTH_USER_MODEL, through=PeerReviewBundleReviewer)

    objects = PPKManager()

    class Meta: #pylint: disable=W0232,C0111,R0903
        app_label = APP_LABEL

    def get_all_states(self):
        reviewed, ranked, graded = True, True, True

        for pr in self.peerreview_set.filter( Q(review__isnull=True)
                                            | Q(rank__isnull=True)
                                            | Q(submission_grade__isnull=True)
                                            )\
                                     .exclude(submission_flag__isnull=False):

            if reviewed and not pr.review:
                reviewed = False
            if ranked and not pr.rank:
                ranked = False
            if graded and not pr.submission_grade:
                graded = False

            if not (reviewed or ranked or graded):
                break

        return reviewed, ranked, graded

    def all_flagged(self):
        " Returns True when ALL submissions have been flagged (excluding the self-review) "
        return not self.peerreview_set.exclude(identifier='').filter(submission_flag__isnull=True).exists()

    def is_reviewed(self):
        " Returns True when peer review reporting is done, excluding the 'self' review "
        if self.assignment.reporting_required():
            # True when all have been reviewed or flagged
            return not self.peerreview_set.exclude(identifier='').filter(review__isnull=True,
                                                                         submission_flag__isnull=True).exists()
        else:
            # True when at least one is reviewed, or all have been flagged
            return self.peerreview_set.exclude(identifier='').filter(review__isnull=False).exists() \
                   or self.all_flagged()

    def is_self_reviewed(self):
        " Returns True when the self-review reporting is done "

        if self.assignment.reporting_required():
            # True when all have been reviewed
            return not self.peerreview_set.filter(identifier='', review__isnull=True).exists()
        else:
            # True when at least one is reviewed
            return self.peerreview_set.filter(identifier='', review__isnull=False).exists()

    def flags_count(self):
        " Number of flagged submissions, excluding the 'self' review "
        return self.peerreview_set.exclude(identifier='').filter(submission_flag__isnull=False).count()

    def reviews_count(self):
        " Number of peer review reports done, excluding the 'self' review "
        return self.peerreview_set.exclude(identifier='').filter(review__isnull=False).count()

    def is_ranked(self):
        " Whether ranking has been done "
        return not self.peerreview_set.filter(rank__isnull=True).exists() or self.all_flagged()

    def is_graded(self):
        " Returns True when peer review grading is done, excluding the 'self' review "
        if self.assignment.grading_required():
            # True when all have been graded or flagged
            return not self.peerreview_set.exclude(identifier='').filter(submission_grade__isnull=True,
                                                                         submission_flag__isnull=True).exists()
        else:
            # True when at least one is graded, or all have been flagged
            return self.peerreview_set.exclude(identifier='').filter(submission_grade__isnull=False).exists() \
                   or self.all_flagged()

    def is_self_graded(self):
        " Returns True when self-review grading is done, excluding the 'self' review "
        if self.assignment.grading_required():
            # True when all have been graded
            return not self.peerreview_set.filter(identifier='', submission_grade__isnull=True).exists()
        else:
            # True when at least one is graded
            return self.peerreview_set.filter(identifier='', submission_grade__isnull=False).exists()

    def grades_count(self):
        " Number of peer review grades done, excluding the 'self' review "
        return self.peerreview_set.exclude(identifier='').filter(submission_grade__isnull=False).count()

    def size(self):
        " Size of the bundle, excluding the optional 'self' review "
        return self.peerreview_set.exclude(identifier='').count()

    def self_review(self):
        " Whether there is a self-review in the bundle "
        return self.peerreview_set.filter(identifier='').exists()

    def completion_percentage(self):
        """ Calculates how much of this bundle is done.
        Returns an integer in the range 0..100 (a percentage) or None if this bundle
        has no or only one required component
        """
        assignment = self.assignment
        size = self.size()
        self_review = self.self_review()

        reporting_required = assignment.reporting_required()
        grading_required = assignment.grading_required()
        ranking_required = assignment.ranking_required()
        self_reporting_required = self_review and assignment.self_reporting_required()
        self_grading_required = self_review and grading_required

        todo = sum([
            size if reporting_required else 0,
            1 if self_reporting_required else 0,
            size if grading_required else 0,
            1 if self_grading_required else 0,
            1 if ranking_required else 0,
        ])

        if todo>1:
            flags_count = self.flags_count()
            done = sum([
                 self.reviews_count()+flags_count if reporting_required else 0,
                 1 if self_reporting_required and self.is_self_reviewed() else 0,
                 self.grades_count()+flags_count if grading_required else 0,
                 1 if self_grading_required and self.is_self_graded() else 0,
                 1 if ranking_required and self.is_ranked() else 0,
            ])

            return (done*100)/todo

        return None

    def get_ranked_reviews(self):
        """ Get the reviews in the ranked ordering
        Returns a list of lists
        """
        result, last_rank = [], None
        peerreviews = self.peerreview_set.all()

        # Sort peerreviews with same rank in a special way:
        #  if a peerreview has an identifier, sort them according to the identifier
        #  if it does not have an identifier, put it last (ie. 'A' < 'B' < 'C' < '')
        for peerreview in sorted(peerreviews, key=lambda pr:(pr.rank, not(pr.identifier), pr.identifier)):
            if last_rank is None or peerreview.rank != last_rank:
                result.append([peerreview])
            else:
                result[-1].append(peerreview)

            last_rank = peerreview.rank

        return result

    def get_ranking(self):
        """ Returns the ranking string, in the format "A|B,C|D",
        which means A is best, D is worst and B and C are equally good
        """

        result, last_rank = '', None
        for peerreview in self.peerreview_set.order_by('rank', 'identifier'):
            if not result:
                if peerreview.rank == last_rank:
                    result += ','
                else:
                    result += '|'

            result += peerreview.identifier
            last_rank = peerreview.rank

        return result

    @transaction.commit_on_success
    def set_ranking(self, order):
        """ Set the review ranking. `order` is a string in the format "A|B,C|D",
        which means A is best, D is worst and B and C are equally good
        """

        peerreviews = dict(
            (peerreview.identifier, peerreview)
            for peerreview in self.peerreview_set.all()
        )

        for peerreview in peerreviews.itervalues():
            peerreview.rank = None

        rank = 1
        for level in order.split('|'):
            ids = level.split(',')
            for review_id in ids:
                peerreviews[review_id.strip()].rank = rank

            rank += len(ids)

        for peerreview in peerreviews.itervalues():
            peerreview.save(update_fields=['rank'])

    def __unicode__(self):
        return u"'%s' reviewers: %s" % (
            self.assignment.review_assignment,
            ', '.join(u.get_full_name() for u in self.reviewer.all()),
        )

class PeerReview(models.Model, PPKModelMixin):
    """ A PeerReview couples a single submission to a group of reviewers (which can be one User, or a group of Users).

    This object represents that the reviewer has to peer-review a submission (which he might or might not have already done).

    Note that there is a many-to-many relationship between submission and reviewer
    A single submission may have to be reviewed by multiple reviewers (with a maximum of bundle_size)
    And a reviewer may have to review multiple submissions

    """
    bundle = models.ForeignKey(PeerReviewBundle, db_index=True)

    # The user visible identifier of the submission, so that the user can distinguish between multiple
    # submissions that are otherwise anonimized. Blank for 'self' reviews
    identifier = models.CharField(max_length=16, blank=True)

    # The submission that the reviewer should review
    submission = models.ForeignKey(Submission)

    # The actual review
    # May be empty if the reviewer hasn't done his job yet
    review = models.ForeignKey(SubmissionFile, blank=True, null=True)
    rank = models.PositiveIntegerField(blank=True, null=True)

    # the reviewer can indicate the quality of the submission with the submission_grade
    submission_grade = models.ForeignKey(Grade, null=True, blank=True, related_name='submission_grade')

    # the reviewer can flag an inappropriate submission with submission_flag
    submission_flag = models.ForeignKey(FlaggedObject, # A FlaggedObject with submission as parent
                                        blank=True, null=True,
                                        related_name='submission_flag')

    # The author(s) can also flag reviews
    review_flags = generic.GenericRelation(FlaggedObject, # A FlaggedObject with this object as parent
                                           object_id_field='parent_id',
                                           content_type_field='parent_content_type')

    # Who created this review
    reviewed_by = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True,
                                    help_text="The last author to modify the review")
    reviewed_on = models.DateTimeField(null=True, blank=True,
                                       help_text="The last time the review was modified")

    objects = PeerReviewManager()

    class Meta: #pylint: disable=W0232,C0111,R0903
        app_label = APP_LABEL
        unique_together = ('bundle', 'identifier')
        index_together = [
            ('bundle', 'identifier'),
        ]

    def reporting_available(self):
        " Returns whether the user is able to do an individual review of a submission "
        if self.identifier:
            return self.bundle.assignment.reporting_available()
        else:
            return self.bundle.assignment.self_reporting_available()

    def reporting_required(self):
        " Returns whether the user is required to do an individual review of a submission "
        if self.identifier:
            return self.bundle.assignment.reporting_required()
        else:
            return self.bundle.assignment.self_reporting_required()

    def is_reviewed(self):
        return bool(self.review) or bool(self.submission_flag)

    def is_graded(self):
        return bool(self.submission_grade) or bool(self.submission_flag)

    def is_ranked(self):
        return bool(self.rank)

    def submission_flagged(self):
        return bool(self.submission_flag)

    def is_self_review(self, user=None):
        return self.identifier == '' and (user is None or self.bundle.reviewer.filter(pk=user.pk).exists())

    def get_review_grade(self):
        try:
            return self.review_grade.grade
        except PeerReviewGrade.DoesNotExist:
            return None

    def review_is_graded(self):
        return self.review_grade is not None

    def review_is_flagged(self):
        return self.review_flags.exists()

    def __unicode__(self):
        return 'Identifier %s submission %d' % (self.identifier, self.submission.id)

    get_absolute_url = get_model_absolute_url

class PeerReviewGrade(models.Model):
    peerreview = models.OneToOneField(PeerReview,
                                      related_name='review_grade',
                                      primary_key=True)

    grade = models.ForeignKey(Grade)

    created = models.DateTimeField(default=timezone.now)
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL,
                                   default=get_current_user)

    class Meta: #pylint: disable=W0232,C0111,R0903
        app_label = APP_LABEL
