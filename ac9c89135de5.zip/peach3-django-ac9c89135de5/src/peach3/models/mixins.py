""" This file is part of PEACH.

    Copyright (C) 2006-2009 Eindhoven University of Technology
"""

__all__ = ('CreationMixin', 'RevisionMixin', )# 'EditionMixin',

class CreationMixin(object):
    """ A mixin class for models using a 'created' date field for ordering.
        Requires a function called 'get_grouping_field_name' to return the
        name of the field(s) that these objects should be grouped by
    """
    def _get_siblings_filter(self):
        fields = self.get_grouping_field_name()
        if not isinstance(fields, (list, tuple)):
            fields = [fields]
        return dict((field, getattr(self, field)) for field in fields)

    def get_previous(self):
        if hasattr(self, '_previous_cache'):
            prev = getattr(self, '_previous_cache')
        else:
            try:
                prev = self.get_previous_by_created(**self._get_siblings_filter())
            except self.DoesNotExist:
                prev = None
            self._previous_cache = prev #pylint: disable=W0201
        return prev
    previous = property(get_previous)

    def get_next(self):
        if hasattr(self, '_next_cache'):
            next_ = getattr(self, '_next_cache')
        else:
            try:
                next_ = self.get_next_by_created(**self._get_siblings_filter())
            except self.DoesNotExist:
                next_ = None
            self._next_cache = next_ #pylint: disable=W0201
        return next_
    next = property(get_next) #@ReservedAssignment

class RevisionMixin(CreationMixin):
    """ A mixin class for models using a revision based ordering.
        The difference between a revision and an edition is that a
        new revision replaces an earlier revision, whereas a new edition
        lives next to the older editions
    """

    def get_revision(self):
        """ Get revision number
        """
        rev = getattr(self, '_revision_cache', None)
        if rev is None:
            rev = (self.__class__._default_manager #pylint: disable=W0212
                                 .using(self._state.db)
                                 .filter(created__lt=self.created, pk__lt=self.pk,
                                         **self._get_siblings_filter()).count() + 1)

        return rev
    revision = property(get_revision)

#class EditionMixin(CreationMixin):
#    """ A mixin class for models using a edition based ordering.
#        The difference between a revision and an edition is that a
#        new revision replaces an earlier revision, whereas a new edition
#        lives next to the older editions
#    """
#    def get_edition(self):
#        """ Get edition number
#        """
#        ed = getattr(self, '_edition_cache', None)
#        if ed is None:
#            prev = self.previous
#            if prev:
#                ed = prev.edition+1
#            else:
#                ed = 1
#            self._edition_cache = ed
#        return ed
#    edition = property(get_edition)
#
#class MarkupMixin(object):
#    def get_parsed(self, *args, **kwargs):
#        if not hasattr(self, '_content_rst'):
#            self._content_rst = rst2html(self.content, *args, **kwargs)
#        return self._content_rst

class OrderMixin(object):
    def swap_order(self, other):
        assert isinstance(other, self.__class__)

        tmp = other.order
        other.order = self.order #pylint: disable=E0203
        self.order = tmp #pylint: disable=W0201

        other.save(update_fields=['order'])
        self.save(update_fields=['order'])
    swap_order.alters_data=True
