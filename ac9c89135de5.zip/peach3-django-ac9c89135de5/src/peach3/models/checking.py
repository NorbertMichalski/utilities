""" This file is part of PEACH.

    Copyright (C) 2006-2009 Eindhoven University of Technology
"""
from django import dispatch
from django.conf import settings
from django.core.cache import cache
from django.db import models
from django.db.models.signals import post_delete, post_save
from django.utils.timezone import now
from django.utils.translation import ugettext_lazy as _, get_language

from peach3.managers.checking import ReasonManager
from peach3.models import APP_LABEL
from peach3.models.files import FileRevision
from peach3.models.grade import Grade
from peach3.models.mixins import RevisionMixin
from peach3.models.submission import Submission, SubmissionAuthor
from peach3.utils.cache import cache_key
from peach3.utils.ppk import PPKModelMixin, PPKManager

__all__ = ('CheckResult', 'Reason', 'ReasonAltDescription',
           'CheckResultStep', 'CheckResultStepIO',)

class CheckResult(models.Model, RevisionMixin, PPKModelMixin):
    STATES = (
        ('CHECKING', _("Checking")),
        ('CHECKED',  _("Checked")),
        ('SYSFAIL',  _("System failure")),
    )

    submission = models.ForeignKey(Submission)
    created = models.DateTimeField(default=now)
    checked = models.DateTimeField(null=True, blank=True)
    checked_level = models.PositiveSmallIntegerField(null=True, blank=True)

    state = models.CharField(max_length=8, blank=True, choices=STATES)
    grade = models.ForeignKey(Grade, null=True, blank=True)
    report = models.TextField(blank=True)

    # One score field for each observer/reviewer level
    score_0 = models.IntegerField(null=True, blank=True)
    score_1 = models.IntegerField(null=True, blank=True)
    score_2 = models.IntegerField(null=True, blank=True)
    score_3 = models.IntegerField(null=True, blank=True)
    score_4 = models.IntegerField(null=True, blank=True)
    score_5 = models.IntegerField(null=True, blank=True)
    score_6 = models.IntegerField(null=True, blank=True)
    score_7 = models.IntegerField(null=True, blank=True)
    score_8 = models.IntegerField(null=True, blank=True)
    score_9 = models.IntegerField(null=True, blank=True)
    score_10 = models.IntegerField(null=True, blank=True)

    objects = PPKManager()

    class Meta: #pylint: disable=W0232,C0111,R0903
        app_label = APP_LABEL
        get_latest_by = 'created'
        ordering = 'submission', 'created'

    def get_score(self, user):
        if user:
            level = min(self.submission.get_observelevel(user) or 0, 10)
        else:
            level = 0
        return getattr(self, 'score_%d' % level)

    def get_steps_count(self, user, stage=None):
        " Returns a tuple (passed, total) with the number of test runs in this checkresult that are visible for user "

        level = self.submission.get_observelevel(user) or 0

        q = self.checkresultstep_set.exclude(level__gt=level)
        if stage:
            q = q.filter(stage=stage)

        total = q.count()
        passed = q.filter(passed=True).count()

        return (passed, total)

    ### Ordering mixin interface
    @staticmethod
    def get_grouping_field_name():
        return 'submission'

@dispatch.receiver([post_save, post_delete], sender=CheckResult)
def checkresult_changed(sender, instance, **kwargs): #pylint: disable=W0613,W0621
    instance.submission.save(update_fields=['modified']) # Touch submission's last modified timestamp
    SubmissionAuthor.objects.update_submission(instance.submission)

class Reason(models.Model):
    code = models.CharField(max_length=16, db_index=True)
    param1 = models.CharField(max_length=16, blank=True)
    param2 = models.CharField(max_length=16, blank=True)

    default_description = models.TextField()
    default_language = models.CharField(max_length=16,
                                        choices=settings.LANGUAGES,
                                        default=settings.LANGUAGE_CODE)

    objects = ReasonManager()

    class Meta: #pylint: disable=W0232,C0111,R0903
        app_label = APP_LABEL

    def get_description(self, lang=None):
        if lang is None:
            lang = get_language()

        key = cache_key('peach3.models.Reason.get_description', self, lang)

        cached = cache.get(key)
        if cached is None:
            try:
                description = self.reasonaltdescription_set.get(language=lang).description
            except self.reasonaltdescription_set.model.DoesNotExist:
                description = None

            cache.set(key, (description,))

        else:
            description = cached[0]

        if description:
            return description
        else:
            return self.default_description

    description = property(get_description)

    def __unicode__(self):
        code = self.code
        if self.param1 or self.param2:
            code = code+':'+self.param1
        if self.param2:
            code = code+':'+self.param2
        return code

class ReasonAltDescription(models.Model):
    ### Model definition
    reason = models.ForeignKey(Reason)
    language = models.CharField(max_length=16, choices=settings.LANGUAGES)
    description = models.CharField(max_length=80)

    class Meta: #pylint: disable=W0232,C0111,R0903
        app_label = APP_LABEL
        unique_together = ('reason', 'language')
        index_together = [
            ('reason', 'language'),
        ]

class CheckResultStep(models.Model, PPKModelMixin):
    STAGES = (
        ('PREPROCESSING', _("PreProcessing")),
        ('COMPILATION',   _("Compilation")),
        ('TESTRUN',       _("Test Run")),
    )

    REPORTFORMATS = (
        ('2', _("Peach2 legacy")),
        ('t', _("Plain text")),
        ('h', _("HTML")),
        ('r', _("rST")),
    )

    checkresult = models.ForeignKey(CheckResult)
    stage = models.CharField(max_length=16, choices=STAGES, blank=True)
    step = models.PositiveSmallIntegerField()
    level = models.PositiveSmallIntegerField()

    passed = models.BooleanField()

    reason = models.CharField(max_length=32, blank=True)

    report = models.TextField(blank=True)
    report_format = models.CharField(max_length=1, choices=REPORTFORMATS)
    score = models.IntegerField(null=True, blank=True)

    runtime = models.PositiveIntegerField(null=True, blank=True, help_text=_("Unit: miliseconds"))

    generatedfiles = models.ManyToManyField(FileRevision, null=True, blank=True, editable=False)

    objects = PPKManager()

    class Meta: #pylint: disable=W0232,C0111,R0903
        app_label = APP_LABEL
        ordering = 'checkresult', 'stage', 'step'
        index_together = [
            ('checkresult', 'stage', 'step'),
        ]

    def is_visible(self, user):
        return self.level <= (self.checkresult.submission.get_observelevel(user) or 0)

@dispatch.receiver([post_save, post_delete], sender=CheckResultStep)
def checkresultstep_updated(sender, instance, **kwargs): #pylint: disable=W0613,W0621
    instance.checkresult.submission.save(update_fields=['modified']) # Touch submission's last modified timestamp

class CheckResultStepIO(models.Model):
    STREAMS = (
        ('0', _("stdin")),
        ('1', _("stdout")),
        ('2', _("stderr")),
    )

    checkresultstep = models.ForeignKey(CheckResultStep)
    stream = models.CharField(max_length=1, choices=STREAMS)
    timestamp = models.PositiveIntegerField()
    order = models.PositiveIntegerField()
    data = models.TextField()

    class Meta: #pylint: disable=W0232,C0111,R0903
        app_label = APP_LABEL

