""" This file is part of PEACH.

    Copyright (C) 2006-2012 Eindhoven University of Technology
"""
from django import dispatch
from django.core.cache import cache
from django.core.exceptions import ObjectDoesNotExist
from django.db import models
from django.db.models.signals import post_delete, post_save
from django.utils.timezone import now
from django.utils.translation import ugettext_lazy as _

from peach3.managers.assignment import AssignmentEditionManager
from peach3.models import APP_LABEL
from peach3.models.course import CourseEdition
from peach3.models.files import FileType
from peach3.models.grade import GradingSystem
from peach3.models.i18n import I18NMixin, TranslatedName
from peach3.models.mixins import OrderMixin
from peach3.models.proglang import ProgrammingLanguage
from peach3.utils.cache import cache_key
from peach3.utils.dates import TimeRange
from peach3.utils.params import parse_parameters
from peach3.utils.ppk import PPKModelMixin, PPKManager

from mptt.models import MPTTModel, TreeForeignKey

# Create your models here.

__all__ = ('AssignmentSet', 'AssignmentEdition',
           'AssignmentEditionOption', 'AssignmentLayout',
           'AssignmentSlot',
          )

class AssignmentSet(models.Model, I18NMixin, OrderMixin, PPKModelMixin):
    courseedition = TreeForeignKey(CourseEdition)

    default_name = models.CharField(max_length=100, unique=False)
    default_language = models.CharField(max_length=16,
                                        choices=I18NMixin.LANGUAGE_CHOICES,
                                        default=I18NMixin.LANGUAGE_DEFAULT)

    order = models.PositiveIntegerField(null=True, blank=True)

    objects = PPKManager()

    class Meta: #pylint: disable=W0232,C0111,R0903
        app_label = APP_LABEL
        ordering = 'courseedition', 'order', 'default_name'

    def save(self, *arg, **kwargs):
        super(AssignmentSet, self).save(*arg, **kwargs)

        # If order is not set, set it to the primary key value
        # TODO: Use a signal handler for this
        if self.pk and self.order is None:
            self.order = self.pk
            super(AssignmentSet, self).save(update_fields=['order'])

    def clone(self, courseedition):
        # Return a clone of this set for a new courseedition

        if courseedition==self.courseedition:
            return self

        newset = AssignmentSet.objects.create(courseedition = courseedition,
                                              default_name = self.default_name,
                                              default_language = self.default_language)

        for translation in TranslatedName.objects.filter_by_object(self):
            TranslatedName.objects.create_for_object(newset,
                                                     language=translation.language,
                                                     name=translation.name)

        return newset

class AssignmentEdition(MPTTModel, I18NMixin, PPKModelMixin): # EditionMixin, OrderMixin pylint: disable=R0904
    ### Model definition
    slug = models.SlugField(max_length=32, db_index=True)

    parent = TreeForeignKey('self', null=True, blank=True, related_name='children')
    assignmentset = models.ForeignKey(AssignmentSet, blank=True, null=True)

    courseedition = TreeForeignKey(CourseEdition)

    created = models.DateTimeField(default=now)

    layout = models.ForeignKey('AssignmentLayout', blank=True, null=True)
    gradingsystems = models.ManyToManyField(GradingSystem, blank=True)
    languages = models.ManyToManyField(ProgrammingLanguage, blank=True)

    observelevel = models.PositiveSmallIntegerField(default=1,
                    help_text=_("Minimum observelevel required to observe submissions for this assignment"))
    reviewlevel = models.PositiveSmallIntegerField(default=1,
                    help_text=_("Minimum reviewlevel required to review submissions for this assignment"))
    reviewpublishlevel = models.PositiveSmallIntegerField(default=1,
                    help_text=_("Minimum reviewlevel required to publish a review for submissions for this assignment"))

    default_name = models.CharField(max_length=100, unique=False)
    default_language = models.CharField(max_length=16,
                                        choices=I18NMixin.LANGUAGE_CHOICES,
                                        default=I18NMixin.LANGUAGE_DEFAULT)

    order = models.PositiveIntegerField(null=True, blank=True)

    objects = AssignmentEditionManager()

    class Meta: #pylint: disable=W0232,C0111,R0903
        app_label = APP_LABEL
        get_latest_by = 'created'
        unique_together = ('courseedition','slug'),
        ordering = 'order', 'default_name'

    class MPTTMeta: #pylint: disable=W0232,C0111,R0903
        order_insertion_by = ['created']

    def submissions(self):
        # Return the number of submissions for this assignment
        return self.submission_set.count()

    # Timeranges
    def get_creation_timerange(self):
        if not hasattr(self, '_creation_timerange'):
            self._creation_timerange = TimeRange(begin=self.created) #pylint: disable=W0201
        return self._creation_timerange

    def _set_cluster_timerange(self, type, cluster, range): #@ReservedAssignment pylint: disable=W0622
        """ Set a timerange of `type` for the given `cluster`.

            `type` (`string`) is the range type (See `TimeRangeAbstractModel` for possible values),
            `cluster` (`Cluster`) is the cluster and `range` (`TimeRange`) is the range to set.
        """
        from peach3.models.timerange import ClusterTimeRange

        ClusterTimeRange.objects.set_timerange(assignmentedition=self, type=type, cluster=cluster, range=range)

    def _get_cluster_timerange(self, type, cluster): #@ReservedAssignment pylint: disable=W0622
        """ Get the timerange of given `type` for the given `cluster`. Returns a `TimeRange`.
            `cluster` can be '*' which returns the union of the timeranges for the clusters
            or a list (or QuerySet) of clusters
        """
        query = self.clustertimerange_set.filter(type=type)

        if cluster!='*':
            if isinstance(cluster, (list, tuple, models.query.QuerySet)):
                query = query.filter(cluster__in=cluster)

            else:
                query = query.filter(cluster=cluster)

        return query.get_timerange()

    def clone_timeranges(self, old_cluster, new_cluster):
        from peach3.models.timerange import TimeRangeAbstractModel

        for t in [TimeRangeAbstractModel.TYPE_OPEN, TimeRangeAbstractModel.TYPE_VISIBLE]:
            rng = self._get_cluster_timerange(t, old_cluster)
            self._set_cluster_timerange(t, new_cluster, rng)

    def _set_individual_timerange(self, type, user, range): #@ReservedAssignment pylint: disable=W0622
        """ Set a timerange of `type` for the given `user`.

            `type` (`string`) is the range type (See `TimeRangeAbstractModel` for possible values),
            `user` (`User`) is the user and `range` (`TimeRange`) is the range to set.
        """
        from peach3.models.timerange import IndividualTimeRange

        IndividualTimeRange.objects.set_timerange(assignmentedition=self, type=type, user=user, range=range)

    def _get_individual_timerange(self, type, user):
        """ Get the individual timerange of requested type for the provided user.
        :param user: The user to get the timerange for
        :return: A TimeRange object for this user, or None if there is no individual range of this type for the user
        """
        try:
            return self.individualtimerange_set.get(type=type, user=user).get_range()
        except self.individualtimerange_set.model.DoesNotExist:
            return None

    def _get_timerange(self, type, user=None, cluster=None): #@ReservedAssignment pylint: disable=W0622
        """ Get a timerange of `type` for given `user` or `cluster`.
            If `cluster` is given, it must be valid for the `user`.
            Returns the `TimeRange` for the `user`.
            If `cluster` is '*', returns the union of the timeranges for all clusters
        """
        if user:
            ce = self.courseedition
            if cluster or not self.can_observe(user):
                timerange = self._get_cluster_timerange(type, cluster or ce.get_user_cluster(user))
            else:
                timerange = self._get_cluster_timerange(type, ce.get_observable_clusters(user, self.observelevel))

            individual = self._get_individual_timerange(type, user)
            if individual is None:
                return timerange
            else:
                return timerange + individual

        elif cluster:
            return self._get_cluster_timerange(type, cluster)

        else:
            return TimeRange(closed=True)

    def set_cluster_open_timerange(self, cluster, range): #@ReservedAssignment pylint: disable=W0622
        from peach3.models.timerange import TimeRangeAbstractModel
        self._set_cluster_timerange(TimeRangeAbstractModel.TYPE_OPEN, cluster, range)

    def set_individual_open_timerange(self, user, range): #@ReservedAssignment pylint: disable=W0622
        from peach3.models.timerange import TimeRangeAbstractModel
        self._set_individual_timerange(TimeRangeAbstractModel.TYPE_OPEN, user, range)

    def set_individual_deadline(self, user, deadline):
        from peach3.models.timerange import TimeRangeAbstractModel
        user_range = TimeRange(begin=now(), end=deadline)
        self._set_individual_timerange(TimeRangeAbstractModel.TYPE_OPEN, user, user_range)
        self._set_individual_timerange(TimeRangeAbstractModel.TYPE_VISIBLE, user, user_range)

    def get_open_timerange(self, user=None, cluster=None):
        " Shortcut for `self.get_timerange(TimeRangeAbstractModel.TYPE_OPEN, user, cluster)` "
        from peach3.models.timerange import TimeRangeAbstractModel
        return self._get_timerange(TimeRangeAbstractModel.TYPE_OPEN, user=user, cluster=cluster)

    def get_individual_open_timerange(self, user):
        """ Get the individual 'open' timerange for the provided user.
        :param user: The user to get the timerange for
        :return: A TimeRange object for the 'open' range for this user, or None if there is no individual range
        for the user
        """
        from peach3.models.timerange import TimeRangeAbstractModel
        return self._get_individual_timerange(TimeRangeAbstractModel.TYPE_OPEN, user)

    def is_open(self, user=None, cluster=None, when=None):
        """ Returns True if assignment is open at given date (or current date if when=None)
        """
        cluster = cluster or self.courseedition.get_user_cluster(user)

        if when in self.get_open_timerange(user, cluster):
            return True
        elif user:
            # Assignment is also open if user's review level exceeds self.observelevel
            return (when in self.get_creation_timerange()
                    and (user.is_superuser
                         or self.courseedition.get_reviewlevel(user,'*') >= self.observelevel
                        ))

        return False

    def compare_open(self, user=None, cluster=None, when=None):
        """ Returns
              -1   if assignment opens in the future
               0   if assignment is currently open
               1   if assignment was open in the past and is now closed
              None if assignment never opens
        """
        rng = self.get_open_timerange(user, cluster)
        if rng.is_closed():
            return None
        return cmp(rng, when)

    def get_deadline(self, user=None, cluster=None):
        """ Get this assignment's deadline for given user or cluster.
            Returns True if the assignment is open without deadline,
            returns False if the assignment is closed without deadline,
            otherwise returns a datetime object with the deadline (possibly
            in the past)
        """
        rng = self.get_open_timerange(user, cluster)
        if rng.is_closed():
            return False
        return rng.end if rng.has_end() else True

    def set_cluster_visible_timerange(self, cluster, range): #@ReservedAssignment pylint: disable=W0622
        from peach3.models.timerange import TimeRangeAbstractModel
        self._set_cluster_timerange(TimeRangeAbstractModel.TYPE_VISIBLE, cluster, range)

    def set_individual_visible_timerange(self, user, range): #@ReservedAssignment pylint: disable=W0622,C0103
        from peach3.models.timerange import TimeRangeAbstractModel
        self._set_individual_timerange(TimeRangeAbstractModel.TYPE_VISIBLE, user, range)

    def get_visible_timerange(self, user=None, cluster=None):
        " Shortcut for `self.get_timerange(TimeRangeAbstractModel.TYPE_VISIBLE, user, cluster)` "
        from peach3.models.timerange import TimeRangeAbstractModel
        return self._get_timerange(TimeRangeAbstractModel.TYPE_VISIBLE, user, cluster)

    def get_individual_visible_timerange(self, user):
        """ Get the individual 'visible' timerange for the provided user.
        :param user: The user to get the timerange for
        :return: A TimeRange object for the 'visible' range for this user, or None if there is no individual range
        for the user
        """
        from peach3.models.timerange import TimeRangeAbstractModel
        return self._get_individual_timerange(TimeRangeAbstractModel.TYPE_VISIBLE, user)

    def can_observe(self, user):
        return self.courseedition.get_observelevel(user, '*') >= self.observelevel

    def is_visible(self, user=None, cluster=None, when=None):
        if not cluster:
            cluster = self.courseedition.get_user_cluster(user)

        if when in self.get_visible_timerange(user, cluster):
            return True
        elif user:
            # Assignment is also visible if user's observer level exceeds self.observelevel
            return when in self.get_creation_timerange() and self.can_observe(user)

        return False

    def valid_grade(self, grade):
        """ Validate a grade

        :param grade: grade to validate
        :return: returns True if grade is in one of the gradingsystems of this assignment
        """
        return grade.system.assignmentedition_set.filter(pk=self.pk).exists()

    # Options

    def _get_option(self, optioncode):
        key = cache_key('peach3.models.AssignmentEdition', self, 'option', optioncode)
        result = cache.get(key)
        if result is None:
            try:
                option = self.assignmenteditionoption_set.get(option=optioncode)
                result = True, parse_parameters(option.parameters)
            except self.assignmenteditionoption_set.model.DoesNotExist:
                result = False, {}

            cache.set(key, result)

        return result

    def has_option(self, optioncode):
        return self._get_option(optioncode)[0]

    def get_option(self, optioncode):
        return self._get_option(optioncode)[1]

    def set_option(self, optioncode, **kwargs):
        key = cache_key('peach3.models.AssignmentEdition', self, 'option', optioncode)
        cache.delete(key)

        parameters='\n'.join((key if value is True else '%s=%s' % (key, value)) for key, value in kwargs.iteritems())

        obj, created = AssignmentEditionOption.objects.get_or_create(assignmentedition=self,
                                                                     option=optioncode,
                                                                     defaults={'parameters':parameters})
        if not created:
            obj.parameters = parameters
            obj.save(update_fields=['parameters'])

    def delete_option(self, optioncode):
        key = cache_key('peach3.models.AssignmentEdition', self, 'option', optioncode)
        cache.delete(key)

        AssignmentEditionOption.objects.filter(assignmentedition=self,
                                               option=optioncode).delete()


    def has_option_parameter(self, optioncode, key):
        return key in self.get_option(optioncode)

    def get_option_parameter(self, optioncode, key, default=None):
        return self.get_option(optioncode).get(key, default)

    def set_option_parameter(self, optioncode, key, value):
        option = self.get_option(optioncode)
        option[key] = value
        self.set_option(optioncode, **option)

    def delete_option_parameter(self, optioncode, key):
        option = self.get_option(optioncode)
        del option[key]
        self.set_option(optioncode, **option)

    # Similar assignments

    def get_similar(self, include_self=False):
        """ Returns a queryset for assignments that are similar to this one
        """
        if self.is_root_node():
            include_root = include_self
            include_self = True # root is already filtered, so no need to filter it twice
        else:
            include_root = True

        q = self.get_root().get_descendants(include_self=include_root)

        if not include_self:
            q = q.exclude(pk=self.pk)

        return q

    def __unicode__(self):
        return self.name

#    ### Permission Interface
#    def _get_permissions(self, user):
#        return ( user.get_model_permissions(self)
#               | self.assignment.get_permissions(user)
#               | self.assignmentset.get_permissions(user) if self.assignmentset else frozenset()
#               )
#        return perms
#

    def has_access(self, user, access=None):
        return self.courseedition.has_access(user, access)

    ### Unique Identification Interface
    @classmethod
    def get_uid_fields(cls):
        return 'courseedition__period__slug', 'courseedition__code', 'slug',

    def get_uid(self):
        return self.courseedition.period.slug, self.courseedition.code, self.slug,

    def save(self, *arg, **kwargs):
        super(AssignmentEdition, self).save(*arg, **kwargs)

        # If order is not set, set it to the primary key value
        # TODO: Use a signal handler for this
        if self.pk and self.order is None:
            self.order = self.pk
            super(AssignmentEdition, self).save(update_fields=['order'])

class AssignmentEditionOption(models.Model):
    OPTIONS = (
        ('REVIEW', _("Review")),        # Parameters: -
        ('COAUTHORS', _("Co-Authors")), # Parameters: min, max
        ('scrub', _("Scrubbing")),      # Parameters: cutmark, required
    )

    assignmentedition = TreeForeignKey(AssignmentEdition)
    option = models.CharField(max_length=16, choices=OPTIONS)
    parameters = models.TextField(blank=True, help_text=_("'key' or 'key=value' pairs; one per line"))

    class Meta: #pylint: disable=W0232,C0111,R0903
        app_label = APP_LABEL
        db_table = APP_LABEL+'_asgnedoption'
        unique_together = ('assignmentedition', 'option')
        index_together = [
            ('assignmentedition', 'option'),
        ]

@dispatch.receiver([post_save, post_delete], sender=AssignmentEditionOption)
def assignmentedition_option_change(sender, instance, **kwargs): #pylint: disable=W0613
    # When reviewing options change, submission states might change,
    # so we must update all submission states for all submissions for
    # the assignmentedition
    if instance.option=='REVIEW':
        from peach3.models.submission import SubmissionAuthor
        try:
            SubmissionAuthor.objects.update_assignmentedition(instance.assignmentedition)
        except ObjectDoesNotExist:
            pass

class AssignmentLayout(models.Model):
    name = models.CharField(max_length=80, unique=True)

    def __unicode__(self):
        return self.name

    class Meta: #pylint: disable=W0232,C0111,R0903
        app_label = APP_LABEL

class AssignmentSlot(models.Model, I18NMixin):
    assignmentsubmlayout = models.ForeignKey(AssignmentLayout)

    default_name = models.CharField(max_length=100, unique=False)
    default_language = models.CharField(max_length=16,
                                        choices=I18NMixin.LANGUAGE_CHOICES,
                                        default=I18NMixin.LANGUAGE_DEFAULT)

    order = models.PositiveIntegerField()

    #validators = models.ManyToManyField(FileValidator, blank=True)
    allowedTypes = models.ManyToManyField(FileType, blank=True)
    namePattern = models.CharField(max_length=200, blank=True)

    required = models.BooleanField()

    ### Naming interface
    def __unicode__(self):
        return self.get_display_name()

    class Meta: #pylint: disable=W0232,C0111,R0903
        app_label = APP_LABEL

