""" This file is part of PEACH.

    Copyright (C) 2006-2009 Eindhoven University of Technology
"""
from django.conf import settings
from django.db import models

from peach3.models import APP_LABEL, CachedFileModel

from unipath import AbstractPath

from datetime import timedelta

__all__ = ('Report',)

class Report(CachedFileModel):
    type = models.CharField(max_length=12) #@ReservedAssignment
    parameters = models.TextField()
    mimetype = models.CharField(max_length=50)
    taskid = models.CharField(max_length=64, help_text="Celery task id", blank=True, default='')
    tasksuccess = models.NullBooleanField(help_text="True when the Celery task ended in success", default=None)

    users = models.ManyToManyField(settings.AUTH_USER_MODEL)

    class Meta: #pylint: disable=W0232,C0111,R0903
        app_label = APP_LABEL

    def get_hash(self):
        if not hasattr(self, '_hash'):
            from hashlib import md5
            h = md5(self.file.name+' '+self.parameters)
            self._hash = h.hexdigest()
        return self._hash
    hash = property(get_hash) #@ReservedAssignment

    @models.permalink
    def get_absolute_url(self):
        name = AbstractPath(self.file.name).name
        return ('peach3-core:report.download', [], {'rid':self.id, 'filename':name})
    absolute_url = property(get_absolute_url)

    def get_download_html(self):
        from django.template.loader import render_to_string
        return render_to_string('peach3/report/download_link.html', {'report':self})
    download_html = property(get_download_html)

    def __unicode__(self):
        s = u'Report %d' % self.pk
        if self.file.name:
            s += ': '+self.file.name
        return s

    def is_expired(self, when):
        return self.last_access < when-timedelta(weeks=4)
