""" This file is part of PEACH.

    Copyright (C) 2006-2012 Eindhoven University of Technology
"""
from django import dispatch
from django.db import models
from django.db.models.signals import pre_delete
from django.utils.timezone import now

from peach3.core.storage.secured import FileAccessDeniedError
from peach3.core.storage.submission import submissionstorage
from peach3.managers.files import FileValidatorManager, FileTypeManager, FileRevisionManager
from peach3.models import APP_LABEL
from peach3.models.i18n import I18NMixin
from peach3.utils.params import parse_parameters, parse_patterns, match_patterns
from peach3.utils.ppk import PPKModelMixin

import codecs

__all__ = ('FileValidator', 'FileType', 'FileRevision',)

def import_by_string(name):
    components = name.split('.')
    mod = __import__('.'.join(components[:-1]),
                     globals(),
                     locals(),
                     components[-1:])
    return getattr(mod, components[-1])

class FileValidator(models.Model):
    name = models.CharField(max_length=80)

    validator = models.CharField(max_length=80)
    parameters = models.TextField(blank=True)

    objects = FileValidatorManager()

    class Meta: #pylint: disable=W0232,C0111,R0903
        app_label = APP_LABEL

    def _get_validator_class(self):
        try:
            return import_by_string(self.validator)
        except ImportError:
            return None

    def validate(self, filepath, assignmentedition):
        if not hasattr(self, '_validator_instance'):
            vcls = self._get_validator_class()
            if vcls:
                param = parse_parameters(self.parameters)
                self._validator_instance = vcls(**param)
            else:
                self._validator_instance = None #pylint: disable=W0201

        if not self._validator_instance:
            return False, "Unable to load validator %r" % self.validator

        return self._validator_instance.validate(filepath, assignmentedition)

    def __unicode__(self):
        return self.name

class LEXER_CHOICES(object): #pylint: disable=C0103,R0903
    def __init__(self):
        try:
            from pygments.lexers import get_all_lexers
        except ImportError:
            self.lexers = []
        else:
            lexers = [(l[0], l[0]) for l in get_all_lexers()]
            lexers.sort(key=lambda x:x[1].lower())

            self.lexers = lexers

    def __iter__(self):
        return iter(self.lexers)

class FileType(models.Model, I18NMixin):
    ### Model definition
    lexer = models.CharField(max_length=80, choices=LEXER_CHOICES(), default='', blank=True)
    lexer_parameters = models.TextField(blank=True)

    binary_content = models.NullBooleanField()
    base_type = models.BooleanField()

    namepatterns = models.TextField(default='', blank=True)
    mimetypes = models.TextField(default='', blank=True)

    iconcls = models.CharField(max_length=30, blank=True)

    validators = models.ManyToManyField(FileValidator, blank=True)

    default_name = models.CharField(max_length=100, unique=True)
    default_language = models.CharField(max_length=16,
                                        choices=I18NMixin.LANGUAGE_CHOICES,
                                        default=I18NMixin.LANGUAGE_DEFAULT)

    objects = FileTypeManager()

    class Meta: #pylint: disable=W0232,C0111,R0903
        app_label = APP_LABEL

    ###
    def _parse_lexer_parameters(self):
        if not hasattr(self, '_parsed_lexer_parameters'):
            self._parsed_lexer_parameters = parse_parameters(self.lexer_parameters) #pylint: disable=W0201
        return self._parsed_lexer_parameters

    def get_lexer(self, **kwargs):
        if not hasattr(self,'_lexercls'):
            if self.lexer:
                from pygments.lexers import find_lexer_class
                lexercls = find_lexer_class(self.lexer)
            else:
                lexercls = None

            if lexercls is None and self.binary_content is not None and not self.binary_content:
                from pygments.lexers import TextLexer #@UnresolvedImport pylint: disable=E0611
                lexercls = TextLexer

            self._lexercls = lexercls #pylint: disable=W0201

        if self._lexercls:
            opt = self._parse_lexer_parameters()
            opt.update(kwargs)
            return self._lexercls(**opt)
        else:
            return None

    def _parse_namepatterns(self):
        if not hasattr(self, '_parsed_namepatterns'):
            self._parsed_namepatterns = parse_patterns(self.namepatterns) #pylint: disable=W0201
        return self._parsed_namepatterns

    def _parse_mimetypes(self):
        if not hasattr(self, '_parsed_mimetypes'):
            self._parsed_mimetypes = parse_patterns(self.mimetypes) #pylint: disable=W0201
        return self._parsed_mimetypes

    def get_default_mimetype(self):
        if not hasattr(self, '_default_mimetype'):
            m = self.mimetypes.split('\n', 1)[0] #pylint: disable=E1101
            if ';' in m:
                m = m.split(';', 1)[0]

            self._default_mimetype = m.strip() or None #pylint: disable=W0201

        return self._default_mimetype
    mimetype = property(get_default_mimetype)

    def match(self, fileobj, mimetype=None, charset=None):
        if self.binary_content is not None and charset is not None:
            if self.binary_content and charset!='':
                return None
            elif not self.binary_content and charset=='':
                return None

        if mimetype is None and charset is not None:
            if charset=='':
                mimetype = 'application/octet-stream'
            else:
                mimetype = 'text/plain'

        namepats = self._parse_namepatterns()
        mimepats = self._parse_mimetypes()

        if namepats or mimepats:
            if namepats and fileobj.name:
                namematch = match_patterns(namepats, fileobj.name, 0.8)
            else:
                namematch = 0.0

            if mimepats and mimetype:
                mimematch = match_patterns(mimepats, mimetype)*0.7
            else:
                mimematch = 0.0

            return max(namematch, mimematch)

        return None

    def validate(self, fileobj, assignmentedition):
        """ Check all defined validators for this type
        Returns a tuple (valid, errors) with valid a boolean indicating whether the file is valid
        and errors a list of errors found
        """

        errors = []
        for validator in self.validators.all():
            valid, error = validator.validate(fileobj, assignmentedition)
            if not valid:
                errors.append(error)

        return not errors, errors

class FileRevision(models.Model, PPKModelMixin):
    file = models.FileField(upload_to=submissionstorage.upload_path, #@ReservedAssignment
                            storage=submissionstorage,
                            max_length=submissionstorage.MAX_PATH_LENGTH, null=True)
    filetype = models.ForeignKey(FileType, blank=True, null=True)
    charset = models.CharField(max_length=32, blank=True)
    sha1 = models.CharField(max_length=40)
    created = models.DateTimeField(default=now)

    objects = FileRevisionManager()

    class Meta: #pylint: disable=W0232,C0111,R0903
        app_label = APP_LABEL
        get_latest_by = 'created'

    def _open_file_with_codec(self):
        try:
            return codecs.open(self.file.path, 'rb', self.charset or 'unicode_escape', 'replace') #pylint: disable=E1101
        except LookupError:
            return codecs.open(self.file.path, 'rb', 'unicode_escape', 'replace') #pylint: disable=E1101

    def get_unicode(self):
        " Get file contents converted to unicode "
        with self._open_file_with_codec() as f:
            return f.read()

    def get_unicode_lines(self):
        " Get file contents converted to unicode, as a list of lines "
        with self._open_file_with_codec() as f:
            return f.readlines()

    def has_access(self, user):
        for sbf in self.submissionfile_set.all():
            if sbf.has_access(user):
                return True

        return False

    def compare(self, other):
        """ Compare our file with the given file (a django.core.files.File object)
            Does not close the other file.
        """
        return submissionstorage.compare(self.file.name, other)

    ### Naming interface
    def __unicode__(self):
        return self.file.name

@dispatch.receiver(pre_delete, sender=FileRevision)
def filerevision_delete(sender, instance, **kwargs): #pylint: disable=W0613
    if instance.file:
        try:
            instance.file.delete(False)
        except FileAccessDeniedError:
            pass
