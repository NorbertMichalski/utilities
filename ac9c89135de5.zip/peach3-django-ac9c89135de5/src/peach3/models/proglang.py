# -*- coding: utf-8 -*-
""" This file is part of PEACH.

    Copyright (C) 2006-2012 Eindhoven University of Technology
    Copyright (C) 2009 Eljakim Information Technology bv.
"""

from django.db import models
from peach3.models.i18n import I18NMixin
from peach3.models import APP_LABEL

__all__ = ('ProgrammingLanguage',)

class ProgrammingLanguage(models.Model, I18NMixin):
    code = models.CharField(max_length=16, db_index=True, unique=True)

    default_name = models.CharField(max_length=100, unique=True)
    default_language = models.CharField(max_length=16,
                                        choices=I18NMixin.LANGUAGE_CHOICES,
                                        default=I18NMixin.LANGUAGE_DEFAULT)

    enabled = models.BooleanField(default=True)

    class Meta: #pylint: disable=W0232,C0111,R0903
        app_label = APP_LABEL
        db_table = APP_LABEL+'_proglang'
