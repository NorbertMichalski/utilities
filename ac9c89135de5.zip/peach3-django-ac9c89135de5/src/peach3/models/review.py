""" This file is part of PEACH.

    Copyright (C) 2006-2009 Eindhoven University of Technology
"""
from django import dispatch
from django.conf import settings
from django.contrib.auth import get_user_model
from django.contrib.contenttypes import generic
from django.db import models, transaction
from django.db.models.signals import pre_delete, post_delete, post_save, m2m_changed
from django.utils.timezone import now

from peach3.managers.review import ReviewManager
from peach3.models.forum import Comment
from peach3.models.grade import Grade
from peach3.models.news import NewsItem
from peach3.models.mixins import RevisionMixin
from peach3.models.submission import Submission, SubmissionAuthor
from peach3.models import APP_LABEL
from peach3.utils.permissions import get_current_user
from peach3.utils.ppk import PPKModelMixin

__all__ = ('Review',)

class Review(models.Model, RevisionMixin, PPKModelMixin):
    submission = models.ForeignKey(Submission)
    created = models.DateTimeField(default=now)
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, related_name='review_creator', default=get_current_user)

    reviewlevel = models.PositiveSmallIntegerField()
    visibilitylevel = models.PositiveSmallIntegerField()

    grade = models.ForeignKey(Grade, null=True, blank=True)

    authors = models.ManyToManyField(settings.AUTH_USER_MODEL, related_name='review_author')
    comments = generic.GenericRelation(Comment, object_id_field='parent_id',
                                                content_type_field='parent_content_type')

    objects = ReviewManager()

    class Meta: #pylint: disable=W0232,C0111,R0903
        app_label = APP_LABEL
        get_latest_by = 'created'
        ordering = 'created',

    @transaction.commit_on_success
    def send_reviewed_news(self):
        # Any older news about this submission is not current
        assert self.is_published()

        NewsItem.objects.filter_related(self.submission).update(current=False)

        # Message to the authors
        for user in self.authors.all():
            NewsItem.objects.create(
                courseedition = self.submission.courseedition,
                receipient = user,
                related = self.submission,
                appears = self.created,
                created_by = self.created_by,
                msgtype = 'reviewed',
            )

    def can_modify(self, user):
        return (
            self.created_by == user
            or self.submission.courseedition.is_manager(user)
            or self.reviewlevel < self.submission.get_reviewlevel(user)
        )

    def is_visible(self, user):
        if self.can_modify(user):
            return True

        if self.is_published():
            return self.submission.is_author(user) or self.submission.is_observer(user)
        else:
            return self.visibilitylevel <= (self.submission.get_observelevel(user) or 0)

    has_access = is_visible

    def is_published(self):
        return self.visibilitylevel == 0

    ### Ordering mixin interface
    @staticmethod
    def get_grouping_field_name():
        return 'submission'

@dispatch.receiver(post_save, sender=Review)
def review_post_save(sender, instance, **kwargs): #pylint: disable=W0613,W0621
    instance.submission.save(update_fields=['modified']) # Touch submission's last modified timestamp
    SubmissionAuthor.objects.update_submission(instance.submission,
                                               instance.authors.all())

@dispatch.receiver(pre_delete, sender=Review)
def review_pre_delete(sender, instance, **kwargs): #pylint: disable=W0613,W0621
    instance.submission.save(update_fields=['modified']) # Touch submission's last modified timestamp

@dispatch.receiver(post_delete, sender=Review)
def review_post_delete(sender, instance, **kwargs): #pylint: disable=W0613,W0621
    SubmissionAuthor.objects.update_submission(instance.submission,
                                               instance.authors.all())

@dispatch.receiver(m2m_changed, sender=Review.authors.through)
def review_authors_changed(sender, instance, action, reverse, pk_set, **kwargs): #pylint: disable=W0613
    if not reverse:
        users = None

        if action=='post_clear':
            users = instance.submission.authors.all()

        elif action in ['post_add', 'post_remove']:
            users = get_user_model().objects.filter(pk__in=pk_set)

        if users:
            SubmissionAuthor.objects.update_submission(instance.submission, users)
