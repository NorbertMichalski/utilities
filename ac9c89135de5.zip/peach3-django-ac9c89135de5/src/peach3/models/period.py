""" This file is part of PEACH.

    Copyright (C) 2006-2012 Eindhoven University of Technology
"""
from django.core.exceptions import ValidationError
from django.db import models
from django.utils.translation import ugettext as _

from peach3.managers.period import PeriodManager
from peach3.models import APP_LABEL
from peach3.models.i18n import I18NMixin
from peach3.utils.dates import TimeRange

from mptt.models import MPTTModel, TreeForeignKey

__all__ = ('Period',)

# Create your models here.

class Period(MPTTModel, I18NMixin):
    slug = models.CharField(max_length=8, unique=True)

    parent = TreeForeignKey('self', null=True, blank=True, related_name='children')

    _begin = models.DateTimeField("Begin", default=TimeRange.NEGINFDATE, db_column='begin', db_index=True)
    _end = models.DateTimeField("End", default=TimeRange.POSINFDATE, db_column='end', db_index=True)

    default_name = models.CharField(max_length=100, unique=False)
    default_language = models.CharField(max_length=16,
                                        choices=I18NMixin.LANGUAGE_CHOICES,
                                        default=I18NMixin.LANGUAGE_DEFAULT)

    objects = PeriodManager()

    class Meta: #pylint: disable=W0232,C0111,R0903
        app_label = APP_LABEL
        ordering = '_begin', '_end',
        unique_together = ('_begin', '_end'), # No identical periods allowed, as that would break the tree structure

    class MPTTMeta:
        order_insertion_by = '_begin', '_end'

    def clean(self):
        super(Period, self).clean()

        # No period with same range may exist
        if Period.objects.filter(_begin=self._begin, _end=self._end).exclude(pk=self.pk).count()>0:
            raise ValidationError(_("A period with the same range already exists"))

    def get_range(self):
        return TimeRange(begin=self._begin, end=self._end)

    def set_range(self, r):
        self._begin = r.begin
        self._end = r.end
    set_range.alters_data=True

    range = property(get_range, set_range) #@ReservedAssignment

    def available(self, date=None):
        return not self.range.is_after(date)

    def active(self, date=None):
        return self.range.in_range(date)

    def save(self, *arg, **kwarg):
        super(Period, self).save(*arg, **kwarg)

        # Force a rebuild of the tree structure
        Period.objects.rebuild()
