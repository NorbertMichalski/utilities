""" This file is part of PEACH.

    Copyright (C) 2006-2012 Eindhoven University of Technology
"""
from django.conf import settings
from django.contrib.contenttypes import generic
from django.contrib.contenttypes.models import ContentType
from django.db import models
from django.utils.timezone import now

from peach3.models import APP_LABEL
from peach3.models.forum import Comment
from peach3.models.i18n import I18NMixin
from peach3.utils.ppk import PPKModelMixin, PPKManager
from peach3.utils.permissions import get_current_user

# Create your models here.

__all__ = ('Flag', 'FlaggedObject',)

class Flag(models.Model, I18NMixin, PPKModelMixin):
    default_name = models.CharField(max_length=100, unique=True)
    default_language = models.CharField(max_length=16,
                                        choices=I18NMixin.LANGUAGE_CHOICES,
                                        default=I18NMixin.LANGUAGE_DEFAULT)

    objects = PPKManager()

    class Meta: #pylint: disable=W0232,C0111,R0903
        app_label = APP_LABEL


class FlaggedObject(models.Model, PPKModelMixin):
    """ A flag on an object

    Used to mark submissions or peer reviews as inappropriate.
    """
    parent_content_type = models.ForeignKey(ContentType)
    parent_id = models.PositiveIntegerField()
    parent = generic.GenericForeignKey('parent_content_type', 'parent_id')
    flag = models.ForeignKey(Flag)

    created = models.DateTimeField(default=now)
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL,
                                   default=get_current_user)

    comments = generic.GenericRelation(Comment,
                                       object_id_field='parent_id',
                                       content_type_field='parent_content_type')

    objects = PPKManager()

    class Meta: #pylint: disable=W0232,C0111,R0903
        app_label = APP_LABEL
        index_together = (
            ('parent_content_type', 'parent_id'),
        )

    def get_comment(self):
        try:
            return self.comments.latest().get_content().get_formatted()
        except Comment.DoesNotExist:
            return None

    get_comment.apply_tags = True
