""" This file is part of PEACH.

    Copyright (C) 2006-2012 Eindhoven University of Technology
"""
from django.conf import settings
from django.db import models
from django.utils.translation import ugettext_lazy as _

from peach3.models import APP_LABEL
from peach3.models.assignment import AssignmentEdition
from peach3.models.cluster import Cluster

from peach3.managers.timerange import TimeRangeAbstractManager

from peach3.utils.dates import TimeRange

from mptt.models import TreeForeignKey

__all__ = ('ClusterTimeRange', 'IndividualTimeRange',)

class TimeRangeAbstractModel(models.Model):
    TYPE_OPEN = 'o'
    TYPE_VISIBLE = 'v'

    TYPE_CHOICES = ((TYPE_OPEN, _('Open'),),
                    (TYPE_VISIBLE, _('Visible'),),
                   )

    assignmentedition = TreeForeignKey(AssignmentEdition)
    type = models.CharField(max_length=1, choices = TYPE_CHOICES) #@ReservedAssignment

    _begin = models.DateTimeField(null=True, blank=True, db_column='state_from')
    _end = models.DateTimeField(null=True, blank=True, db_column='state_until')

    objects = TimeRangeAbstractManager()

    class Meta: #pylint: disable=W0232,C0111,R0903
        abstract = True

    def get_range(self):
        return TimeRange(begin=self._begin, end=self._end)

    def set_range(self, r):
        self._begin = r.begin if r.has_begin() else None
        self._end = r.end if r.has_end() else None
    set_range.alters_data=True

    range = property(get_range, set_range) #@ReservedAssignment


class ClusterTimeRange(TimeRangeAbstractModel):
    cluster = models.ForeignKey(Cluster)

    class Meta(TimeRangeAbstractModel.Meta): #pylint: disable=W0232,C0111,R0903
        app_label = APP_LABEL
        unique_together = ('cluster', 'assignmentedition', 'type')
        index_together = [
            ('cluster', 'assignmentedition', 'type'),
        ]

    ### Naming interface
    def __unicode__(self):
        return u'%s:%s:%s' % (self.assignmentedition, self.cluster, self.get_type_display()) #pylint: disable=E1101

class IndividualTimeRange(TimeRangeAbstractModel):
    user = models.ForeignKey(settings.AUTH_USER_MODEL)

    class Meta(TimeRangeAbstractModel.Meta): #pylint: disable=W0232,C0111,R0903
        app_label = APP_LABEL
        unique_together = ('user', 'assignmentedition', 'type')
        index_together = [
            ('user', 'assignmentedition', 'type')
        ]

    ### Naming interface
    def __unicode__(self):
        return u'%s:%s:%s' % (self.assignmentedition, self.user, self.get_type_display()) #pylint: disable=E1101
