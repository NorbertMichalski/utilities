# -*- coding: utf-8 -*-
""" This file is part of PEACH.

    Copyright (C) 2006-2009 Eindhoven University of Technology
"""
from django.conf import settings
from django.contrib.auth.models import AbstractUser
from django.db import models
from django.db.models.signals import post_save
from django.dispatch import receiver
from django.utils.encoding import smart_str
from django.utils.translation import ugettext_lazy as _

from peach3.core.modelurl import get_model_absolute_url
from peach3.core.user import AlternativeNames
from peach3.core.verification import VERIFY_CHOICES
from peach3.managers.auth import UserManager
from peach3.models import APP_LABEL
from peach3.models.proglang import ProgrammingLanguage
from peach3.utils.decorators import skip_raw_save
from peach3.utils.ppk import PPKModelMixin

import pytz

__all__ = ('User', 'UserPreference', 'VerificationCode')

# Create your models here.

SECRET_LENGTH = 16

def generate_secret():
    from Crypto import Random

    s, f = '', Random.new()
    while len(s) < SECRET_LENGTH:
        v = f.read(SECRET_LENGTH - len(s))
        for c in v:
            if 32 <= ord(c) < 128:
                s += c

    return s

class User(AbstractUser, PPKModelMixin):
    STATE_VERIFIED = 'V'
    STATE_UNVERIFIED = 'U'
    STATE_BLOCKED = 'X'

    STATE_CHOICES = (
      (STATE_UNVERIFIED, _("Unverified")),
      (STATE_VERIFIED, _("Verified")),
      (STATE_BLOCKED, _("Blocked")),
    )

    # Additional name fields
    initials = models.CharField(max_length=30, blank=True)
    titles_prefix = models.CharField(max_length=30, blank=True)
    last_name_prefix = models.CharField(max_length=30, blank=True)
    last_name_suffix = models.CharField(max_length=30, blank=True)
    titles_suffix = models.CharField(max_length=30, blank=True)

    # Registration state
    state = models.CharField(max_length=1, choices=STATE_CHOICES, default=STATE_VERIFIED)

    # Secret key
    _secret = models.CharField(max_length=SECRET_LENGTH, blank=True, db_column='secret')

    objects = UserManager()

    class Meta: #pylint: disable=W0232,C0111,R0903
        app_label = APP_LABEL

    def format_initials(self):
        i = self.initials
        if i == '' or '.' in i:
            return i
        else:
            return '.'.join(list(i)) + '.'

    def get_full_name_sortable(self):
        name = self.last_name
        if self.last_name_suffix:
            name += u' ' + self.last_name_suffix
        if self.initials or self.first_name or self.last_name_prefix:
            name += u','
            if self.first_name and not self.initials:
                name += u' ' + self.first_name
            elif self.initials and not self.first_name:
                name += u' ' + self.format_initials()
            else:
                name += u' %s [%s]' % (self.first_name, self.format_initials())
            if self.last_name_prefix:
                name += u' ' + self.last_name_prefix

        return name

    def get_full_name_formal(self):
        name = self.last_name
        if self.last_name_suffix:
            name += u' ' + self.last_name_suffix
        if self.initials or self.last_name_prefix:
            name += u','
            if self.initials:
                name += u' ' + self.format_initials()
            if self.last_name_prefix:
                name += u' ' + self.last_name_prefix

        return name

    def get_full_name(self):
        name = self.last_name
        if self.last_name_suffix:
            name += u' ' + self.last_name_suffix
        if self.last_name_prefix:
            name = self.last_name_prefix + u' ' + name
        if self.first_name or self.initials:
            if self.first_name:
                name = self.first_name + u' ' + name
            else:
                name = self.format_initials() + u' ' + name
        return name

    def get_short_name(self):
        return self.first_name or self.last_name

    def get_alternative_names(self, fetch=True):
        return AlternativeNames().get_alternative_names(self.username, fetch)

    @property
    def secret(self):
        " Gets the user's secret. Creates a new secret if it does not exist "
        if not self._secret:
            self._secret = generate_secret()
            self.save(update_fields=['_secret'])

        return self._secret


class UserPreference(models.Model):
    DATE_CHOICES = (
        ('D j M Y',) * 2,  # Wed 9 Jan 2007
        ('j M Y',) * 2,    # 9 Jan 2007
        ('D M j Y',) * 2,  # Wed Jan 9 2007
        ('M j Y',) * 2,    # Jan 9 2007
        ('D j-m-Y',) * 2,  # Wed 9-01-2007
        ('j-m-Y',) * 2,    # 9-01-2007
        ('D n.j.Y',) * 2,  # Wed 1.9.2007
        ('n.j.Y',) * 2,    # 1.9.2007
        ('D Y/m/d',) * 2,  # Wed 2007/01/09
        ('Y/m/d',) * 2,    # 2007/01/09
    )

    # Mapping from long dates (above) to short dates (without month and day names)
    SHORT_DATES = {
        'D j M Y': 'j-m-Y',
        'j M Y': 'j-m-Y',
        'D M j Y': 'n.j.Y',
        'M j Y': 'n.j.Y',
        'D j-m-Y': 'j-m-Y',
        'j-m-Y': 'j-m-Y',
        'D n.j.Y': 'n.j.Y',
        'n.j.Y': 'n.j.Y',
        'D Y/m/d': 'Y/m/d',
        'Y/m/d': 'Y/m/d',
    }

    TIME_CHOICES = (
        ('G:i',) * 2,      # 15:05
        ('g:i a',) * 2,    # 3:05 pm
    )

    TIMEZONE_CHOICES = zip(pytz.common_timezones, pytz.common_timezones)

    user = models.OneToOneField(settings.AUTH_USER_MODEL, primary_key=True, related_name='preference')
    timezone_str = models.CharField(max_length=48, choices=TIMEZONE_CHOICES, default=settings.TIME_ZONE)
    date_format = models.CharField(max_length=16, choices=DATE_CHOICES, default=DATE_CHOICES[0][0])
    time_format = models.CharField(max_length=8, choices=TIME_CHOICES, default=TIME_CHOICES[0][0])
    language = models.CharField(max_length=16,
                                choices=(('',_("Browser default"),),)+settings.LANGUAGES,
                                default='', blank=True)
    programmingLanguage = models.ForeignKey(ProgrammingLanguage, blank=True, null=True)

    class Meta: #pylint: disable=W0232,C0111,R0903
        app_label = APP_LABEL

    def get_timezone(self):
        if not hasattr(self, '_tz'):
            try:
                self._tz = pytz.timezone(smart_str(self.timezone_str))
            except pytz.UnknownTimeZoneError:
                self._tz = pytz.timezone(settings.TIME_ZONE)
        return self._tz

    def set_timezone(self, tz):
        self._tz = tz #pylint: disable=W0201
        self.timezone_str = str(tz)

    timezone = property(get_timezone, set_timezone)

    def get_short_date_format(self):
        return self.SHORT_DATES.get(self.date_format, self.date_format)
    short_date_format = property(get_short_date_format)

    def get_datetime_format(self):
        return self.date_format+' '+self.time_format
    datetime_format = property(get_datetime_format)

    def get_short_datetime_format(self):
        return self.get_short_date_format()+' '+self.time_format
    short_datetime_format = property(get_short_datetime_format)


@receiver(post_save, sender=User)
@skip_raw_save
def user_saved(sender, instance, created, **kwargs):
    " Ensure each User object has an associated UserPreference object "
    if created:
        UserPreference.objects.get_or_create(user=instance)


class VerificationCode(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL)
    type = models.CharField(max_length=1, choices=VERIFY_CHOICES) #@ReservedAssignment
    code = models.CharField(max_length=8)
    created = models.DateTimeField(auto_now_add=True)
    expires = models.DateTimeField(blank=True, null=True)
    parameters = models.TextField(blank=True)

    class Meta: #pylint: disable=W0232,C0111,R0903
        app_label = APP_LABEL

    def get_challenge(self):
        from hashlib import md5

        h = md5()
        for value in [settings.SECRET_KEY, self.user.username, self.type, self.code, self.parameters]:
            h.update(value) #pylint: disable=E1101

        return h.hexdigest()

    get_absolute_url = get_model_absolute_url
