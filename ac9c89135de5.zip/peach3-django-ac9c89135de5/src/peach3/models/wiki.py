""" This file is part of PEACH.

    Copyright (C) 2006-2012 Eindhoven University of Technology
"""
from django import dispatch
from django.conf import settings
from django.contrib.contenttypes import generic
from django.contrib.contenttypes.models import ContentType
from django.core.cache import cache
from django.db import models
from django.db.models.signals import pre_delete, post_save
from django.utils.encoding import smart_str
from django.utils.timezone import now
from django.utils.translation import ugettext as _, ugettext_lazy, get_language

from peach3.core.modelurl import get_model_absolute_url
from peach3.managers.wiki import PageManager, PageRevisionTextManager, PageRevisionManager
from peach3.models import APP_LABEL
from peach3.models.mixins import RevisionMixin
from peach3.utils.cache import cache_key
from peach3.utils.decorators import skip_raw_save
from peach3.utils.permissions import get_current_user
from peach3.utils.rst import rst2html
from peach3.utils.wiki import decode_full_path, user_can_create_page, construct_full_path
from peach3.utils.ppk import PPKModelMixin

from datetime import timedelta
import itertools

__all__ = ('Page', 'PagePermission', 'PageRevisionText', 'PageRevision',)

icolumn = lambda s, i : itertools.imap(lambda l:l[i], s)  #pylint: disable=C0103

class Page(models.Model, PPKModelMixin):
    # The ordering here is important! Order from most open to most restricted
    PAGE_ACCESS_ANONYMOUS = 1
    PAGE_ACCESS_AUTHENTICATED = 2
    PAGE_ACCESS_PARENT_ACCESS = 3
    PAGE_ACCESS_EXPLICIT = 5

    # Keep this in sync with client-side code in peach3-ui-extjs2: static/js/peach3.js
    PAGE_ACCESS = (
        (PAGE_ACCESS_ANONYMOUS, ugettext_lazy(u"Everyone, including anonymous users")),
        (PAGE_ACCESS_AUTHENTICATED, ugettext_lazy(u"All authenticated users")),
        (PAGE_ACCESS_PARENT_ACCESS, ugettext_lazy(u"Users with access to the parent object")),
        (PAGE_ACCESS_EXPLICIT, ugettext_lazy(u"Nobody, except explicitly allowed")),
    )

    ### Model definition
    parent_type = models.ForeignKey(ContentType, blank=True, null=True)
    parent_id = models.PositiveIntegerField(blank=True, null=True)
    parent = generic.GenericForeignKey('parent_type', 'parent_id')

    path = models.CharField(max_length=200, blank=True)

    created = models.DateTimeField(default=now)
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, default=get_current_user)

    allow_comments = models.BooleanField(default=False)

    access = models.PositiveSmallIntegerField(choices=PAGE_ACCESS,
                                              default=PAGE_ACCESS_AUTHENTICATED)
    parent_access = models.CharField(max_length=16, blank=True)

    permission = models.ManyToManyField(settings.AUTH_USER_MODEL, through='PagePermission',
                                        related_name='page_permission')

    default_language = models.CharField(max_length=16,
                                        choices=settings.LANGUAGES,
                                        default=settings.LANGUAGE_CODE)

    class Meta: #pylint: disable=W0232,C0111,R0903
        app_label = APP_LABEL
        get_latest_by = 'created'
        unique_together = ('parent_type', 'parent_id', 'path')
        index_together = [
            ('parent_type', 'parent_id', 'path'),
        ]
#        permissions = (
#            ('view_page', "Can view page"),
#            ('revert_page', "Can revert changes"),
#            ('moderate_page', "Can moderate page"),
#            ('manage_page', "Can manage page"),
#        )

    objects = PageManager()

    ### Model methods
    def get_latest(self, language=None, fallback=True, dontcache=False):
        """ Get latest revision for selected language, optionally falling back to
        the default language. The 'dontcache' parameter is not used anymore
        """
        if language is None:
            language = get_language()

        try:
            revision = self.pagerevision_set.filter(language=language)\
                                            .select_related('text')\
                                            .latest()
        except self.pagerevision_set.model.DoesNotExist:
            revision = None

        if revision is None or not revision.is_active:
            if fallback and language!=self.default_language:
                return self.get_latest(self.default_language, False, dontcache)
            else:
                raise self.pagerevision_set.model.DoesNotExist

        return revision

    latest = property(get_latest)

    def get_title(self, language=None):
        if language is None:
            language = get_language()

        key = cache_key('peach3.models.Page.title', self, language)
        title = cache.get(key)
        if not title:
            try:
                title = rst2html(self.get_latest(language).text.content, self.full_path)['title']
                cache.set(key, title)

            except:
                title = self.full_path

        return title
    title = property(get_title)

    def get_languages(self):
        key = cache_key('peach3.models.Page.languages', self)

        languages = cache.get(key)
        if languages is None:
            languages = [smart_str(self.default_language)]

            # Get a list of all languages defined
            candidates = self.pagerevision_set.exclude(language=self.default_language)\
                                              .distinct().values_list('language', flat=True)

            # Check for deactivated languages
            for lang in sorted(candidates):
                try:
                    self.get_latest(lang, False)
                except self.pagerevision_set.model.DoesNotExist:
                    continue
                else:
                    languages.append(smart_str(lang))

            cache.set(key, languages)

        return languages
    languages = property(get_languages)

    def get_revision(self, rev, language=None):
        """ Get a specific revision for the chosen language
        """
        if language is None:
            language = get_language()

        key = cache_key('peach3.models.Page.get_revision', self, rev, language)
        pk = cache.get(key)
        if pk is None:
            revision = self.pagerevision_set.filter(language=language).select_related('text').order_by('created')[rev]
            pk = revision.pk
            cache.set(key, pk)
        else:
            revision = PageRevision.objects.get(pk=pk)

        return revision

    def revision_count(self, language=None):
        """ Get the number of revisions for the chosen language
        """
        if language is None:
            language = get_language()

        key = cache_key('peach3.models.Page.revision_count', self, language)
        count = cache.get(key)
        if count is None:
            count = self.pagerevision_set.filter(language=language).count()
            cache.set(count, key)

        return count

    def deactivate(self, user, language=None):
        """ Deactivate selected language (by creating a new empty revision)
            If language is None, deactivates the entire page
        """
        if not self.is_editor(user):
            return False

        active_languages = self.languages

        if not language:
            languages = active_languages
            changes = _("Page deactivated")

        elif language in active_languages:
            languages = [language]
            changes = _("Translation deactivated")

        else:
            # language doesn't exist or is already deactivated, so no need to deactivate it
            return True

        # Update cached languages
        key = cache_key('peach3.models.Page.languages', self)
        cached_languages = cache.get(key)
        if cached_languages:
            for language in languages:
                cached_languages.remove(language)
            cache.set(key, cached_languages)

        # Add revisions with text=None
        PageRevision.objects.bulk_create(PageRevision(
            page=self,
            created_by=user,
            language=language,
            text=None,
            changes=changes
        ) for language in languages)

        for language in languages:
            # Delete cached title
            key = cache_key('peach3.models.Page.title', self, language)
            cache.delete(key)

            # Increment cached revision count
            key = cache_key('peach3.models.Page.revision_count', self, language)
            try:
                cache.incr(key)
            except ValueError:
                cache.set(key, 1)

        return True

    def new_revision(self, user, language, markup, content, changes, force_new=False):
        assert user
        assert language
        assert markup

        if not self.is_editor(user):
            # Change page permission is required for any changes
            return False

        try:
            last_revision = self.get_latest(language, dontcache=True)
        except PageRevision.DoesNotExist:
            last_revision = None

        # Update cached languages
        key = cache_key('peach3.models.Page.languages', self)
        languages = cache.get(key)
        if languages:
            languages.append(language)
            cache.set(key, languages)

        if not force_new and last_revision and \
           last_revision.created_by==user and last_revision.language==language and \
           ((last_revision.text.content==content and last_revision.text.markup==markup) \
             or now()-last_revision.created<timedelta(minutes=15)):

            # Same user edited this object less than 15 minutes ago, or didn't change the content
            last_revision.changes = changes
            last_revision.update_content(markup, content)
            last_revision.created = now()
            last_revision.save()

        else:
            PageRevision.objects.create(page=self,
                                        created_by=user,
                                        language=language,
                                        markup=markup,
                                        content=content,
                                        changes=changes)

            # Increment cached revision count
            key = cache_key('peach3.models.Page.revision_count', self, language)
            try:
                cache.incr(key)
            except ValueError:
                cache.set(key, 1)

        return True

    def set_default_language(self, language):
        self.default_language = language

        key = cache_key('peach3.models.Page.languages', self)
        cache.delete(key)


#    def get_comments(self):
#        key = cache_key('peach3.models.Page.comments', self)
#        comments = cache.get(key)
#        if comments is None:
#            comments = PageComments.objects.filter(revision__page=self)
#            cache.set(key, comments)
#        return comments
#    comments = property(get_comments)

    def get_model(self):
        if self.parent_type is None:
            return None

        model = getattr(self, '_model', None)
        if not model:
            model = models.loading \
                          .get_model(app_label = self.parent_type.app_label,
                                     model_name = self.parent_type.model)
            self._model = model #pylint: disable=W0201

        return model
    model = property(get_model)

    @staticmethod
    def user_can_add(user, full_path):
        try:
            parent, path = decode_full_path(full_path)
        except Page.DoesNotExist:
            return False

        return user_can_create_page(user, parent, path)

    def get_up(self):
        """ Get page one level up """
        pathparts = self.path.split('/') #pylint: disable=E1101

        if self.parent:
            args = {'parent':self.parent}
        else:
            args = {'parent__isnull':True}

        while len(pathparts)>0:
            pathparts.pop()
            path = '/'.join(pathparts)
            try:
                uppage = Page.objects.get(path=path, **args)
                if uppage!=self:
                    return uppage

            except Page.DoesNotExist:
                pass

        return None
    up = property(get_up)

    def get_down(self):
        """ Get all pages below this one """
        if self.parent:
            args = {'parent':self.parent}
        else:
            args = {'parent__isnull':True}
        return Page.objects.filter(path__startswith=self.path+'/', **args).all()
    down = property(get_down)

    def get_permission(self, user, permission):
        if user.is_anonymous():
            return False
        elif user.is_superuser or user==self.created_by:
            return True

        try:
            pp = PagePermission.objects.get(page=self, user=user)
            return pp.permission >= permission
        except PagePermission.DoesNotExist:
            return self.up and self.up.get_permission(user, permission) or False

    def set_permission(self, user, permission):
        if user!=self.created_by:
            if permission is not None:
                PagePermission.objects.get_or_create(page=self,
                                                     user=user,
                                                     permission=permission)
            else:
                PagePermission.objects.filter(page=self,
                                              user=user,
                                              permission=permission).delete()

    def get_permissions(self):
        yield self.created_by, PagePermission.PAGE_PERMISSION_OWNER
        for pp in PagePermission.objects.filter(page=self):
            yield pp.user, pp.permission

    def is_editor(self, user=None):
        if user is None:
            user = get_current_user()

        return user.is_superuser \
                    or user==self.created_by \
                    or self.get_permission(user, PagePermission.PAGE_PERMISSION_EDITOR)

    ### Naming interface
    def __unicode__(self):
        return self.full_path

    ### URL access
    def get_full_path(self):
        return construct_full_path(self.parent, self.path)
    full_path = property(get_full_path)

    get_absolute_url = get_model_absolute_url

#    ### Permissions interface
#    def _get_permissions(self, user):
#        perms = user.get_model_permissions(self)
#
#        up = self.up
#        if up:
#            return perms | up.get_permissions(user)
#
#        parent = self.parent
#        if parent:
#            if hasattr(parent, 'get_permissions'):
#                return perms | parent.get_permissions(user)
#            else:
#                return perms | user.get_permissions(parent)
#
#        return perms
#
    def has_access(self, user):
        if self.is_editor(user):
            return True

        if user.is_anonymous():
            if self.access >= Page.PAGE_ACCESS_AUTHENTICATED:
                return False

        else:
            if self.access >= Page.PAGE_ACCESS_EXPLICIT:
                return user==self.created_by or self.pagepermission_set.filter(user=user).count()>0

            parent = self.parent
            if self.access >= Page.PAGE_ACCESS_PARENT_ACCESS:
                return parent \
                   and hasattr(parent, 'has_access') \
                   and parent.has_access(user, self.parent_access or None)

        return True

class PagePermission(models.Model):
    PAGE_PERMISSION_READ = 0
    PAGE_PERMISSION_EDITOR = 1
    PAGE_PERMISSION_OWNER = 99
    PAGE_PERMISSION = (
        (PAGE_PERMISSION_READ,   ugettext_lazy(u"Read")),
        (PAGE_PERMISSION_EDITOR, ugettext_lazy(u"Editor")),
        (PAGE_PERMISSION_OWNER,  ugettext_lazy(u"Owner")),
    )

    page = models.ForeignKey(Page)
    user = models.ForeignKey(settings.AUTH_USER_MODEL)
    permission = models.PositiveSmallIntegerField(choices=PAGE_PERMISSION)

    class Meta: #pylint: disable=W0232,C0111,R0903
        app_label = APP_LABEL

class PageRevisionText(models.Model):
    MARKUP_CHOICES = (
      ('plain', ugettext_lazy("Plain text")),
      ('rst'  , ugettext_lazy("Restructured text")),
    )

    ### Model definition
    markup = models.CharField(max_length=8, choices=MARKUP_CHOICES, default=MARKUP_CHOICES[1][0])

    # diff_base indicates which revision to use as base for the diff.
    # If it is NULL, the content is not diffed.
    # TODO: Diffing is currently not implemented, so diff_base is always NULL for now
    diff_base = models.ForeignKey('self', null=True, blank=True)
    content_or_diff = models.TextField()

    objects = PageRevisionTextManager()

    class Meta: #pylint: disable=W0232,C0111,R0903
        app_label = APP_LABEL

    ### Model methods
    def get_content(self):
        """ Returns the content of this revision
            Applies the diff if needed
        """
        return self.content_or_diff
    content = property(get_content)

    def update(self, markup, content):
        self.markup = markup
        self.diff_base = None
        self.content_or_diff = content
        self.save()
    update.alters_data=True

class PageRevision(models.Model, RevisionMixin):
    ### Model definition
    page = models.ForeignKey(Page)

    created = models.DateTimeField(default=now)
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, default=get_current_user)

    changes = models.TextField(blank=True)
    language = models.CharField(max_length=16,
                                choices=settings.LANGUAGES,
                                default=settings.LANGUAGE_CODE)
    text = models.ForeignKey(PageRevisionText, blank=True, null=True) # None for a deactivated language

    objects = PageRevisionManager()

    class Meta: #pylint: disable=W0232,C0111,R0903
        app_label = APP_LABEL
        get_latest_by = 'created'

    ### Model methods
    def update_content(self, markup, content):
        if self.text.pagerevision_set.count()==1:
            if self.text.markup!=markup or self.text.content!=content:
                self.text.update(markup, content)
        else:
            self.text = PageRevisionText.objects.get_or_create(markup=markup, content=content)[0]
            self.save(update_fields=['text'])
    update_content.alters_data=True

    @property
    def is_active(self):
        return self.text is not None

    ### Ordering mixin interface
    @staticmethod
    def get_grouping_field_name():
        return 'page', 'language'

    ### Naming interface
    def __unicode__(self):
        return u'%s (%s) [%d]' % (self.page, self.language, self.revision)

#class PageComment(models.Model, MarkupMixin):
#    ### Model definition
#    revisiontext = models.ForeignKey(PageRevisionText)
#
#    created = models.DateTimeField()
#    created_by = models.ForeignKey(settings.AUTH_USER_MODEL)
#
#    reply_on = models.ForeignKey("self", null=True, blank=True,
#                                 related_name="replies_set")
#
#    content = models.TextField()
#
#    class Meta: #pylint: disable=W0232,C0111,R0903
#        app_label = APP_LABEL

@dispatch.receiver(pre_delete, sender=PageRevision)
def pagerevision_pre_delete(sender, instance, **kwargs): #pylint: disable=W0613
    " Update cache when an object is deleted (should only occur from admin site) "

    # Delete cached languages
    key = cache_key('peach3.models.Page.languages', instance.page)
    cache.delete(key)

    # Delete cached title
    key = cache_key('peach3.models.Page.title', instance.page, instance.language)
    cache.delete(key)

    # Decrement cached revision count
    key = cache_key('peach3.models.Page.revision_count', instance.page, instance.language)
    try:
        cache.decr(key)
    except ValueError:
        pass

@dispatch.receiver([post_save, pre_delete], sender=PageRevisionText)
@skip_raw_save
def pagerevisiontext_update(sender, instance, **kwargs): #pylint: disable=W0613
    # Delete cached titles
    for revision in instance.pagerevision_set.all():
        key = cache_key('peach3.models.Page.title', revision.page, revision.language)
        cache.delete(key)
