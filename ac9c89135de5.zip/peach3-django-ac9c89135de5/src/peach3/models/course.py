""" This file is part of PEACH.

    Copyright (C) 2006-2012 Eindhoven University of Technology
"""
from django.conf import settings
from django.core.cache import cache
from django.contrib.auth import get_user_model
from django.contrib.auth.models import Group
from django.db import models, transaction
from django.db.models import Q
from django.db.models.signals import m2m_changed, post_save, pre_delete
from django.dispatch import receiver

from django.utils.timezone import now
from django.utils.translation import ugettext_lazy

from peach3.core.modelurl import get_model_absolute_url
from peach3.models import APP_LABEL
from peach3.models.cluster import Cluster, ClusterStaff, ClusterMember
from peach3.models.i18n import I18NMixin
from peach3.models.period import Period
from peach3.models.realm import Realm
from peach3.utils.decorators import skip_raw_save
from peach3.utils.permissions import get_current_user

from peach3.utils.cache import cache_key, unique_cache_hash

from mptt.models import MPTTModel, TreeForeignKey

import random

__all__ = ('CourseEdition','SubCode')

# Create your models here.

class CourseEdition(MPTTModel, I18NMixin): #, EditionMixin pylint: disable=R0904
    CLUSTER_SELECTION_AUTO = 'A'
    CLUSTER_SELECTION_MANUAL = 'M'

    CLUSTER_SELECTION_CHOICES = (
        (CLUSTER_SELECTION_AUTO,   ugettext_lazy("Automatic")),
        (CLUSTER_SELECTION_MANUAL, ugettext_lazy("Manual")),
    )

    ### Model definition
    code = models.SlugField(max_length=16)

    parent = TreeForeignKey('self', null=True, blank=True, related_name='children')
    period = TreeForeignKey(Period)

    created = models.DateTimeField(default=now)
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, default=get_current_user)

    cluster_selection = models.CharField(max_length=1,
                                         choices=CLUSTER_SELECTION_CHOICES,
                                         default=CLUSTER_SELECTION_MANUAL)

    scoreboard = models.BooleanField(default=False)

    managers = models.ManyToManyField(settings.AUTH_USER_MODEL, related_name='courseedition_manager_set', blank=True)

    default_name = models.CharField(max_length=100, unique=False)
    default_language = models.CharField(max_length=16,
                                        choices=I18NMixin.LANGUAGE_CHOICES,
                                        default=I18NMixin.LANGUAGE_DEFAULT)

    class Meta: #pylint: disable=W0232,C0111,R0903
        app_label = APP_LABEL
        get_latest_by = 'created'
        unique_together = ('code', 'period')
        index_together = [
            ('code', 'period'),
        ]

    class MPTTMeta: #pylint: disable=W0232,C0111,R0903
        order_insertion_by = ['created']

    # Cache helpers
    def _get_cachekey(self, *args):
        key = cache_key('peach3.models.CourseEdition', self, 'key')
        course_cache_hash = unique_cache_hash(key, self)
        return cache_key('peach3.models.CourseEdition', self, 'info', course_cache_hash, *args)

    def _del_cachekey(self):
        key = cache_key('peach3.models.CourseEdition', self, 'key')
        cache.delete(key)

    def _get_user_cachekey(self, user, *args):
        key = self._get_cachekey('user_key', user)
        user_cache_hash = unique_cache_hash(key, user)
        return cache_key('peach3.models.CourseEdition', self, 'userinfo', user, user_cache_hash, *args)

    def _del_user_cachekey(self, user):
        key = self._get_cachekey('user_key', user)
        cache.delete(key)

    def flush_cache(self):
        self._del_cachekey()

    def delete(self, *args, **kwargs):
        self.flush_cache()
        super(CourseEdition, self).delete(*args, **kwargs)

    ### Model methods
    def get_similar(self, include_self=False):
        """ Returns a QuerySet for all similar courses. Includes:
             * Courses in the same tree
             * Courses with the same code

            If include_self=False (default), excludes the current course
        """
        same_root = self.get_root().get_descendants(include_self=True)
        q = CourseEdition.objects.filter(Q(pk__in=same_root)|Q(code=self.code))
        if not include_self:
            q = q.exclude(pk=self.pk)
        return q

    def get_user_cluster(self, user):
        if user.is_superuser:
            return self.get_admin_cluster()

        key = self._get_user_cachekey(user, 'cluster')

        cached = cache.get(key)
        if cached is None:
            try:
                cluster = self.cluster_set.get(clustermember__user=user)
            except self.cluster_set.model.DoesNotExist:
                cluster = None

            cache.set(key, (cluster,))

        else:
            cluster = cached[0]

        return cluster

    def _get_user_cluster_attribute(self, user, attr):
        if user.is_superuser:
            return None

        key = self._get_user_cachekey(user, attr)

        cached = cache.get(key)
        if cached is None:
            try:
                clm = ClusterMember.objects.get(cluster__courseedition=self,
                                                user=user)
                value = getattr(clm, attr, None)
            except ClusterMember.DoesNotExist:
                value = None

            cache.set(key, (value,))

        else:
            value = cached[0]

        return value

    def get_user_realm(self, user):
        return self._get_user_cluster_attribute(user, 'realm')

    def get_user_subcode(self, user):
        return self._get_user_cluster_attribute(user, 'subcode')

    def get_clusters(self, **kwargs):
        if not kwargs:
            return self.cluster_set.all()
        else:
            return self.cluster_set.filter(**kwargs)

    def get_observable_clusters(self, user, level):
        if user.is_superuser:
            # Superuser can always observe
            return list(self.get_clusters())

        key = self._get_user_cachekey(user, 'observable_clusters', level)

        clusters = cache.get(key)
        if clusters is None:
            clusters = list(self.get_clusters(clusterstaff__user=user,
                                              clusterstaff__level__gt=level-1))
            cache.set(key, clusters)

        return clusters

    def get_admin_cluster(self):
        if not hasattr(self, '_admin_cluster'):
            try:
                self._admin_cluster = self.cluster_set.get(admin_cluster=True) #pylint: disable=W0201
            except self.cluster_set.model.DoesNotExist:
                return None

        return self._admin_cluster

    def is_member(self, user):
        cl = self.get_user_cluster(user)
        return cl is not None

    def is_active_member(self, user):
        cl = self.get_user_cluster(user)
        if cl is None:
            return False

        key = self._get_user_cachekey(user, 'is_active_member')

        cached = cache.get(key)
        if cached is None:
            active = cl.clustermember_set.filter(user=user, removed=ClusterMember.SOURCE_NONE).exists()
            cache.set(key, (active,))

        else:
            active = cached[0]

        return active

    def is_manager(self, user, include_superuser=True):
        if user.is_superuser and include_superuser:
            return True

        key = self._get_user_cachekey(user, 'is_manager')

        cached = cache.get(key)
        if cached is None:
            manager = self.managers.filter(pk=user.pk).count()>0
            cache.set(key, (manager,))
        else:
            manager = cached[0]

        return manager

    def get_managers(self):
        return self.managers.all()

    def is_staff(self, user):
        if user.is_superuser:
            return True

        key = self._get_user_cachekey(user, 'is_staff')

        cached = cache.get(key)
        if cached is None:
            staff = ClusterStaff.objects.filter(user=user, cluster__courseedition=self).count()>0
            cache.set(key, (staff,))

        else:
            staff = cached[0]

        return staff

    def get_staff(self):
        # Returns all users that are staff for this course
        key = self._get_cachekey('get_staff')

        cached = cache.get(key)
        if cached is None:
            user_ids = ClusterStaff.objects.filter(cluster__courseedition=self)\
                                           .distinct().values_list('user', flat=True)
            cache.set(key, user_ids)
        else:
            user_ids = cached

        return [get_user_model().objects.get(pk=uid) for uid in user_ids]

    def get_active_members(self):
        # Returns a User queryset for all active members of this course
        # Active is: user is active in User model and ClusterMember model

        cls = Cluster.objects.filter(courseedition=self, admin_cluster=False)
        clms = ClusterMember.objects.filter(removed=ClusterMember.SOURCE_NONE, cluster__in=cls)
        return get_user_model().objects.filter(is_active=True, clustermember__in=clms)

    def add_to_admincluster(self, user):
        admin_cl = self.get_admin_cluster()
        assert admin_cl
        if not admin_cl.is_member(user):
            if not user.is_superuser:
                cluster = self.get_user_cluster(user)
            else:
                cluster = None

            if cluster:
                # Move user
                cluster.move_member(user, admin_cl, None, source=ClusterMember.SOURCE_STAFF)
            else:
                # Add user to admin cluster
                admin_cl.add_member(ClusterMember.SOURCE_STAFF, user, None)

            self._del_user_cachekey(user)

    def remove_from_admincluster(self, user):
        admin_cl = self.get_admin_cluster()
        assert admin_cl
        if admin_cl.is_member(user) and not self.is_manager(user, False):
            # If user has any submissions, move him to a normal cluster
            if self.submission_set.filter(authors=user).count()>0:
                cluster = self.get_clusters(admin_cluster=False)[0]
                realm = cluster.realms.all()[0]
                admin_cl.move_member(user, cluster, realm, source=ClusterMember.SOURCE_STAFF)

            else:
                # Remove user from admin cluster
                admin_cl.remove_member(user)

            self._del_user_cachekey(user)

    def add_manager(self, user):
        if not user.is_superuser:
            assert not self.is_manager(user)

            #self.add_to_admincluster(user)
            self.managers.add(user)

#            # Make manager a level 10 reviewer for all clusters
#            for cl in self.get_clusters(admin_cluster=False):
#                cl.set_staff(user, ClusterStaff.ROLE_REVIEW, 10, True)

            self._del_user_cachekey(user)

    def remove_manager(self, user):
        if not user.is_superuser:
            assert self.is_manager(user)

            self.managers.remove(user)
#            if not self.is_staff(user):
#                self.remove_from_admincluster(user)
            self._del_user_cachekey(user)

    def get_observelevel(self, user, cluster=None):
        """ Returns user's (maximum) observelevel for this CourseEdition.
            cluster can be:
               None, which indicate's user's cluster (default)
               a cluster object
               a list (or generator) of clusters
               string '*', indicating all clusters for this courseedition
        """
        if user.is_superuser:
            return 99

        key = self._get_user_cachekey(user, 'observelevel', cluster)

        cached = cache.get(key)
        if cached is None:
            if cluster is None:
                clusters = [self.get_user_cluster(user)]
            elif cluster=='*':
                clusters = list(self.get_clusters(admin_cluster=False))
            elif isinstance(cluster, Cluster):
                clusters = [cluster]
            else:
                clusters = cluster

            level = None
            for cl in clusters:
                if cl.admin_cluster:
                    return self.get_observelevel(user, '*')
                level = max(level, cl.get_observelevel(user))

            cache.set(key, (level,))

        else:
            level = cached[0]

        return level

    def get_reviewlevel(self, user, cluster=None):
        """ Returns user's (maximum) reviewlevel for this CourseEdition.
            cluster can be:
               None, which indicate's user's cluster (default)
               a cluster object
               a list (or generator) or clusters
               string '*', indicating all clusters for this courseedition
        """
        key = self._get_user_cachekey(user, 'reviewlevel', cluster)

        cached = cache.get(key)
        if cached is None:
            if cluster is None:
                clusters = [self.get_user_cluster(user)]
            elif cluster=='*':
                clusters = list(self.get_clusters())
            elif isinstance(cluster, Cluster):
                clusters = [cluster]
            else:
                clusters = cluster

            level = None
            for cl in clusters:
                level = max(level, cl.get_reviewlevel(user))

            cache.set(key, (level,))

        else:
            level = cached[0]

        return level

    def realms(self, subcode=None):
        realms = Realm.objects.filter(cluster__courseedition=self)
        if subcode:
            realms = realms.filter(cluster__subcodes=subcode)
        return realms.distinct()

    def find_cluster(self, realm, subcode, must_be_joinable):
        " Pick an available cluster to join a new user "
        clusters = self.cluster_set.filter(admin_cluster=False,
                                           test_cluster=False)
        if realm:
            clusters = clusters.filter(realms=realm)
        if subcode:
            clusters = clusters.filter(subcodes=subcode)
        if must_be_joinable:
            clusters = clusters.filter_joinable()

        clusters = list(clusters)

        if len(clusters)==1:
            return clusters[0]

        elif len(clusters)>1 and self.cluster_selection == self.CLUSTER_SELECTION_AUTO:
            # Automatic selection: randomly pick one of the smallest clusters

            smallest, smallest_size = [], None
            for cl in clusters:
                size = cl.get_size()
                if smallest_size is None or size<=smallest_size:
                    if size != smallest_size:
                        smallest, smallest_size = [], size

                    smallest.append(cl)

            return random.choice(smallest)

        return None

    @transaction.commit_on_success
    def join_cluster(self, source, user, realm, cluster, subcode=None, must_be_joinable=True):
        # Join a new user to a cluster
        #  cluster MUST be None if cluster_selection = AUTOMATIC
        #  cluster MAY be None if cluster_selection = MANUAL; in that case only one cluster should
        #                             be joinable; otherwise False is returned
        # Selected cluster must be joinable, and linked to realm, otherwise False is returned
        # Returns True on success, or None if user was already member
        if self.is_member(user):
            return None

        if self.cluster_selection==self.CLUSTER_SELECTION_AUTO and cluster is not None:
            return False

        if cluster is None:
            cluster = self.find_cluster(realm, subcode, must_be_joinable)
            if not cluster:
                return False

        # Sanity checks
        if must_be_joinable and not cluster.is_joinable():
            return False
        elif realm and not cluster.realms.filter(pk=realm.pk).exists():
            return False
        elif subcode and not cluster.subcodes.filter(pk=subcode.pk).exists():
            return False

        if not realm:
            realm = cluster.realms.all()[0]

        self._del_user_cachekey(user)
        created = ClusterMember.objects.get_or_create(cluster=cluster,
                                                      user=user,
                                                      defaults={
                                                          'source':source,
                                                          'realm':realm,
                                                          'subcode':subcode,
                                                      })[1]

        return created or None

    @transaction.commit_on_success
    def leave_cluster(self, user):
        if not self.is_member(user) or not self.can_leave(user):
            return False

        self._del_user_cachekey(user)
        ClusterMember.objects.get(cluster__courseedition=self, user=user).delete()

        return True

    def can_leave(self, user):
        return (self.submission_set.filter(authors=user).count()==0
            and not self.is_manager(user)
            and not self.is_staff(user))

    def is_joinable(self):
        " Returns True if at least one cluster is joinable "
        return self.cluster_set.filter(admin_cluster=False, test_cluster=False).filter_joinable().exists()

    def is_active(self):
        " Returns True if at least one cluster is active "
        return self.cluster_set.filter(admin_cluster=False, test_cluster=False).filter_active().exists()

    ### Naming interface
    def get_display_name(self, lang=None, with_period=True):
        name = u'%s: %s' % (self.code, self.get_name(lang))

        if with_period:
            name += ' (%s)' % self.period.get_display_name(lang)

        return name

    def __unicode__(self):
        return self.get_display_name()

    ### Unique Identification Interface
    @classmethod
    def get_uid_fields(cls):
        return 'period__slug', 'code'

    def get_uid(self):
        return self.period.slug, self.code

#    ### Permission Interface
#    def _get_permissions(self, user):
#        return ( user.get_model_permissions(self)
#               | self.course.get_permissions(user)
#               )
#
    def has_access(self, user, access=None):
        if user.is_superuser:
            return True
        elif user.is_anonymous():
            return False

        if access in ['manage', 'createwiki']:
            return self.is_manager(user)

        is_reviewer = self.get_reviewlevel(user, '*') is not None
        if access=='review':
            return is_reviewer

        is_observer = self.get_observelevel(user, '*') is not None
        if access=='observe':
            return is_observer

        return access is None and (is_reviewer or is_observer or self.is_member(user))

    get_absolute_url = get_model_absolute_url

#class FinalGrade(models.Model):
#    ### Model definition
#    courseedition = TreeForeignKey(CourseEdition)
#    user = models.ForeignKey(settings.AUTH_USER_MODEL)
#    grade = models.ForeignKey(Grade)
#
#    class Meta: #pylint: disable=W0232,C0111,R0903
#        app_label = APP_LABEL
#
#    ### Naming interface
#    def __unicode__(self):
#        return u'%s: %s' % (self.user, self.grade)

### Signals

def __add_or_update_manager(cluster, user):
    cluster.set_staff(user, **ClusterStaff.MANAGER_VALUES)

@receiver(post_save, sender=CourseEdition)
@skip_raw_save
def courseedition_saved(instance, **kwargs): #pylint: disable=W0613
    " Make sure there exists an admin Cluster "
    if instance.cluster_set.filter(admin_cluster=True).count()==0:
        instance.cluster_set.create(admin_cluster=True, default_name="Admin")

@receiver(pre_delete, sender=CourseEdition)
def courseedition_delete(instance, **kwargs): #pylint: disable=W0613
    " Trigger the managers_changed signal before deleting the CourseEdition "
    instance.managers.clear()

@receiver(m2m_changed, sender=CourseEdition.managers.through)
def managers_changed(instance, action, reverse, pk_set, model, **kwargs): #pylint: disable=W0613
    if not reverse:
        if action in ['pre_add', 'post_add', 'pre_remove']:
            users = model.objects.filter(pk__in=pk_set)
        elif action=='pre_clear':
            users = instance.managers

        if action=='pre_add':
            for user in users.all():
                # Add/update new managers as members to the admin cluster
                instance.add_to_admincluster(user)

                # Add/update new managers as staff to all clusters, except the admin-cluster
                for cluster in instance.cluster_set.filter(admin_cluster=False):
                    __add_or_update_manager(cluster, user)

        elif action=='post_add':
            # The new managers are staff, and add them to the group 'Managers'
            group = Group.objects.get(name='Managers')
            for user in users.exclude(groups=group):
                user.groups.add(group)

            users.update(is_staff=True)

        elif action in ['pre_remove', 'pre_clear']:
            # If this courseedition is the only one the user manages,
            # remove user from the Managers permission group
            group = Group.objects.get(name='Managers')
            to_unstaff = []
            for user in users.all():
                if user.courseedition_manager_set.count()==1:
                    user.groups.remove(group)
                    to_unstaff.append(user.pk)

            if to_unstaff:
                get_user_model().objects.filter(pk__in=to_unstaff).update(is_staff=False)

@receiver(post_save, sender=Cluster)
@skip_raw_save
def cluster_saved(instance, created, **kwargs): #pylint: disable=W0613
    if created:
        # Add existing managers as staff to this cluster
        for manager in instance.courseedition.managers.all():
            __add_or_update_manager(instance, manager)

@receiver(post_save, sender=ClusterStaff)
@skip_raw_save
def staff_saved(instance, created, **kwargs): #pylint: disable=W0613
    courseedition = instance.cluster.courseedition

    if created:
        # Add the user to the Admin cluster of the courseedition
        user = instance.user

        courseedition.add_to_admincluster(user)

    courseedition.flush_cache()

@receiver(pre_delete, sender=ClusterStaff)
def staff_removed(instance, **kwargs): #pylint: disable=W0613
    courseedition = instance.cluster.courseedition
    user = instance.user

    if not courseedition.is_staff(user):
        # Remove the user from the Admin cluster of the courseedition
        courseedition.remove_from_admincluster(user)

    courseedition.flush_cache()

class SubCode(models.Model, I18NMixin):
    courseedition = models.ForeignKey(CourseEdition)

    subcode = models.SlugField(max_length=16)

    default_name = models.CharField(max_length=100, unique=False)
    default_language = models.CharField(max_length=16,
                                        choices=I18NMixin.LANGUAGE_CHOICES,
                                        default=I18NMixin.LANGUAGE_DEFAULT)

    class Meta: #pylint: disable=W0232,C0111,R0903
        app_label = APP_LABEL
        unique_together = ('courseedition', 'subcode')

    ### Naming interface
    def get_display_name(self, lang=None):
        return u'%s: %s' % (self.subcode, self.get_name(lang))

    def __unicode__(self):
        return self.get_display_name()

@receiver(post_save, sender=SubCode)
@skip_raw_save
def subcode_saved(instance, created, **kwargs): #pylint: disable=W0613
    if created:
        # Add subcode to course's admin cluster
        instance.courseedition.get_admin_cluster().subcodes.add(instance)

        # Add subcode to other clusters of this course that do not have a subcode yet
        for cluster in instance.courseedition.get_clusters(admin_cluster=False, subcodes=None):
            cluster.subcodes.add(instance)

