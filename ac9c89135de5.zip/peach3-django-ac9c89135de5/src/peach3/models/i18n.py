""" This file is part of PEACH.

    Copyright (C) 2006-2012 Eindhoven University of Technology
"""
from django import dispatch
from django.conf import settings
from django.contrib.contenttypes import generic
from django.contrib.contenttypes.models import ContentType
from django.core.cache import cache
from django.db import models
from django.db.models.signals import post_save, post_delete
from django.utils.translation import ugettext as _, get_language

from peach3.models import APP_LABEL
from peach3.utils.cache import cache_key

from peach3.managers.i18n import TranslatedNameManager

__all__ = ('I18NMixin', 'TranslatedName')

def parse_names(all_names, ignore_errors=False):
    if isinstance(all_names, dict):
        return all_names

    default = None
    names = {}

    for langname in all_names.split('\n'):
        langname = langname.strip()
        if langname:
            if ':' not in langname:
                if ignore_errors:
                    continue
                raise ValueError, _("Invalid format")

            lang, name = langname.split(':', 1)

            if lang not in I18NMixin.LANGUAGE_CODES:
                if ignore_errors:
                    continue
                raise ValueError, _("Invalid language code")

            if default is None:
                default = lang

            names[lang] = name

    return names, default

class I18NMixin: #pylint: disable=W0232
    """ A mixin for objects with translated names.

        Requires the following fields to be added to the model::

            default_name = models.CharField(max_length=100)
            default_language = models.CharField(max_length=16,
                                                choices=I18NMixin.LANGUAGE_CHOICES,
                                                default=I18NMixin.LANGUAGE_DEFAULT)

        The 'default_name' field can optionally have blank=True and/or unique=True
    """
    LANGUAGE_CHOICES = settings.LANGUAGES
    LANGUAGE_CODES = [l[0] for l in LANGUAGE_CHOICES]
    LANGUAGE_DEFAULT = settings.LANGUAGE_CODE

    def get_name(self, lang=None):
        if lang is None:
            lang = get_language()

        if lang==self.default_language:
            return self.default_name

        key = cache_key('peach3.models.i18n.mixin.get_name', self, lang)

        name = cache.get(key)
        if name is None:
            try:
                name = TranslatedName.objects.get_by_object(object=self, language=lang).name
            except TranslatedName.DoesNotExist:
                name = self.default_name

            cache.set(key, name)

        return name

    name = property(get_name)

    def set_name(self, name, lang=None, set_default=False):
        #pylint: disable=W0201,E0203

        if lang is None:
            lang = get_language()
        elif lang not in self.LANGUAGE_CODES:
            raise ValueError, _("Invalid language code")

        if lang==self.default_language or set_default:
            # Save old default
            old_default_name = self.default_name
            old_default_language = self.default_language

            # Set new default (No need to delete from cache, the save will take care of that)
            TranslatedName.objects.filter_by_object(object=self, language=lang).delete()
            self.default_name = name
            self.default_language = lang
            if self.pk is not None:
                self.save(update_fields=['default_name', 'default_language'])

            # If language of old default differs from new default, save old default as translation
            if old_default_language != lang:
                self.set_name(old_default_name, old_default_language)

        else:
            tn, created = TranslatedName.objects.get_or_create_by_object(object=self,
                                                                         language=lang,
                                                                         defaults={
                                                                             'name':name,
                                                                         })
            if not created:
                tn.name = name
                tn.save(update_fields=['name'])

    set_name.alters_data=True

    def get_all_names(self):
        key = cache_key('peach3.models.i18n.mixin.get_all_names', self)

        names = cache.get(key)
        if names is None:
            names =  [(self.default_language, self.default_name)] \
                    +[(o.language, o.name)
                      for o in TranslatedName.objects.filter_by_object(object=self)]

            names = "\n".join("%s:%s" % n for n in names)

            cache.set(key, names)

        return names

    def set_all_names(self, all_names):
        names, default = parse_names(all_names, True)

        # Update/add translations
        for lang, name in names.iteritems():
            self.set_name(name, lang, lang==default)

        # Delete removed translations
        rest = TranslatedName.objects.filter_by_object(object=self)\
                                     .exclude(language__in=names.keys())

        langs = list(rest.values_list('language', flat=True))
        rest.delete()
        _delete_cache_keys(self, langs)

    set_all_names.alters_data=True

    all_names = property(get_all_names, set_all_names)

    get_display_name = get_name

    def __unicode__(self):
        return self.get_display_name()

class TranslatedName(models.Model):
    content_type = models.ForeignKey(ContentType)
    object_id = models.PositiveIntegerField()

    object = generic.GenericForeignKey('content_type', 'object_id') #@ReservedAssignment
    language = models.CharField(max_length=16, choices=settings.LANGUAGES)
    name = models.CharField(max_length=100)

    objects = TranslatedNameManager()

    class Meta: #pylint: disable=W0232,C0111,R0903
        app_label = APP_LABEL
        unique_together = ('content_type', 'object_id', 'language')
        index_together = [
            ('content_type', 'object_id', 'language'),
        ]

def _delete_cache_keys(obj, langs):
    if not isinstance(langs, (list, tuple)):
        langs = [langs]
    for lang in langs:
        key = cache_key('peach3.models.i18n.mixin.get_name', obj, lang)
        cache.delete(key)
    key = cache_key('peach3.models.i18n.mixin.get_all_names', obj)
    cache.delete(key)

@dispatch.receiver(post_save)
def i18mixin_saved(sender, instance, **kwargs): #pylint: disable=W0613
    if isinstance(instance, I18NMixin):
        _delete_cache_keys(instance, instance.default_language)

@dispatch.receiver([post_save, post_delete], sender=TranslatedName)
def translatedname_saved(sender, instance, **kwargs): #pylint: disable=W0613
    _delete_cache_keys(instance.object, instance.language)
