""" This file is part of PEACH.

    Copyright (C) 2006-2012 Eindhoven University of Technology
"""
from django.contrib.sites.models import Site
from django.contrib.sites.managers import CurrentSiteManager
from django.db import models

from peach3.models.i18n import I18NMixin
from peach3.models import APP_LABEL
from peach3.utils.ppk import PPKModelMixin, PPKManager

__all__ = ('Realm',)

class Realm(models.Model, I18NMixin, PPKModelMixin):
    site = models.ForeignKey(Site)
    default_name = models.CharField(max_length=100, unique=True)
    default_language = models.CharField(max_length=16,
                                        choices=I18NMixin.LANGUAGE_CHOICES,
                                        default=I18NMixin.LANGUAGE_DEFAULT)

    ### Managers
    objects = PPKManager()
    on_site = CurrentSiteManager()

    class Meta: #pylint: disable=W0232,C0111,R0903
        app_label = APP_LABEL
        ordering = 'default_name',

    def has_access(self, user, access=None):
        return user.is_superuser or access is None

