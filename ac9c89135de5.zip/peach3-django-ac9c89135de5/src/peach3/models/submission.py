""" This file is part of PEACH.

    Copyright (C) 2006-2009 Eindhoven University of Technology
"""
from django import dispatch
from django.conf import settings
from django.contrib.contenttypes import generic
from django.contrib.contenttypes.models import ContentType
from django.core.cache import cache
from django.core.urlresolvers import reverse
from django.db import models, transaction
from django.db.models.signals import pre_delete, post_delete, post_save
from django.utils.http import urlquote_plus
from django.utils.timezone import now
from django.utils.translation import ugettext as _

from peach3.core.modelurl import get_model_absolute_url
from peach3.core.signals import cleanup_signal
from peach3.core.storage.secured import FileAccessDeniedError
from peach3.managers.submission import SubmissionManager, SubmissionAuthorManager
from peach3.models import APP_LABEL
from peach3.models.assignment import AssignmentEdition, AssignmentSlot
from peach3.models.cluster import Cluster, ClusterMember
from peach3.models.course import CourseEdition
from peach3.models.files import FileRevision
from peach3.models.flag import FlaggedObject
from peach3.models.forum import Comment
from peach3.models.news import NewsItem
from peach3.models.proglang import ProgrammingLanguage
from peach3.utils.cache import cache_key, unique_cache_hash
from peach3.utils.dates import TimeRange
from peach3.utils.permissions import get_current_user
from peach3.utils.ppk import PPKModelMixin, PPKManager

from mptt.models import TreeForeignKey

from datetime import timedelta

__all__ = ('Submission', 'SubmissionAuthor', 'SubmissionFile', )

# Create your models here.

submission_created = dispatch.Signal() #pylint: disable=C0103

class Submission(models.Model, PPKModelMixin): #pylint: disable=R0902,R0904
    assignmentedition = TreeForeignKey(AssignmentEdition)
    courseedition = TreeForeignKey(CourseEdition)

    authors = models.ManyToManyField(settings.AUTH_USER_MODEL, through='SubmissionAuthor')

    # clusters is the clusters the authors of this submission are member of
    #   (automatically updated by a signalhandler)
    #   DB denormalisation to speed up selecting submissions a staff member can observe or review
    clusters = models.ManyToManyField(Cluster)

    # is_group=True iff COUNT(authors)>1 (automatically updated by a signalhandler)
    #   This is a DB denormalisation; using annotate to Count the authors and filter on that
    #   resulted in an very inefficient query in utils.submission.get_available_coauthors
    is_group = models.BooleanField(default=False)

    comments = generic.GenericRelation(Comment, object_id_field='parent_id',
                                                content_type_field='parent_content_type')
    flags = generic.GenericRelation(FlaggedObject, object_id_field='parent_id',
                                    content_type_field='parent_content_type')

    created = models.DateTimeField(default=now, db_index=True)
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL,
                                   related_name='submission_created_set',
                                   default=get_current_user) # NOT necessarily one of the authors!

    submitted = models.DateTimeField(null=True, blank=True)
    submitted_by = models.ForeignKey(settings.AUTH_USER_MODEL,
                                     null=True, blank=True,
                                     related_name='submission_submitted_set')

    files = models.ManyToManyField(FileRevision, through='SubmissionFile')

    modified = models.DateTimeField(auto_now=True, db_index=True) # Last modified time

    language = models.ForeignKey(ProgrammingLanguage, blank=True, null=True)

    objects = SubmissionManager()

    class Meta: #pylint: disable=W0232,C0111,R0903
        app_label = APP_LABEL
        ordering = 'created',
        index_together = (
            ('assignmentedition', 'created_by'),
        )

    def _mark_updated(self):
        rnow = now().replace(microsecond=0)
        ae = self.assignmentedition

        self._flush_cache()

        for au in self.authors.all():
            # This key is also used by assignment.models.AssignmentEdition
            # and submission.ajax.list_all
            key = cache_key('peach3.models.Submission', au, ae, 'updated')
            cache.set(key, rnow, 60*60)

        self._observelevel = {}
        self._reviewlevel = {}

    @transaction.commit_manually
    def submit(self, stamp, user, comment=None, progLangId=None):
        # User can be None (submitted by system)
        assert user is None or self.can_submit(user)

        try:
            self.submitted = stamp
            self.submitted_by = user
            if progLangId:
                self.language = ProgrammingLanguage.objects.get(id=progLangId)
            else:
                # if exactly one programming language is allowed for this assignment, use that one
                if self.assignmentedition.languages.count() == 1:
                    self.language = self.assignmentedition.languages.get()
                else:
                    self.language = None

            self.save()

            if comment:
                c = self.comments.create(author=user, created=stamp)
                c.commentrevision_set.create(author=user,
                                             created=stamp,
                                             header='',
                                             message=comment)

        except:
            transaction.rollback()
            raise

        finally:
            transaction.commit()

        try:
            handled = False
            for receiver, response in submission_created.send(sender=self.__class__,
                                                              instance=self):
                if response:
                    handled = True
                    break

            if not handled:
                self.send_initial_news()

        except:
            transaction.rollback()
            raise

        finally:
            transaction.commit()

    submit.alters_data = True

    def _get_state(self, author):
        if author:
            try:
                return self.submissionauthor_set.get(author=author).state
            except SubmissionAuthor.DoesNotExist:
                pass

        states = self.submissionauthor_set.values_list('state', flat=True)
        if states:
            for state in states:
                if state != 'REVOKED':
                    return state

            return 'REVOKED'

        return 'NEW'

    def get_state(self, author):
        """ Get (cached) state for author; author may be None to get the user-independent state

        Can return
          NEW:       Submission is being submitted
          CHECK:     Submission is queued for check
          CHECKING:  Submission is being checked
          SYSFAIL:   System failure during check occurred
          REVIEW:    Submission is queued for review
          REVIEWING: Submission is locked for review
          ACCEPTED:  Submission was accepted
          REJECTED:  Submission was rejected
          REVOKED:   Submission was revoked
        """
        key = cache_key('peach3.models.Submission.state', self.pk, author)
        state = cache.get(key)
        if state is None:
            state = self._get_state(author)

            cache_time = SubmissionAuthor.STATE_CACHE_TIME.get(state, 0)
            if cache_time>0:
                # Using 'add' here, to prevent a race condition with SubmissionAuthorManager.update_assignmentedition
                cache.add(key, state, cache_time*60)

        return state

    def get_score(self, user):
        try:
            return self.checkresult_set.latest().get_score(user)
        except self.checkresult_set.model.DoesNotExist:
            return None

    def get_steps_count(self, user, stage=None):
        try:
            return self.checkresult_set.latest().get_steps_count(user, stage)
        except self.checkresult_set.model.DoesNotExist:
            return None

    def get_file(self, filename):
        try:
            return self.submissionfile_set.get(name=filename)
        except self.submissionfile_set.model.DoesNotExist:
            return None

    def is_replaced(self, user=None):
        # Returns True if this submission was replaced by a newer submission
        #  If user is None: for all authors, otherwise for requested user
        authors = [user] if user else self.authors.all()

        newersbs = Submission.objects.filter(authors__in=authors,
                                             assignmentedition=self.assignmentedition,
                                             created__gt=self.created)

        return newersbs.exists()

    @transaction.commit_on_success
    def send_initial_news(self):
        " Send the initial news message after upload and accept/reject by the system "

        msg = None
        try:
            scr = self.checkresult_set.latest()
        except self.checkresult_set.model.DoesNotExist:
            msg = 'received'
        else:
            if scr.state=='CHECKED':
                if scr.grade is None or scr.grade.passing != False:
                    msg = 'received'
                else:
                    msg = 'rejected'
            else:
                return

        authors = list(self.authors.all())

        self_ct = ContentType.objects.get_for_model(self)
        rnow = now()
        exp = max(self.created + timedelta(days=365),
                  rnow + timedelta(days=30))

        # Mark any news item pertaining to an older submission for this assignment
        # by this author as not-current
        for sb in Submission.objects.filter(authors__in=authors,
                                            assignmentedition=self.assignmentedition):
            NewsItem.objects.filter_related(sb).update(current=False)

        admin_cluster = self.courseedition.get_admin_cluster()
        if admin_cluster:
            # Message to the course staff

            existing_news = NewsItem.objects.filter(
                courseedition = self.courseedition,
                cluster = admin_cluster,
                related_content_type = self_ct,
                related_id = self.id,
                created_by = self.created_by,
                msgtype = msg+'-admin',
            ).order_by('-created')

            if msg=='received':
                if len(existing_news)==0:
                    NewsItem.objects.create(
                        courseedition = self.courseedition,
                        cluster = admin_cluster,
                        related_content_type = self_ct,
                        related_id = self.id,
                        created_by = self.created_by,
                        msgtype = msg+'-admin',
                        created = rnow,
                        appears = self.created,
                        expires = exp,
                    )
                else:
                    news = existing_news[0]

                    if not news.current:
                        news.current = True
                        news.save(update_fields=['current'])

            else:
                existing_news.delete()

        # Message to the authors
        for author in authors:
            msg_end = '-author' if author==self.created_by else '-coauthor'
            umsg = msg+msg_end

            existing_news = NewsItem.objects.filter(
                courseedition = self.courseedition,
                receipient = author,
                related_content_type = self_ct,
                related_id = self.id,
                created_by = self.created_by,
                msgtype__endswith = msg_end,
            ).order_by('-created')

            if len(existing_news)==0:
                NewsItem.objects.create(
                    courseedition = self.courseedition,
                    receipient = author,
                    related_content_type = self_ct,
                    related_id = self.id,
                    created_by = self.created_by,
                    created = rnow,
                    appears = self.created,
                    expires = exp,
                    msgtype = umsg,
                )
            else:
                news = existing_news[0]

                if news.msgtype != umsg or news.expires < exp or not news.current:
                    news.current = True
                    news.msgtype = umsg
                    news.expires = exp
                    news.save()

                    if news.msgtype != umsg:
                        news.mark_unread()

    def get_news_text(self, newsitem):
        # Do not supply any hints to the score in these messages, to encourage users to visit the
        # full submission and not just read a summary
        texts = {
            'received-admin' : (
                _("%(fullname)s submitted '%(assignmentname)s'"),
                _("%(fullname)s (%(username)s) submitted for assignment '%(assignmentname)s'."),
            ),
            'received-author' : (
                _("Received: Submission for '%(assignmentname)s'"),
                _("Your submission for assignment '%(assignmentname)s' was received. "
                  "Open the submission to see the full status."),
            ),
            'received-coauthor' : (
                _("Received: Submission by %(fullname)s for '%(assignmentname)s'"),
                _("%(fullname)s submitted a teamwork submission for assignment '%(assignmentname)s'. "
                  "Open the submission to see the full status."),
            ),
            'rejected-author' : (
                _("REJECTED: Submission for '%(assignmentname)s'"),
                _("Your submission for assignment '%(assignmentname)s' was rejected. "
                  "Open the submission to see the reason."),
            ),
            'rejected-coauthor' : (
                _("REJECTED: Submission by %(fullname)s for '%(assignmentname)s'"),
                _("%(fullname)s submitted a teamwork submission for assignment '%(assignmentname)s' but "
                  "it was rejected. Open the submission to see the reason."),
            ),
            'reviewed' : (
                _("Submission for '%(assignmentname)s' reviewed"),
                _("Your submission for '%(assignmentname)s' has been reviewed. "
                  "Open the submission to see the review."),
            ),
        }

        args = {
            'username' : self.created_by.username,
            'fullname' : self.created_by.get_full_name_formal(),
            'assignmentname' : self.assignmentedition.name,
        }

        s, t = texts[newsitem.msgtype]
        return s % args, t % args

    def get_observelevel(self, user):
        """ Returns the user's observelevel for this submission
            Returns >0 for observers, and None for outsiders.
            Should not return 0 for authors!
        """
        return self.courseedition.get_observelevel(user, list(self.get_clusters()))

    def get_reviewlevel(self, user):
        """ Returns the user's reviewlevel for this submission
            Returns >0 for reviewers, and None for outsiders.
            Level 0 is reserved for peer-reviews (not implemented yet)
        """
        clusters = list(self.get_clusters())

        if (len(clusters)==0 and user==self.created_by)\
                 or (len(clusters)==1 and clusters[0].admin_cluster):
            # Special case: no authors yet, or all authors are reviewers
            clusters = '*'

        return self.courseedition.get_reviewlevel(user, clusters)

    def get_authors(self):
        # Generator returning all authors; the author that submitted the submission
        # is at the front
        main_author = None

        if self.submitted_by and self.is_author(self.submitted_by):
            main_author = self.submitted_by
        elif self.created_by and self.is_author(self.created_by):
            main_author = self.created_by

        q = self.authors
        if main_author:
            yield main_author
            q = q.exclude(pk=main_author.pk)

        for author in q.order_by('last_name', 'first_name'):
            yield author

    def get_clusters(self):
        return self.clusters.iterator()

    def same_authors(self, other_submission):
        # Returns the number of authors that are the same for both submissions
        pks = [au.pk for au in other_submission.get_authors()]
        return self.authors.filter(pk__in=pks).count()

    def is_visible(self, user):
        """ Returns True if the user can view the full submission; ie. it includes authors and staff reviewers
            but not peer-reviewers
        """
        return self.is_author(user) or self.is_observer(user) or self.is_reviewer(user)

    def is_author(self, user):
        " Returns True if the given user is an author "
        return self.authors.filter(pk=user.pk).exists()

    def add_author(self, *users):
        " Add one or more authors to this submission "
        current_authors = self.authors.all()

        SubmissionAuthor.objects.bulk_create(
            SubmissionAuthor(submission=self, author=user)
            for user in users
            if user not in current_authors
        )

        self._update_clusters_relation()

        # Update the user states
        SubmissionAuthor.objects.update_submission(self, users)

    def remove_author(self, *users):
        " Remove on or more authors from this submission "
        SubmissionAuthor.objects.filter(submission=self, author__in=users).delete()

        self._update_clusters_relation()

        # Update the user states
        SubmissionAuthor.objects.update_submission(self, users)

    def is_observer(self, user):
        """ Returns True if the user is an observer for this submission
        """
        return self.get_observelevel(user) >= self.assignmentedition.observelevel

    def is_reviewer(self, user):
        " Returns True if the user is a reviewer for this submission "
        if not self.assignmentedition.has_option('REVIEW'):
            return False

        try:
            review = self.review_set.latest()
        except self.review_set.model.DoesNotExist:
            review = None

        if review:
            return review.can_modify(user)

        return self.get_reviewlevel(user) >= self.assignmentedition.reviewlevel

    def can_publish_review(self, user, allow_republish=False, initial=False):
        " Returns True if the user can publish the review for this submission "
        try:
            review = self.review_set.latest()
        except self.review_set.model.DoesNotExist:
            if not initial:
                return False
        else:
            if review.is_published() and not allow_republish:
                # Cannot publish if it is already published
                return False

        return user.is_superuser \
               or self.courseedition.is_manager(user) \
               or (self.is_reviewer(user) \
                   and self.get_reviewlevel(user) >= self.assignmentedition.reviewpublishlevel)

    def can_submit(self, user):
        return (self.submitted is None
                and (user.is_superuser
                     or self.get_reviewlevel(user) >= self.assignmentedition.reviewlevel
                     or (self.is_author(user)
                          and self.assignmentedition.is_open(user, when=timedelta(minutes=-5))
                        )
                     )
               ) and self.has_access(user)

    def has_access(self, user, access=None):
        if user.is_superuser:
            return True
        elif user.is_anonymous():
            return False

        is_reviewer = self.is_reviewer(user)
        if access=='review':
            return is_reviewer

        is_observer = self.is_observer(user)
        if access=='observe':
            return is_observer

        return access is None and (is_reviewer or is_observer or self.created_by==user or self.is_author(user))

    def _update_clusters_relation(self):
        " Update the clusters relation and is_group attribute. "
        is_group = self.authors.count()>1
        if is_group != self.is_group:
            self.is_group = is_group
            self.save(update_fields=['is_group'])

        self.clusters = Cluster.objects.filter(courseedition=self.courseedition,
                                               clustermember__user__submission=self)\
                                       .distinct()

    def __unicode__(self):
        return _("%(created_by)s for %(courseedition)s:%(assignmentedition)s on %(created)s") \
                    % {'created_by':self.created_by,
                       'courseedition':self.courseedition,
                       'assignmentedition':self.assignmentedition,
                       'created':self.created
                      }

    get_absolute_url = get_model_absolute_url

    # Cache helpers
    def _get_cachekey(self, *args):
        key = cache_key('peach3.models.Submission', self, 'key')
        submission_cache_hash = unique_cache_hash(key, self)
        return cache_key('peach3.models.Submission', self, 'info', submission_cache_hash, *args)

    def _del_cachekey(self):
        key = cache_key('peach3.models.Submission', self, 'key')
        cache.delete(key)

    def _flush_cache(self):
        self._del_cachekey()

@dispatch.receiver(post_save, sender=Submission)
def submission_saved(sender, instance, created, **kwargs): #pylint: disable=W0613
    " Initialize 'authors', 'is_group' and 'clusters' on newly created submissions "
    instance._mark_updated() #pylint: disable=W0212

    if created:
        creator = instance.created_by
        if not instance.courseedition.is_staff(creator):
            from peach3.utils.submission import get_user_coauthors

            # Collect the required authors
            authors = list(get_user_coauthors(creator,
                                              instance.assignmentedition,
                                              pk__lt=instance.pk)
                          )

            authors.append(creator)

            # Create `authors` relation for the submission
            SubmissionAuthor.objects.bulk_create(
                SubmissionAuthor(submission=instance, author=author)
                for author in authors
            )

            instance._update_clusters_relation() #pylint: disable=W0212

    # Update the user states
    SubmissionAuthor.objects.update_submission(instance)

@dispatch.receiver(pre_delete, sender=Submission)
def submission_pre_delete(sender, instance, **kwargs): #pylint: disable=W0613
    " Update states of other submissions when a submission is about to be deleted "
    SubmissionAuthor.objects.update_submission(instance, for_delete=True)
    instance._mark_updated() #pylint: disable=W0212

@dispatch.receiver(post_save, sender=ClusterMember)
def clustermember_changed(sender, instance, raw, **kwargs): #pylint: disable=W0613
    " Update 'cluster' attribute on Submissions when authors move to another cluster "
    if not raw:
        for sb in Submission.objects.filter(authors=instance.user):
            sb._update_clusters_relation() #pylint: disable=W0212

class SubmissionAuthor(models.Model):
    STATE_UNKNOWN = ''
    STATE_NEW = 'NEW'
    STATE_SYSFAIL = 'SYSFAIL'
    STATE_CHECK = 'CHECK'
    STATE_CHECKING = 'CHECKING'
    STATE_REVIEW = 'REVIEW'
    STATE_REVIEWING = 'REVIEWING'
    STATE_ACCEPTED = 'ACCEPTED'
    STATE_REJECTED = 'REJECTED'
    STATE_REVOKED = 'REVOKED'

    STATE_CHOICES = (
        (STATE_UNKNOWN, ''),
        (STATE_NEW, 'New'),
        (STATE_SYSFAIL, 'SysFail'),
        (STATE_CHECK, 'Check'),
        (STATE_CHECKING, 'Checking'),
        (STATE_REVIEW, 'Review'),
        (STATE_REVIEWING, 'Reviewing'),
        (STATE_ACCEPTED, 'Accepted'),
        (STATE_REJECTED, 'Rejected'),
        (STATE_REVOKED, 'Revoked'),
    )

    # Time, in minutes, to cache a specific state
    # Some states should not be cached too long because they are bound to change,
    # other states are most likely permanent, like ACCEPTED and REJECTED
    STATE_CACHE_TIME = {
        STATE_NEW:       5,
        STATE_CHECK:     1,
        STATE_CHECKING:  1,
        STATE_SYSFAIL:   15,
        STATE_REVIEW:    15,
        STATE_REVIEWING: 5,
        STATE_ACCEPTED:  60*24,
        STATE_REJECTED:  60*24,
        STATE_REVOKED:   60*24,
    }

    submission = models.ForeignKey(Submission)
    author = models.ForeignKey(settings.AUTH_USER_MODEL)

    state = models.CharField(max_length=12, choices=STATE_CHOICES, default=STATE_UNKNOWN, blank=True)
    active = models.BooleanField()          # The submission is the active one for this author
    latest_accepted = models.BooleanField() # The submission is the latest accepted one for this author

    objects = SubmissionAuthorManager()

    class Meta: #pylint: disable=W0232,C0111,R0903
        app_label = APP_LABEL
        unique_together = ('submission', 'author')

class SubmissionFile(models.Model, PPKModelMixin):
    MAX_NAME_LENGTH = 250 # Limited to about 250, because of the UNIQUE relation
    MAX_MIMETYPE_LENGTH = 256

    submission = models.ForeignKey(Submission)
    slot = models.ForeignKey(AssignmentSlot, null=True, blank=True)

    file = models.ForeignKey(FileRevision) #@ReservedAssignment

    name = models.CharField(max_length=MAX_NAME_LENGTH)
    provided_mimetype = models.CharField(max_length=MAX_MIMETYPE_LENGTH, blank=True)
    created = models.DateTimeField(default=now)
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, default=get_current_user)

    objects = PPKManager()

    class Meta: #pylint: disable=W0232,C0111,R0903
        app_label = APP_LABEL
        ordering = 'submission', 'name'
        unique_together = ('submission', 'name')
        # Note: ('submission', 'file') does NOT have to be unique (eg. a submission might
        # have two identical files, and both will use to the same FileRevision object)
        index_together = [
            ('submission', 'name'),
        ]

    def get_download_url(self):
        from peach3.utils.ppk import base32_encode_ppk
        return reverse('peach3-core:submission.download_file',
                       args=[base32_encode_ppk(self.get_private_pk()), urlquote_plus(self.name)])

    def get_print_url(self):
        from peach3.utils.ppk import base32_encode_ppk
        if self.file.filetype.binary_content:
            # Binary content cannot be printed
            return None
        return reverse('peach3-core:submission.print_file',
                       args=[base32_encode_ppk(self.get_private_pk()), urlquote_plus(self.name)])

    get_absolute_url = get_download_url

    def has_access(self, user):
        return self.submission.has_access(user)

@dispatch.receiver(post_delete, sender=SubmissionFile)
def submissionfile_deleted(sender, instance, **kwargs): #pylint: disable=W0613
    if instance.file.submissionfile_set.count()==0:
        try:
            instance.file.delete(False)
        except FileAccessDeniedError:
            pass

@dispatch.receiver(cleanup_signal)
def submit_unfinished(sender=None, **kwargs): #pylint: disable=W0613
    """ Find unfinished submissions for assignments that have closed
        (more than 15 minutes ago) and submit them if there are any
        files, otherwise delete the submission.
    """
    cnow = now()
    stamp = cnow-timedelta(minutes=15)

    for sb in Submission.objects.filter(created__lt=stamp,
                                        submitted__isnull=True):
        ae = sb.assignmentedition

        deadline = TimeRange(closed=True)
        for au in sb.get_authors():
            deadline += ae.get_open_timerange(au)

        if deadline.is_after(stamp):
            if sb.submissionfile_set.count()==0:
                sb.delete()
            else:
                if deadline.has_end():
                    d = deadline.end
                else:
                    d = cnow

                sb.submit(d, None)
