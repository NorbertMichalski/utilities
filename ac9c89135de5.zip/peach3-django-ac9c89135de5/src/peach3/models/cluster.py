from django.conf import settings
from django.core.cache import cache
from django.core.exceptions import ValidationError
from django.contrib.auth import get_user_model
from django.db import models, transaction
from django.db.models.signals import post_save
from django.dispatch import receiver
from django.utils.translation import ugettext as _, ugettext_lazy

from peach3.models.fields import ClusterStaffLevelField
from peach3.models.i18n import I18NMixin
from peach3.models.mixins import OrderMixin
from peach3.models.realm import Realm
from peach3.models import APP_LABEL

from peach3.managers.cluster import ClusterManager

from peach3.utils.cache import cache_key, unique_cache_hash
from peach3.utils.dates import TimeRange
from peach3.utils.decorators import skip_raw_save
from peach3.utils.ppk import PPKModelMixin, PPKManager

__all__ = ('Cluster', 'ClusterMember', 'ClusterStaff',)

# Create your models here.

class Cluster(models.Model, I18NMixin, OrderMixin, PPKModelMixin): #pylint: disable=R0904
    ### Model definition
    courseedition = models.ForeignKey("CourseEdition")

    _joinable_from = models.DateTimeField(null=True, blank=True, db_column='joinable_from')
    _joinable_until = models.DateTimeField(null=True, blank=True, db_column='joinable_until')

    _active_from = models.DateTimeField(null=True, blank=True, db_column='active_from')
    _active_until = models.DateTimeField(null=True, blank=True, db_column='active_until')

    subcodes = models.ManyToManyField("SubCode", null=True, blank=True)
    realms = models.ManyToManyField(Realm, null=True, blank=True)

    admin_cluster = models.BooleanField(default=False)
    test_cluster = models.BooleanField(default=False,
                                       help_text=ugettext_lazy("This cluster is used exclusively for testing purposes"))

    default_name = models.CharField(max_length=100, blank=True, unique=False)
    default_language = models.CharField(max_length=16,
                                        choices=I18NMixin.LANGUAGE_CHOICES,
                                        default=I18NMixin.LANGUAGE_DEFAULT)

    order = models.PositiveIntegerField(null=True, blank=True)

    objects = ClusterManager()

    class Meta: #pylint: disable=W0232,C0111,R0903
        app_label = APP_LABEL
        unique_together = (('courseedition', 'default_name',),
                          )
        ordering = 'courseedition', 'order', 'default_name'

    def clean(self):
        # If order is not set, set it to the maximum order + 1
        if self.order is None:
            m = self.courseedition.cluster_set.aggregate(models.Max('order'))['order__max']
            self.order = (m or 0)+1

        # Validate constraints
        if self.admin_cluster:
            if self.realms.count()>0:
                raise ValidationError, _("Realm not allowed for an admin cluster")

            if self.courseedition.cluster_set.exclude(pk=self.pk).filter(admin_cluster=True).count()>0:
                raise ValidationError, _("There already exists an admin cluster for this courseedition")

        else:
            # Validate selected subcodes
            if self.courseedition.cluster_set.filter(admin_cluster=True).count()==0:
                raise ValidationError, _("There should be at least one admin cluster for this courseedition")

    # Cache helpers
    def _get_cachekey(self, *args):
        key = cache_key('peach3.models.Cluster', self, 'key')
        course_cache_hash = unique_cache_hash(key, self)
        return cache_key('peach3.models.Cluster', self, 'info', course_cache_hash, *args)

    def _del_cachekey(self):
        key = cache_key('peach3.models.Cluster', self, 'key')
        cache.delete(key)

    def _get_user_cachekey(self, user, *args):
        key = self._get_cachekey('user_key', user)
        user_cache_hash = unique_cache_hash(key, user)
        return cache_key('peach3.models.Cluster', self, 'userinfo', user, user_cache_hash, *args)

    def _del_user_cachekey(self, user):
        key = self._get_cachekey('user_key', user)
        cache.delete(key)

    def flush_cache(self):
        self._del_cachekey()

    def save(self, *args, **kwargs):
        super(Cluster, self).save(*args, **kwargs)

        # Update admin cluster of same courseedition if active range has changed
        if not self.admin_cluster and getattr(self, '_active_updated', False):
            self._active_updated = False
            self._update_admincluster_active()

    def delete(self, *args, **kwargs):
        self.flush_cache()
        super(Cluster, self).delete(*args, **kwargs)

    # methods
    def _update_admincluster_active(self):
        " Set the active range for the admincluster to the sum of the ranges for the other clusters "
        acl = self.courseedition.get_admin_cluster()
        if acl:
            acl.active_range = Cluster.objects.get_aggregated_active(courseedition=self.courseedition,
                                                                     admin_cluster=False)
            acl.save(update_fields=['_active_from', '_active_until'])

    ### Model methods
    def set_joinable_range(self, rng):
        self._joinable_from = rng.begin
        self._joinable_until = rng.end
    set_joinable_range.alters_data=True

    def get_joinable_range(self):
        return TimeRange(begin=self._joinable_from, end=self._joinable_until)

    joinable_range = property(get_joinable_range, set_joinable_range)

    def is_joinable(self, when=None):
        return not self.test_cluster and when in self.joinable_range

    def set_active_range(self, rng):
        self._active_from = rng.begin
        self._active_until = rng.end
        self._active_updated = True #pylint: disable=W0201
    set_active_range.alters_data=True

    def get_active_range(self):
        return TimeRange(begin=self._active_from, end=self._active_until)

    active_range = property(get_active_range, set_active_range)

    def is_active(self, user=None, when=None):
        if user and self.clustermember_set.filter(user=user)\
                        .exclude(removed=ClusterMember.SOURCE_NONE).exists():
            # User was removed
            return False

        return when in self.active_range

    def is_member(self, user):
        return self.clustermember_set.filter(user=user).count()>0

    def add_member(self, source, user, realm, subcode=None):
        assert not self.is_member(user)

        if self.admin_cluster:
            assert realm is None
        else:
            assert realm is not None

        self.clustermember_set.create(realm=realm, user=user, subcode=subcode, source=source)

        self.flush_cache()
        self.courseedition.flush_cache()

    def remove_member(self, user, deactivate=None):
        clm = self.clustermember_set.get(user=user)

        if self.courseedition.submission_set.filter(authors=user).exists():
            # This user has done work, only deactivate
            if deactivate is None:
                return False

            clm.removed = deactivate
            clm.save(update_fields=['removed'])
        else:
            clm.delete()

        self.flush_cache()
        self.courseedition.flush_cache()
        return True

    def move_member(self, user, cluster, realm, subcode=None, source=None):
        assert self.is_member(user)

        if self.admin_cluster:
            assert realm is None
        else:
            assert realm is not None

        clm = self.clustermember_set.get(user=user)
        clm.cluster = cluster
        clm.realm = realm
        if subcode:
            clm.subcode = subcode
        if source:
            clm.source = source
        clm.removed = ClusterMember.SOURCE_NONE
        clm.save()

        self.flush_cache()
        cluster.flush_cache()
        self.courseedition.flush_cache()

    def get_staff(self, user):
        key = self._get_user_cachekey(user, 'staff')

        cached = cache.get(key)
        if cached is None:
            try:
                staff = self.clusterstaff_set.get(user=user)
            except self.clusterstaff_set.model.DoesNotExist:
                staff = None

            cache.set(key, (staff,))
        else:
            staff = cached[0]

        return staff

    @transaction.commit_on_success
    def set_staff(self, user, role, level, extend_deadline):
        options = dict(
            role = role,
            level = level,
            extend_deadline = extend_deadline,
        )

        staff, created = self.clusterstaff_set.get_or_create(user=user, defaults=options)
        if not created:
            for k, v in options.iteritems():
                setattr(staff, k, v)
            staff.save()

        self.courseedition.flush_cache()
        self.flush_cache()

    @transaction.commit_on_success
    def delete_staff(self, user):
        # Delete this staff member

        self.clusterstaff_set.filter(user=user).delete()
        self.courseedition.flush_cache()
        self.flush_cache()

    @transaction.commit_on_success
    def set_all_staff(self, values):
        # Takes an array user.pk => { role, level, extend_deadline } and updates the ClusterStaff table
        user_ids = values.keys()
        ce = self.courseedition

        managers = self.courseedition.get_managers()

        # Remove deleted users (but never remove managers)
        removed = self.clusterstaff_set.exclude(user__in=user_ids).exclude(user__in=managers)
        removed_users = [staff.user for staff in removed]
        removed.delete()

        # If removed users are not staff in other clusters,
        # remove from admin cluster
        for user in removed_users:
            if not (ce.is_staff(user)):
                ce.remove_from_admincluster(user)

        # Get all user records
        users = dict((user.id, user) for user in get_user_model().objects.filter(id__in=user_ids))

        # Update/add staff
        for user_id, options in values.iteritems():
            user = users[user_id]

            ce.add_to_admincluster(user)

            staff, created = self.clusterstaff_set.get_or_create(user=user, defaults=options)
            if not created:
                for k, v in options.iteritems():
                    setattr(staff, k, v)
                staff.save()

        self.courseedition.flush_cache()
        self.flush_cache()

    def can_extend_deadline(self, user):
        if user.is_superuser:
            return True

        staff = self.get_staff(user)
        if staff:
            return staff.extend_deadline

        return False

    def get_observelevel(self, user):
        if user.is_superuser:
            return 99

        staff = self.get_staff(user)
        if staff:
            return staff.level

        return None

    def is_observer(self, user):
        return self.get_observelevel(user) is not None

    def get_reviewlevel(self, user):
        staff = self.get_staff(user)
        if staff and staff.role==ClusterStaff.ROLE_REVIEW:
            return staff.level

        return None

    def is_reviewer(self, user):
        return self.get_reviewlevel(user) is not None

    def get_members(self):
        return (cm.user for cm in self.clustermember_set.all())

    def get_member_subcode(self, user):
        try:
            clm = self.clustermember_set.get(user=user)
        except self.clustermember_set.model.DoesNotExist:
            return None
        else:
            return clm.subcode

    def get_size(self):
        return self.clustermember_set.count()

    ### News Interface
    def get_news_text(self, newsitem):
        t = newsitem.msgtype

        if t in ['joined', 'left']:
            if ' #' in newsitem.msgparam:
                username, userid = newsitem.msgparam.split(' #', 1)
            else:
                username, userid = newsitem.msgparam, None

            User = get_user_model()
            try:
                if userid:
                    user = User.objects.get(pk=userid)
                else:
                    user = User.objects.get(username=username)

            except User.DoesNotExist:
                user = None

            info = {
                'cluster':self.name,
                'username':username,
                'fullname':user.get_full_name_formal() if user else username,
                'courseedition':self.courseedition.get_display_name(),
            }

            if t=='joined':
                return (
                    _("%(fullname)s joined cluster '%(cluster)s'") % info,
                    _("%(fullname)s (%(username)s) joined cluster '%(cluster)s' of course '%(courseedition)s'") % info,
                )
            else:
                return (
                    _("%(fullname)s left cluster '%(cluster)s'") % info,
                    _("%(fullname)s (%(username)s) left cluster '%(cluster)s' of course '%(courseedition)s'") % info,
                )

        raise ValueError

    ### Naming interface
    def get_display_name(self, lang=None):
        name = self.get_name(lang)
        if name:
            return u'%s %s' % (self.courseedition.get_display_name(), name)
        else:
            return self.courseedition.get_display_name()

#    ### Permission Interface
#    def _get_permissions(self, user):
#        return ( user.get_model_permissions(self)
#               | self.courseedition.get_permissions(user)
##               | frozenset('%(app_label)s.%(codename)s'
##                           for perm in self.permissions.values('app_label', 'codename')
##                          )
#               )
#
    def has_access(self, user, access=None):
        if user.is_superuser:
            return True
        elif user.is_anonymous():
            return False

        is_observer = self.get_observelevel(user) is not None
        if access=='observe':
            return is_observer

        is_reviewer = self.get_reviewlevel(user) is not None
        if access=='review':
            return is_reviewer

        return access is None and (is_observer or is_reviewer or self.is_member(user))

class ClusterMember(models.Model, PPKModelMixin):
    class SourceChoicesHelper(object):
        " Helper class to allow SOURCE_CHOICES to be extended by plugins "
        def __init__(self, *initial):
            self.choices = list(initial)

        def append(self, key, name):
            self.choices.append((key, name))

        def __iter__(self):
            return iter(self.choices)

    SOURCE_NONE = ''
    SOURCE_USER = 'user'
    SOURCE_STAFF = 'staff'

    SOURCE_CHOICES = SourceChoicesHelper(
        (SOURCE_USER, ugettext_lazy("User")),
        (SOURCE_STAFF, ugettext_lazy("Staff")),
    )

    ### Model definition
    cluster = models.ForeignKey(Cluster)
    realm = models.ForeignKey(Realm, null=True, blank=True)
    subcode = models.ForeignKey("SubCode", null=True, blank=True)
    user = models.ForeignKey(settings.AUTH_USER_MODEL)
    favorite = models.BooleanField(default=True)
    source = models.CharField(max_length=10, choices=SOURCE_CHOICES, default=SOURCE_NONE, blank=True)
    removed = models.CharField(max_length=10, choices=SOURCE_CHOICES, default=SOURCE_NONE, blank=True)

    objects = PPKManager()

    class Meta: #pylint: disable=W0232,C0111,R0903
        app_label = APP_LABEL
        unique_together = ('cluster', 'user')
        index_together = [
            ('cluster', 'user'),
        ]
        ordering = 'cluster', 'user'

    def clean(self):
        if not self.cluster.admin_cluster and\
                 ClusterStaff.objects.filter(cluster=self.cluster, user=self.user).count()>0:
            raise ValidationError(_("This user is already added as staff"))

        if self.cluster.admin_cluster:
            self.realm = None
        elif self.realm is None:
            raise ValidationError(_("Realm is required"))

        valid_subcodes = self.cluster.courseedition.subcode_set.all()
        if valid_subcodes and self.subcode not in valid_subcodes:
            raise ValidationError(_("Invalid sub-course"))

    # Options

#    def _get_option(self, optioncode):
#        key = cache_key('peach3.models.ClusterMember', self, 'option', optioncode)
#
#        result = cache.get(key)
#        if result is None:
#            try:
#                option = self.clustermemberoption_set.get(option=optioncode)
#                result = True, parse_parameters(option.parameters)
#            except self.clustermemberoption_set.model.DoesNotExist:
#                result = False, {}
#
#            cache.set(key, result)
#
#        return result
#
#    def has_option(self, optioncode):
#        return self._get_option(optioncode)[0]
#
#    def get_option(self, optioncode):
#        return self._get_option(optioncode)[1]
#
#    def set_option(self, optioncode, **kwargs):
#        key = cache_key('peach3.models.ClusterMember', self, 'option', optioncode)
#        cache.delete(key)
#
#        parameters="\n".join((key if value is True else '%s=%s' % (key, value)) for key, value in kwargs.iteritems())
#
#        obj, created = AssignmentEditionOption.objects.get_or_create(assignmentedition=self,
#                                                                     option=optioncode,
#                                                                     defaults={'parameters':parameters})
#        if not created:
#            obj.parameters = parameters
#            obj.save()
#
#    def delete_option(self, optioncode):
#        key = cache_key('peach3.models.ClusterMember', self, 'option', optioncode)
#        cache.delete(key)
#
#        AssignmentEditionOption.objects.filter(assignmentedition=self,
#                                               option=optioncode).delete()
#
#
#    def has_option_parameter(self, optioncode, key):
#        return key in self.get_option(optioncode)
#
#    def get_option_parameter(self, optioncode, key, default=None):
#        return self.get_option(optioncode).get(key, default)
#
#    def set_option_parameter(self, optioncode, key, value):
#        option = self.get_option(optioncode)
#        option[key] = value
#        self.set_option(optioncode, **option)
#
#    def delete_option_parameter(self, optioncode, key):
#        option = self.get_option(optioncode)
#        del option[key]
#        self.set_option(optioncode, **option)

#    ### Permission Interface
#    class ModelPermissions:
#        inherit_permissions = ('cluster',)
#        has_access = ('user',)
#
#    def _get_permissions(self, user):
#        return ( user.get_model_permissions(self)
#               | self.cluster.get_permissions(user)
#               )
#
    def has_access(self, user, access=None):
        return access is None and user==self.user

    ### Naming interface
    def __unicode__(self):
        return _("Member")+' '+unicode(self.user)

class ClusterStaff(models.Model, PPKModelMixin):
    ROLE_REVIEW = 'REVIEW'
    ROLE_OBSERVE = 'OBSERVE'

    ROLES = (
        (ROLE_OBSERVE, _("Observe")),
        (ROLE_REVIEW, _("Review")),
    )

    MANAGER_VALUES = {
        'role': ROLE_REVIEW,
        'level': 10,
        'extend_deadline' : True,
    }

    cluster = models.ForeignKey(Cluster)
    user = models.ForeignKey(settings.AUTH_USER_MODEL)

    role = models.CharField(max_length=8, choices=ROLES)
    level = ClusterStaffLevelField()
    extend_deadline = models.BooleanField()

    objects = PPKManager()

    class Meta: #pylint: disable=W0232,C0111,R0903
        app_label = APP_LABEL
        unique_together = ('cluster', 'user')
        index_together = [
            ('cluster', 'user'),
        ]

    def __is_manager(self):
        return self.cluster.courseedition.is_manager(self.user)

    def clean(self):
        if self.cluster.admin_cluster:
            raise ValidationError(_("Admin cluster can't have staff"))

        if not self.cluster.admin_cluster and\
                 ClusterMember.objects.filter(cluster=self.cluster, user=self.user).count()>0:
            raise ValidationError(_("This user is already added as a member"))

        if self.__is_manager():
            # Force values for Managers
            for key, value in self.MANAGER_VALUES.iteritems():
                setattr(self, key, value)

    def __unicode__(self):
        if self.__is_manager():
            output = [_("Manager")]

        else:
            output = [_("Level %d") % self.level]
            if self.role==ClusterStaff.ROLE_REVIEW:
                output.append(_("reviewer"))
            else:
                output.append(_("observer"))

        output.append(unicode(self.user))

        return ' '.join(output)

@receiver(post_save, sender=ClusterStaff)
@skip_raw_save
def staff_saved(instance, created, **kwargs): #pylint: disable=W0613
    instance.cluster.flush_cache()
