from django.contrib.contenttypes.models import ContentType
from django.contrib.contenttypes import generic

from django.db import models

# Create your models here.

from peach3.core.signals import cleanup_signal
from peach3.models import APP_LABEL
from peach3.managers.pdf import RefPDFInfoManager

from pdfviewer.models import PDFInfo

__all__ = ('RefPDFInfo',)

class RefPDFInfo(PDFInfo):
    " A PDFInfo with reference to another object "
    ref_ct = models.ForeignKey(ContentType, blank=True, null=True)
    ref_id = models.PositiveIntegerField(blank=True, null=True)
    ref = generic.GenericForeignKey('ref_ct', 'ref_id')

    objects = RefPDFInfoManager()

    class Meta: #pylint: disable=W0232,C0111,R0903
        app_label = APP_LABEL
        unique_together = ('ref_ct', 'ref_id')
        index_together = [
            ('ref_ct', 'ref_id'),
        ]

def cleanup_pdf(sender, **kwargs):#pylint: disable=W0613
    from pdfviewer.management.commands.clean_pdf import do_clean_pdf

    # Clean pdf db entries after 4 weeks, clean cached pages after 2 weeks
    do_clean_pdf(4*7*24*3600, 2*7*24*3600)

cleanup_signal.connect(cleanup_pdf)
