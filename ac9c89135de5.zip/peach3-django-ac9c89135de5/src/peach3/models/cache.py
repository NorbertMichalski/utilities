from django.db import models
from django.db.models.signals import pre_delete
from django.dispatch import receiver
from django.utils.timezone import now

from peach3.core.storage.cache import cachestorage

__all__ = ('CachedFileModel', 'CachedImageModel')

class CachedObjectModel(models.Model):
    created = models.DateTimeField(default=now)
    last_access = models.DateTimeField(default=now)

    def touch(self, date=None, save=True):
        self.last_access = date or now()
        if save:
            self.save(update_fields=['last_access'])
    touch.alters_data = True

    def is_expired(self, when):
        raise NotImplementedError

    class Meta: #pylint: disable=W0232,C0111,R0903
        abstract = True

class CachedFileModel(CachedObjectModel): #pylint: disable=W0223
    file = models.FileField(upload_to=cachestorage.upload_path, #@ReservedAssignment
                            storage=cachestorage,
                            max_length=300, blank=True, null=True)

    class Meta: #pylint: disable=W0232,C0111,R0903
        abstract = True

class CachedImageModel(CachedObjectModel): #pylint: disable=W0223
    image = models.ImageField(upload_to=cachestorage.upload_path,
                              storage=cachestorage,
                              max_length=300, blank=True, null=True,
                              width_field='width',
                              height_field='height')

    width = models.PositiveIntegerField(blank=True, null=True)
    height = models.PositiveIntegerField(blank=True, null=True)

    class Meta: #pylint: disable=W0232,C0111,R0903
        abstract = True

@receiver(pre_delete)
def delete_object(instance, sender, **kwargs): #pylint: disable=W0613
    if issubclass(sender, CachedFileModel):
        if instance.file.name:
            instance.file.delete(save=False)
    elif issubclass(sender, CachedImageModel):
        if instance.image.name:
            instance.image.delete(save=False)
