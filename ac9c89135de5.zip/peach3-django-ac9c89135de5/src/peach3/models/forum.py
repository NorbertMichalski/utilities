""" This file is part of PEACH.

    Copyright (C) 2006-2009 Eindhoven University of Technology
"""
from django.conf import settings
from django.contrib.contenttypes.models import ContentType
from django.contrib.contenttypes import generic

from django.utils.timezone import now
from django.utils.translation import ugettext_lazy as _
from django.utils.html import escape, linebreaks

from peach3.models import APP_LABEL
from peach3.utils.ppk import PPKModelMixin, PPKManager
from peach3.utils.rst import rst2html

from django.db import models

__all__ = ('Comment', 'CommentRevision',)

class Comment(models.Model, PPKModelMixin):
    parent_content_type = models.ForeignKey(ContentType)
    parent_id = models.PositiveIntegerField()
    parent = generic.GenericForeignKey('parent_content_type', 'parent_id')

    author = models.ForeignKey(settings.AUTH_USER_MODEL)
    created = models.DateTimeField(default=now)

    response_to = models.ForeignKey('self', related_name='response_set', null=True, blank=True)

    objects = PPKManager()

    class Meta: #pylint: disable=W0232,C0111,R0903
        app_label = APP_LABEL
        get_latest_by = 'created'
        index_together = [
            ('parent_content_type', 'parent_id'),
        ]

    def get_content(self):
        try:
            return self.commentrevision_set.latest()
        except self.commentrevision_set.model.DoesNotExist:
            return None

    def get_header(self):
        c = self.get_content()
        return c.header if c else None
    header = property(get_header)

    def get_message(self):
        c = self.get_content()
        return c.message if c else None
    message = property(get_message)

    def get_formatted(self, *args, **kwargs):
        c = self.get_content()
        return c.get_formatted(*args, **kwargs) if c else None

    def get_last_modified(self):
        c = self.get_content()
        return (c.author, c.created) if c else (None, None)
    last_modified = property(get_last_modified)

    def __unicode__(self):
        return _(u'Comment by %(author)r for %(parent)r') % {'author':self.author, 'parent':self.parent}

MARKUP_CHOICES = (
    ('plain', _("Plain text")),
    ('rst'  , _("Restructured text")),
)

class CommentRevision(models.Model, PPKModelMixin):
    comment = models.ForeignKey(Comment, db_index=True)

    author = models.ForeignKey(settings.AUTH_USER_MODEL)
    created = models.DateTimeField(default=now)

    header = models.CharField(max_length=255, blank=True)
    markup = models.CharField(max_length=8, choices=MARKUP_CHOICES, default=MARKUP_CHOICES[0][0])
    message = models.TextField(blank=True)

    objects = PPKManager()

    class Meta: #pylint: disable=W0232,C0111,R0903
        app_label = APP_LABEL
        get_latest_by = 'created'

    def get_formatted(self, *args, **kwargs):
        if self.markup=='plain':
            return '<div class="document">'+linebreaks(escape(self.message))+'</div>'
        else:
            return rst2html(self.message, *args, **kwargs)['html_body']
