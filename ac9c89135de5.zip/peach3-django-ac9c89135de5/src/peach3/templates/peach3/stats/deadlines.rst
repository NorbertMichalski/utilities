Upcoming deadlines
==================
{% for item in data %}
{{ item.0 }}
{% for line in item.1 %} * {{ line }}
{% endfor %}{% endfor %}
