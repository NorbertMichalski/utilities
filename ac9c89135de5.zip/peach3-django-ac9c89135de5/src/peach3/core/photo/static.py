from django.contrib.staticfiles.storage import staticfiles_storage

from peach3.core.photo import Photo

class StaticPhoto(Photo):
    static_url = None

    @property
    def url(self):
        if StaticPhoto.static_url is None:
            StaticPhoto.static_url = staticfiles_storage.url('peach3/img/unknown_user.png')
        return self.static_url

    @property
    def height(self):
        return int(self.width*1.2)
