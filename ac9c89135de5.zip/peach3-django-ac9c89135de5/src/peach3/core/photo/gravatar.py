from django.conf import settings
from django.core.cache import cache
from django.utils import http

from peach3.core.photo import Photo

import urlparse
import hashlib

class GravatarPhoto(Photo):
    GRAVATAR_IMAGE_URL = None
    GRAVATAR_DEFAULT = None
    GRAVATAR_EXT = None

    def __init__(self, user, width):
        super(GravatarPhoto, self).__init__(user, width)
        self._url = None

    def _gravatar_hash(self, user): #pylint: disable=R0201
        email = user.email.encode('utf-8').strip().lower()
        key = 'gravatar:%s' % email
        hsh = cache.get(key)
        if hsh is None:
            hsh = hashlib.md5(email).hexdigest()
            cache.set(key, hsh)
        return hsh

    @property
    def url(self):
        if GravatarPhoto.GRAVATAR_IMAGE_URL is None:
            GravatarPhoto.GRAVATAR_IMAGE_URL = getattr(settings, 'GRAVATAR_IMAGE_URL', 'http://gravatar.com/avatar/')
            GravatarPhoto.GRAVATAR_DEFAULT = getattr(settings, 'GRAVATAR_DEFAULT', 'mm')
            GravatarPhoto.GRAVATAR_EXT = getattr(settings, 'GRAVATAR_EXT', 'jpg')

        if self._url is None:
            param = []

            if self.width:
                param.append(('s', self.width,))

            if self.GRAVATAR_DEFAULT:
                param.append(('d', self.GRAVATAR_DEFAULT,))

            if self.GRAVATAR_EXT:
                ext = '.'+self.GRAVATAR_EXT
            else:
                ext = ''

            url = urlparse.urljoin(self.GRAVATAR_IMAGE_URL, self._gravatar_hash(self.user)+ext)
            if param:
                url += '?'+http.urlencode(param)

            self._url = url

        return self._url

    @property
    def height(self):
        return None
