from django.conf import settings
from django.core.cache import cache
from django.core.exceptions import ImproperlyConfigured
from django.utils import http
from django.utils.importlib import import_module

class Photo(object): #pylint: disable=R0921
    def __init__(self, user, width):
        self.user = user
        self.width = width

    @property
    def url(self):
        raise NotImplementedError

    @property
    def height(self):
        raise NotImplementedError

def get_photo_class(backend=None, **kwds): #pylint: disable=W0613
    path = backend or getattr(settings, 'PHOTO_CLASS', 'peach3.core.photo.static.StaticPhoto')
    try:
        mod_name, klass_name = path.rsplit('.', 1)
        mod = import_module(mod_name)
    except ImportError, e:
        raise ImproperlyConfigured(('Error importing photo backend module %s: "%s"'
                                    % (mod_name, e)))
    try:
        klass = getattr(mod, klass_name)
    except AttributeError:
        raise ImproperlyConfigured(('Module "%s" does not define a '
                                    '"%s" class' % (mod_name, klass_name)))

    return klass
