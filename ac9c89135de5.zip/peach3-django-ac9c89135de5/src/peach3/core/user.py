from django.conf import settings
from django.core.exceptions import ImproperlyConfigured

def load_name_converter(path):
    i = path.rfind('.')
    module, attr = path[:i], path[i+1:]
    try:
        mod = __import__(module, {}, {}, [attr])
    except ImportError, e:
        raise ImproperlyConfigured, 'Error importing name converter %s: "%s"' % (module, e)
    try:
        cls = getattr(mod, attr)
    except AttributeError:
        raise ImproperlyConfigured, 'Module "%s" does not define a "%s" name converter' % (module, attr)
    return cls()

def get_name_converters():
    converters = []
    for converter_path in settings.USER_NAME_CONVERTERS:
        converters.append(load_name_converter(converter_path))
    return converters

class AlternativeNames(object):
    def __new__(cls):
        if not hasattr(cls, 'converters'):
            cls.converters = get_name_converters()
        return object.__new__(cls)

    def get_alternative_names(self, name, fetch=True):
        result = []
        for c in self.converters:
            result.extend(c.get_alternative_names(name, fetch))
        return result

    def get_usernames_from_alternative(self, name, fetch=True):
        result = []
        for c in self.converters:
            result.extend(c.get_usernames_from_alternative(name, fetch))
        return None
