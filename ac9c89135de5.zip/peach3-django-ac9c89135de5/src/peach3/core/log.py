
class ActivityLogger(object):
    def __init__(self):
        self.logger = None

    def connect(self, logger=None):
        import logging
        from peach3.core.signals import activity

        if self.logger is None:
            if logger is None:
                logger = 'peach3.activity'

            if isinstance(logger, basestring):
                logger = logging.getLogger(logger)

            self.logger = logger

            activity.connect(self.log, dispatch_uid='peach3.log.activity')

            self.logger.debug('Activity logger connected')

    def log(self, sender, code, user, course, cluster, assignment, parameters, **kwargs): #pylint: disable=W0613
        from peach3.core.activity import ActivityCode
        from django.utils.encoding import smart_str

        s = []
        if user:
            s.append(('user', user.username))

        if course:
            s.append(('course', course.code))

        if cluster:
            s.append(('cluster', cluster.default_name))

        if assignment:
            s.append(('assignment', assignment.default_name))

        s.extend(parameters.items())

        self.logger.info(u'%s: %s' %
                         (smart_str(ActivityCode.get_text(code)),
                          ', '.join(u'%s=%s'%(key,smart_str(value)) for key,value in s))
                        )

activity_logger = ActivityLogger() #pylint: disable=C0103

def install_activity_logger(logger=None):
    activity_logger.connect(logger)
