""" This file is part of PEACH.

    Copyright (C) 2006-2009 Eindhoven University of Technology
    Copyright (C) 2009 Eljakim Information Technology bv.
"""

def get_scores(ce, user):
    ordered_aes = get_assignments(ce, user)
    assignmentSets = {}
    for ae in ordered_aes:
        if ae.assignmentset:
            aset = ae.assignmentset
            if not aset.id in assignmentSets:
                assignmentSets[aset.id] = aset

    scores = []
    for cl in ce.get_clusters():
        if cl.get_observelevel(user)>0:
            clname = cl.name
            for au in cl.get_members():
                # Load all submissions by this user, group them on the assignment
                subs = {}
                for sb in ce.submission_set.filter(authors=au).order_by('created'):
                    saeid = sb.assignmentedition_id
                    if saeid in subs:
                        subs[saeid].append(sb)
                    else:
                        subs[saeid]=[sb]

                auinfo = {
                    'auid'          : au.id,
                    'cluster'       : clname,
                    'user'          : au.username,
                    'name'          : au.get_full_name_sortable(),
                }

                score = 0
                # add scores for individual assignments
                for ae in ordered_aes:
                    if ae.id in subs:
                        aescore = get_score(ae, subs[ae.id], user)
                        if aescore != None:
                            auinfo["score%d" % ae.id] = aescore
                            score += aescore
                    else:
                        auinfo["score%d" % ae.id] = ''
                # add scores for assignment sets
                for asetid in assignmentSets:
                    aset = assignmentSets[asetid]
                    asscore = 0
                    hasScores = False
                    for ae in ordered_aes:
                        if ae.id in subs and ae.assignmentset == aset:
                            aescore = get_score(ae, subs[ae.id], user)
                            if aescore != None:
                                asscore += aescore
                                hasScores = True
                    if hasScores:
                        auinfo["scoreset%d" % asetid] = asscore
                    else:
                        auinfo["scoreset%d" % asetid] = ''

                auinfo["score"] = score

                scores.append(auinfo)

    scores.sort(cmp=lambda s, t:cmp(t['score'], s['score']))
    rank = 1
    lastScore = None
    lastRank = 0
    for s in scores:
        if lastScore == s['score']:
            s['rank'] = lastRank
        else:
            s['rank'] = rank
            lastRank = rank
        lastScore = s['score']
        rank = rank + 1

    return scores

# returns the score for an assignment, given the list of submissions for that assignment
def get_score(ae, subs, user):
    score = None
    for s in reversed(subs):
        if s.get_state(user) == 'ACCEPTED':
            score = s.get_score(user)
            break
    return score

# copied from course/ajax.py
def get_assignments(ce, user, author=None):
    # Load and order assignments
    return [ae for ae in ce.assignmentedition_set.all().order_by('order') if ae.is_visible(user)]

def get_assignmentsets(aes):
    assignmentSets = {}
    for ae in aes:
        if ae.assignmentset:
            aset = ae.assignmentset
            if not aset.id in assignmentSets:
                assignmentSets[aset.id] = aset
    return assignmentSets.values()
