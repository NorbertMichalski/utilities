from django.utils.encoding import smart_unicode
from django.utils.translation import ugettext_lazy, ugettext as _

from peach3.core.validator import SimpleFileValidator, BaseFileValidator

class TextValidator(SimpleFileValidator):
    NAME = "Text"
    ERROR = ugettext_lazy("Not a text file")

    def _match(self, fileobj, assignmentedition): #pylint: disable=W0613
        for block in fileobj.chunks():
            if not block:
                return True
            elif '\0' in block: #pylint: disable=W1401
                return False

        return True

class TextWithCutmarkValidator(BaseFileValidator):
    NAME = "Text with cutmark"

    def validate(self, fileobj, assignmentedition):
        cutmark = None
        if assignmentedition:
            params = assignmentedition.get_option('scrub')
            if params and params.get('required', False):
                cutmark = params.get('cutmark')

        cutmark_found = not cutmark # Empty cutmark is always found

        fileobj.open('rU')
        for line in fileobj.readlines():
            if '\0' in line: #pylint: disable=W1401
                return False, _("Not a text file")

            line = smart_unicode(line, errors='replace')
            if not cutmark_found and cutmark in line:
                cutmark_found = True

        if not cutmark_found:
            return False, _("No (valid) cutline marker found")

        return True, ''
