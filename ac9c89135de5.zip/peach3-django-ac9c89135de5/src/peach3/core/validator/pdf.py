from django.utils.translation import ugettext_lazy

from peach3.core.validator import SimpleFileValidator

class PDFValidator(SimpleFileValidator):
    NAME = "PDF"
    ERROR = ugettext_lazy("Not a valid PDF file")

    def _match(self, fileobj, assignmentedition): #pylint: disable=W0613
        return fileobj.read(7)=='%PDF-1.'
