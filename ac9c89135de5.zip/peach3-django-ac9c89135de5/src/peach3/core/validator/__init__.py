from django.utils.translation import ugettext_lazy

FILE_VALIDATORS = [
    'peach3.core.validator.pdf.PDFValidator',
    'peach3.core.validator.text.TextValidator',
    'peach3.core.validator.text.TextWithCutmarkValidator',
    'peach3.core.validator.archive.ZipValidator',
]

class BaseFileValidator(object):
    NAME = "Null Validator"

    def __init__(self, **params):
        for key, value in params.iteritems():
            setattr(self, key, value)

    def validate(self, fileobj, assignmentedition): #pylint: disable=R0201,W0613
        " Validate fileobj (a django.core.files.File object) "
        return True, ''

class SimpleFileValidator(BaseFileValidator):
    NAME = "Simple Validator"
    ERROR = ugettext_lazy("File is not in the correct format")

    def _match(self, fileobj, assignmentedition): #pylint: disable=R0201,W0613
        return True

    def validate(self, fileobj, assignmentedition):
        fileobj.open('r')

        if self._match(fileobj, assignmentedition):
            return True, ''

        return False, self.ERROR
