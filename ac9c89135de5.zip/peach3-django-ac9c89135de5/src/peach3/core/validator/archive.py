from django.utils.translation import ugettext as _

from peach3.core.validator import BaseFileValidator

class ZipValidator(BaseFileValidator):
    NAME = "Zip"

    def validate(self, fileobj, assignmentedition): #pylint: disable=W0613
        import zipfile

        try:
            with zipfile.ZipFile(fileobj, 'r', allowZip64=True) as zf:
                failed = zf.testzip()
                if failed:
                    return False, _("Zip file broken: file '%s' fails test") % failed

        except zipfile.BadZipfile:
            return False, _("Not a valid zip file")

        return True, ''
