from django.utils.translation import ugettext_lazy as _

_mk_code = lambda x, y: '%s_%s' % (x, y) #pylint: disable=C0103

class ActivityCode(object):
    USER = 'user'
    COURSE = 'course'
    CLUSTER = 'cluster'
    ASSIGNMENT = 'assignment'
    SUBMISSION = 'submission'

    CREATED = 'added'
    DELETED = 'deleted'
    CHANGED = 'changed'
    LOGIN = 'login'
    LOGOUT = 'logout'

    USER_CREATED = _mk_code(USER, CREATED)
    USER_DELETED = _mk_code(USER, DELETED)
    USER_CHANGED = _mk_code(USER, CHANGED)
    USER_LOGIN = _mk_code(USER, LOGIN)
    USER_LOGOUT = _mk_code(USER, LOGOUT)

    COURSE_CREATED = _mk_code(COURSE, CREATED)
    COURSE_DELETED = _mk_code(COURSE, DELETED)
    COURSE_CHANGED = _mk_code(COURSE, CHANGED)

    CLUSTER_CREATED = _mk_code(CLUSTER, CREATED)
    CLUSTER_DELETED = _mk_code(CLUSTER, DELETED)
    CLUSTER_CHANGED = _mk_code(CLUSTER, CHANGED)

    ASSIGNMENT_CREATED = _mk_code(ASSIGNMENT, CREATED)
    ASSIGNMENT_DELETED = _mk_code(ASSIGNMENT, DELETED)
    ASSIGNMENT_CHANGED = _mk_code(ASSIGNMENT, CHANGED)

    SUBMISSION_CREATED = _mk_code(SUBMISSION, CREATED)
    SUBMISSION_DELETED = _mk_code(SUBMISSION, DELETED)
    SUBMISSION_CHANGED = _mk_code(SUBMISSION, CHANGED)

    __TEXT = {
        USER_CREATED: _("User registered"),
        USER_CHANGED: _("User changed"),
        USER_DELETED: _("User deleted"),
        USER_LOGIN: _("User logged in"),
        USER_LOGOUT: _("User logged out"),

        COURSE_CREATED: _("Course created"),
        COURSE_CHANGED: _("Course changed"),
        COURSE_DELETED: _("Course deleted"),

        CLUSTER_CREATED: _("Cluster created"),
        CLUSTER_CHANGED: _("Cluster changed"),
        CLUSTER_DELETED: _("Cluster deleted"),

        ASSIGNMENT_CREATED: _("Assignment created"),
        ASSIGNMENT_CHANGED: _("Assignment changed"),
        ASSIGNMENT_DELETED: _("Assignment deleted"),

        SUBMISSION_CREATED: _("Submission created"),
        SUBMISSION_CHANGED: _("Submission changed"),
        SUBMISSION_DELETED: _("Submission deleted"),
    }

    @classmethod
    def get_text(cls, code):
        return cls.__TEXT.get(code)

    @classmethod
    def created_or_changed(cls, base, created):
        if created:
            return _mk_code(base, cls.CREATED)
        else:
            return _mk_code(base, cls.CHANGED)
