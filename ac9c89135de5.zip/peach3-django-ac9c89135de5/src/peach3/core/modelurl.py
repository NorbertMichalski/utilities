from django.utils.functional import memoize

from threading import local

#pylint: disable=C0103
_absurlmap_cache = {}
_thread_local = local()

def import_absurlmap(name):
    from django.core.urlresolvers import get_mod_func
    from django.utils.importlib import import_module

    mod_name, func_name = get_mod_func(name)
    return getattr(import_module(mod_name), func_name)

import_absurlmap = memoize(import_absurlmap, _absurlmap_cache, 1)

class UnableToResolveModelUrl(Exception):
    pass

def set_absolute_url_map(absurlmap):
    _thread_local.absurlmap = absurlmap

def get_model_absolute_url(o, *args, **kwargs):
    opts = o._meta #pylint: disable=W0212
    key = '%s.%s' % (opts.app_label, opts.module_name)
    absurlmap_name = getattr(_thread_local, 'absurlmap', None)
    if absurlmap_name:
        absurl = import_absurlmap(absurlmap_name).get(key)
        if absurl:
            return absurl(o, *args, **kwargs)

    raise UnableToResolveModelUrl(key)
