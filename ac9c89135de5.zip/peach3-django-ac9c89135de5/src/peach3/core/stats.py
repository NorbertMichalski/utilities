from django.core.exceptions import ObjectDoesNotExist
from peach3.models import ClusterTimeRange, IndividualTimeRange, ClusterMember, PeerReview, SubmissionAuthor, PeerReviewBundle, Submission

from django.template.loader import render_to_string
from django.utils.timezone import now

from datetime import timedelta

def get_deadlines():
    rnow = now()-timedelta(minutes=5)
    LIMIT = 25

    def weave(tr1, tr2):
        left, right = None, None
        tr1 = tr1.__iter__()
        tr2 = tr2.__iter__()

        while True:
            if left is None:
                try:
                    left = tr1.next()
                except StopIteration:
                    if right:
                        yield right
                    for right in tr2:
                        yield right
                    return

            if right is None:
                try:
                    right = tr2.next()
                except StopIteration:
                    if left:
                        yield left
                    for left in tr1:
                        yield left
                    return

            if left._end < right._end:
                yield left
                left = None
            else:
                yield right
                right = None

    cluster_timeranges = ClusterTimeRange.objects.filter(type='o',
                                                         _end__isnull=False,
                                                         _end__gt=rnow)\
                                                 .order_by('_end')

    individual_timeranges = IndividualTimeRange.objects.filter(type='o',
                                                            _end__isnull=False,
                                                            _end__gt=rnow)\
                                                    .order_by('_end')

    deadlines = []

    count=0
    last_deadline = None
    for cltr in weave(cluster_timeranges, individual_timeranges):
        until = cltr._end
        if until==last_deadline:
            item = deadlines.pop()
        else:
            if len(deadlines)>LIMIT:
                break

            item = [until, {}]

        if hasattr(cltr, 'cluster'):
            count = cltr.cluster.get_size()
        else:
            count = 1

        ae = cltr.assignmentedition
        if cltr.assignmentedition in item[1]:
            item[1][ae] += count
        else:
            item[1][ae] = count

        last_deadline = item[0]

        deadlines.append(item)

    data = [
        (time, sorted([
                  ae.courseedition.get_display_name()+': '+ae.get_display_name()+': %s users' % count
                  for ae, count in info.iteritems()
        ])) for time, info in deadlines
    ]

    return render_to_string('peach3/stats/deadlines.rst', {'data':data})


def course_stats(ce):
    """ Generate statistics for a course

    :param ce:
    :return:
    """

    # All staff
    staff_count = ce.get_admin_cluster().clustermember_set.count()

    # All members for normal clusters (i.e. excluding admin and test clusters)
    member_count = ClusterMember.objects.filter(
        cluster__in=ce.cluster_set.filter(admin_cluster = False, test_cluster = False)
    ).count()

    # All assignments
    assignment_count = ce.assignmentedition_set.count()

    # Submissions that are not created for peerreviews
    submission_count = ce.submission_set.filter(
        submissionfile__peerreview__isnull = True
    ).count()

    # All peer reviews
    peerreview_count = PeerReview.objects.filter(
        bundle__assignment__review_assignment__courseedition = ce,
    ).exclude(
        reviewed_by__isnull = True
    ).count()

    return {
        'staff': staff_count,
        'members': member_count,
        'assignments': assignment_count,
        'submissions': submission_count,
        'peerreviews': peerreview_count,
    }


def assignment_stats(ae):
    """ Generate statistics for an assignment

    :param ae:
    :return:
    """
    try:
        pra = ae.peerreviewassignment

    except ObjectDoesNotExist:
        # Normal assignment

        # Active members for this assignment (i.e. with at least one submission)
        member_count = SubmissionAuthor.objects.filter(
            active = True,
            submission__in = Submission.objects.filter(
                assignmentedition = ae,
            ).exclude(
                submissionfile__peerreview__isnull=False
            )
        ).distinct().count()

        # Submissions that are not created for peerreviews
        submission_count = ae.submission_set.filter(
            submissionfile__peerreview__isnull = True
        ).count()

        return {
            'members': member_count,
            'submissions': submission_count,
        }

    else:
        # Peer review assignment

        # Active members for this assignment (i.e. with at least one peer review)
        member_count = PeerReviewBundle.objects.filter(
            assignment__review_assignment=ae,
            peerreview__reviewed_by__isnull=False
        ).distinct().count()

        # All peer reviews
        peerreview_count = PeerReview.objects.filter(
            bundle__assignment__review_assignment = ae,
        ).exclude(
            reviewed_by__isnull = True
        ).count()

        return {
            'members': member_count,
            'peerreviews': peerreview_count,
        }
