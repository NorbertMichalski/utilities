""" This file is part of PEACH.

    Copyright (C) 2006-2009 Eindhoven University of Technology
"""
from django.utils.timezone import localtime, now

from peach3.core import report
from peach3.tasks.report.submission import multi_submission_download_task
from peach3.utils.files import create_filename

class MultiSubmissionDownload(report.ReportGenerator):
    mimetype = 'application/zip'
    reporttype = 'multisubdown'
    task = multi_submission_download_task

    def get_parameters(self, user, sbs, ce, author, ae): #pylint: disable=W0221
        # `author` and `ae` may be None
        filtered_sbs = []
        ts = None
        for sb in sbs:
            if sb.has_access(user):
                filtered_sbs.append(sb)
                if sb.submitted and (ts is None or sb.submitted > ts):
                    ts = sb.submitted

        if ts is None:
            ts = now()

        return {
            'ae': ae,
            'au': author,
            'ce': ce,
            'sb': filtered_sbs,
            'ts': ts,
        }

    def get_filename(self, parameters):
        ts = localtime(parameters['ts']).strftime('%Y%m%d%H%M%S')

        ce = parameters['ce']
        ae = parameters['ae']
        author = parameters['au']

        if author:
            return create_filename('.zip', ce.name, author.username, ts)
        elif ae:
            return create_filename('.zip', ce.name, ae.slug, ts)
        else:
            return create_filename('.zip', ce.name, ts)

    def start_task(self, path, user, parameters, *args, **kwargs):
        author = parameters['au']
        ae = parameters['ae']

        return self.task.apply_async(
            (str(path),
             [sb.pk for sb in parameters['sb']],
             author.pk if author else None,
             ae.pk if ae else None,
            )
        )
