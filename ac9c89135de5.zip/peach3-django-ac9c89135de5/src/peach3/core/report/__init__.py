""" This file is part of PEACH.

    Copyright (C) 2006-2009 Eindhoven University of Technology
"""
from django.contrib.contenttypes.models import ContentType
from django.utils.encoding import smart_str
from django.utils.timezone import now

from celery import Task

from peach3.models import Report

import threading, time

from unipath import Path

def format_parameters(data):
    """ Generate a short, constant representation of the data, independent of
        internal ordering of the data
    """
    if isinstance(data, dict):
        p = [format_parameters(k)+':'+format_parameters(v) for k, v in data.iteritems()]
        return '{'+','.join(sorted(p))+'}'

    elif isinstance(data, (list, tuple, set, frozenset)):
        p = [format_parameters(v) for v in data]
        return ','.join(sorted(p))

    elif isinstance(data, basestring):
        return repr(smart_str(data))

    elif data is None:
        return '-'

    elif hasattr(data, 'pk'):
        ct = ContentType.objects.get_for_model(data)
        return '%s_%s#%s' % (ct.app_label, ct.model, data.pk)

    else:
        return str(data)

class ReportGenerator(object): #pylint: disable=R0921
    " Class to create and manager report generator tasks "

    reporttype = None
    mimetype = None
    task = None

    def __init__(self, user, *args, **kwargs):
        assert self.reporttype and self.mimetype

        report = kwargs.pop('_report', None)
        report_dirty = set() # Modified fields

        if not report:
            parameters = self.get_parameters(user, *args, **kwargs)

            report, created = Report.objects.get_or_create(
                type=self.reporttype,
                mimetype=self.mimetype,
                parameters=format_parameters(parameters),
            )

            if not report.users.filter(pk=user.pk).exists():
                report.users.add(user)

            if not created and report.tasksuccess==False:
                # Retry a previous failed report
                report.tasksuccess = None
                report_dirty.add('tasksuccess')
                created = True

        elif isinstance(report, Report):
            created = False
            if user not in report.users.all():
                raise ValueError

        else:
            raise TypeError

        if created:
            # New report or a previously failed report, start a new task
            report.file.name = report.file.field.generate_filename(report, self.get_filename(parameters))
            report_dirty.add('file')

            path = Path(report.file.path)
            path.parent.mkdir(True) #pylint: disable=E1101
            result = self.start_task(path, user, parameters, *args, **kwargs)

        elif report.taskid:
            # A scheduled or running task
            result = self.task.AsyncResult(report.taskid)

        else:
            # A finished task
            result = None

        # Update task state in report object
        if result:
            if result.ready():
                report.taskid = ''
                report.tasksuccess = result.successful()
                report_dirty.update(['taskid', 'tasksuccess'])

                result.forget()
                result = None

            elif report.taskid != result.id:
                report.taskid = result.id
                report_dirty.add('taskid')

        if report_dirty:
            report.save(update_fields=list(report_dirty))

        self.report = report
        self.result = result

    @classmethod
    def get_by_id(cls, report_id, user):
        " Get an existing report by id "
        try:
            report = Report.objects.get(pk=report_id, users=user)
        except Report.DoesNotExist:
            return None

        return cls(user, _report=report)

    def get_parameters(self, user, *args, **kwargs):
        raise NotImplementedError

    def get_filename(self, params):
        raise NotImplementedError

    def start_task(self, path, user, parameters, *args, **kwargs):
        raise NotImplementedError

    def get_progress(self):
        if self.result:
            state = self.result.state
            if state == 'PENDING':
                return -1
            elif state == 'PROGRESS':
                return self.result.info.get('progress')
            elif self.result.ready():
                return 100
            else:
                return 0

        return None

    def is_ready(self):
        if self.result:
            return self.result.ready()

        return True

    def is_successful(self):
        if not self.result:
            return self.report.tasksuccess

        return None
