""" This file is part of PEACH.

    Copyright (C) 2006-2009 Eindhoven University of Technology
"""
from django.db.models import Max
from django.utils.timezone import localtime, now

from peach3.core import report
from peach3.models import Submission, SubmissionAuthor, Review, CheckResult
from peach3.tasks.report.course import course_overview_task
from peach3.utils.files import create_filename


def course_overview_parameters(ce):
    sbaus = SubmissionAuthor.objects.filter(submission__courseedition=ce, active=True).values_list('id', flat=True)
    rvs = Review.objects.filter(submission__courseedition=ce).values_list('id', 'grade_id')
    cks = CheckResult.objects.filter(submission__courseedition=ce).values_list('id', 'state', 'grade_id', 'score_10')

    sbts = Submission.objects.filter(courseedition=ce).aggregate(Max('created'), Max('submitted'), Max('modified'))
    rvts = Review.objects.filter(submission__courseedition=ce).aggregate(Max('created'))
    ckts = CheckResult.objects.filter(submission__courseedition=ce).aggregate(Max('created'), Max('checked'))

    ts = max(sbts.values() + rvts.values() + ckts.values()) or now()

    return {
        'ce': ce,
        'sbaus': list(sbaus),
        'rvs': list(rvs),
        'cks': list(cks),
        'ts': ts,
    }

class CourseOverview(report.ReportGenerator):
    mimetype = 'text/comma-separated-values'
    reporttype = 'courseovervw'
    task = course_overview_task

    def get_parameters(self, user, ce): #pylint: disable=W0221
        return course_overview_parameters(ce)

    def _format_date(self, ts): #pylint: disable=R0201
        return localtime(ts).strftime('%Y%m%d%H%M%S')

    def get_filename(self, parameters):
        ts = self._format_date(parameters['ts'])
        return create_filename('.csv', parameters['ce'].name, ts)

    def start_task(self, path, user, parameters, *args, **kwargs):
        return self.task.apply_async((str(path), user.pk, parameters['ce'].pk))
