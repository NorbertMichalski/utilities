#pylint: disable=C0103
from django.dispatch import Signal

cleanup_signal = Signal()

activity = Signal(providing_args=['code', 'user',
                                  'course', 'cluster',
                                  'assignment', 'parameters'])
