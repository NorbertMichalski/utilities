from django.utils import timezone
from django.utils.encoding import iri_to_uri

from peach3.core.storage.secured import SecuredFileSystemStorage
from peach3.utils.files import rmdirs

from unipath import AbstractPath, Path
import os.path

class SubmissionStorage(SecuredFileSystemStorage): #pylint: disable=W0223
    base_path = 'submission'
    MAX_PATH_LENGTH = 300

    @classmethod
    def upload_path(cls, instance, filename):
        created = getattr(instance, 'created', timezone.now())

        base = AbstractPath(created.strftime('%Y'), # one level for each year
                            created.strftime('%m%d'), # at most 366 items at this level
                            created.strftime('%H%M'), # at most 1440 items at this level
                            str(instance.pk)
                           )

        fname = iri_to_uri(filename)
        fbase, fext = os.path.splitext(fname)
        max_fbase_len = cls.MAX_PATH_LENGTH - len(base) - len(fext) - len(os.path.pathsep) - 1

        return str(base.child(fbase[:max_fbase_len]+fext))

    def _get_object(self, path):
        from peach3.models import FileRevision

        parts = AbstractPath(path).components()

        if len(parts)==6:
            return FileRevision.objects.get(pk=str(parts[4]))

        raise FileRevision.DoesNotExist

    def has_access(self, name, allow_superuser=False): #pylint: disable=W0221
        return super(SubmissionStorage, self).has_access(name, True)

    def delete(self, name):
        super(SubmissionStorage, self).delete(name)

        # Try to delete as many path elements as possible up to the root of the store
        rmdirs(self.location, Path(self.path(name)).parent)

submissionstorage = SubmissionStorage() #pylint: disable=C0103
