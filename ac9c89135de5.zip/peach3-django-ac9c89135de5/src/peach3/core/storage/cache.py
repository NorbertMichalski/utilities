from django.conf import settings
from django.contrib.contenttypes.models import ContentType
from django.core.exceptions import ObjectDoesNotExist
from django.core.files.storage import FileSystemStorage
from django.utils.timezone import now

from peach3.core.signals import cleanup_signal
from peach3.utils.files import rmdirs

from unipath import AbstractPath, Path, FILES

class CacheStorage(FileSystemStorage):
    base_path = 'cache'

    def __init__(self):
        base_path = self.base_path
        assert base_path is not None, "%s.base_path must be set" % self.__class__.__name__
        location = Path(settings.STORE).child(base_path)
        super(CacheStorage, self).__init__(location)

    @classmethod
    def upload_path(cls, instance, filename):
        ct = ContentType.objects.get_for_model(instance)

        # Construct path in such a way any sub-paths in filename will be rejected
        path = AbstractPath(ct.app_label, ct.model, str(instance.pk)).child(filename)

        return str(path)

    def _get_object(self, name):
        from peach3.models.cache import CachedFileModel, CachedImageModel

        parts = AbstractPath(name).components()

        if len(parts)==5:
            ct = ContentType.objects.get_by_natural_key(*parts[1:3])

            # Get by pk; don't get it by filename, because the on-disk filename
            # might be different from the filename stored in the database.
            # (not all filesystems preserve a filename fully)
            obj = ct.get_object_for_this_type(pk=parts[3])

            if isinstance(obj, CachedFileModel):
                f = obj.file
            elif isinstance(obj, CachedImageModel):
                f = obj.image
            else:
                raise TypeError

            # An additional check to verify that we really got the right object
            if name==f.name or Path(self.path(name)).same_file(self.path(f.name)):
                return obj

        raise ObjectDoesNotExist

    def delete(self, name):
        super(CacheStorage, self).delete(name)

        # Try to delete as many path elements as possible up to the root of the store
        rmdirs(self.location, Path(self.path(name)).parent)

    def _open(self, name, mode='rb'):
        try:
            obj = self._get_object(name)
        except ObjectDoesNotExist:
            pass
        else:
            obj.touch()

        return super(CacheStorage, self)._open(name, mode) #pylint: disable=W0212

    def cleanup(self, sender=None, **kwargs): #pylint: disable=W0613
        rnow = now()

        location = Path(self.location)
        for path in location.walk(filter=FILES):
            name = location.rel_path_to(path)

            try:
                obj = self._get_object(name)

            except ObjectDoesNotExist:
                self.delete(name)

            else:
                if obj.is_expired(rnow):
                    # Only delete the object. A signal handler on the object
                    # will take care of deleting the file
                    obj.delete()

cachestorage = CacheStorage() #pylint: disable=C0103
cleanup_signal.connect(cachestorage.cleanup)
