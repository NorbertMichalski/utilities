from django.conf import settings
from django.core.files.storage import FileSystemStorage
from django.core.exceptions import ObjectDoesNotExist

from peach3.utils.permissions import get_current_user

from functools import wraps

from unipath import Path

__all__ = ('FileAccessDeniedError', 'SecuredFileSystemStorage')

class FileAccessDeniedError(Exception):
    pass

class SecuredFileSystemStorage(FileSystemStorage): #pylint: disable=R0921
    base_path = None

    def __init__(self):
        base_path = self.base_path
        assert base_path is not None, "%s.base_path must be set" % self.__class__.__name__
        location = Path(settings.STORE).child(base_path)
        super(SecuredFileSystemStorage, self).__init__(location)

    def _get_object(self, name): #pylint: disable=R0201,W0613
        """Get the related object based on the given file name.
        Raises django.core.exceptions.ObjectDoesNotExist (or a subclass link Model.DoesNotExist)
        if object cannot be found
        """

        raise ObjectDoesNotExist

    def has_access(self, name, allow_superuser=False):
        """ Check whether the current user has access to the file
        The default implementation of this will check using the "has_access" feature of the
        related object returned by _get_object
        """
        user = get_current_user()
        if user:
            if allow_superuser and user.is_superuser:
                return True

            try:
                return self._get_object(name).has_access(user)
            except ObjectDoesNotExist:
                pass

        # No current user, we must be running in a shell
        return True

    def _test_access(self, name):
        if not self.has_access(name):
            raise FileAccessDeniedError

    # exists() is not wrapped with the access test, instead, it simply returns False
    # for any path the user has no access to.
    def exists(self, name):
        return self.has_access(name) and super(SecuredFileSystemStorage, self).exists(name)

    def compare(self, name, other):
        """ Compare named file with the other one (a django.core.files.File object).
        This is allowed even if the current user otherwise has no access to the file.

        Does not close the other file.
        """
        with super(SecuredFileSystemStorage, self)._open(name, 'rb') as myfile: #pylint: disable=W0212
            other.open()
            while True:
                d1, d2 = myfile.read(8192), other.read(8192)
                if not d1 and not d2:
                    return True
                elif d1!=d2:
                    return False

    def url(self, name):
        raise NotImplementedError

# Decorate the methods of SecuredFileSystemStorage listed in SECURED_METHODS
# with a call to _test_access
SECURED_METHODS = ['_open', 'delete', 'listdir', 'size',
                   'accessed_time', 'created_time', 'modified_time']

def _make_secured(original_method):
    @wraps(original_method)
    def wrapped(self, path, *args, **kwargs):
        self._test_access(path) #pylint: disable=W0212
        return original_method(self, path, *args, **kwargs)
    return wrapped

for _name in SECURED_METHODS:
    _original_method = getattr(FileSystemStorage, _name)
    _wrapped_method = _make_secured(_original_method)
    setattr(SecuredFileSystemStorage, _name, _wrapped_method)
