""" This file is part of PEACH.

    Copyright (C) 2006-2009 Eindhoven University of Technology
"""
from peach3.models import Page
from peach3.utils.rst import rst2html
from peach3.utils.wiki import get_default_title, decode_full_path

from docutils import nodes

#pylint: disable=W0613
def wiki_reference_role(role, rawtext, text, lineno, inliner, options=None, content=None, writer=None):
    wiki_path = text
    title = None
    options = options or {}
    content = content or []

    try:
        page = Page.objects.get_by_path(wiki_path)
        exists = True

        content = page.latest.text.content
        try:
            parsed = rst2html(content, wiki_path, writer=writer)
        except:
            pass
        else:
            title = parsed['title']

    except Page.DoesNotExist:
        exists = False

    if not title:
        try:
            title = get_default_title(*decode_full_path(wiki_path))
        except:
            title = 'wiki:'+text

    node = nodes.reference(rawtext, title, refuri='wiki:'+wiki_path, exists=exists, **options)

    return [node], []
