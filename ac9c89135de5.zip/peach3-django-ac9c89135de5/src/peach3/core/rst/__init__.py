""" This file is part of PEACH.

    Copyright (C) 2006-2009 Eindhoven University of Technology
"""
from django.conf import settings

def import_extensions():
    """ Import the directives as configured by RST_EXTENSIONS

        RST_EXTENSIONS is a dictionary of rST extensions to register with docutils.
        The key is the type of extension to register ('directive', or 'role'), the value is a
        list of extensions of the given type to import. Items can be strings or 2-tuples.
        Single strings or the first element of a tuple are the full module path to a directive function.
        For strings, this function is imported as a directive with the same name as the function.
        For tuples, this function is imported as a directive with the name of the second element of the tuple.

        Example:

        RST_EXTENSIONS = (
            'directive': [
                'a.b.c.d.sourcecode',
                ('a.b.c.d.some_function', 'flash,),
                ...
            ],
            'role': [
                ...
            ]
        )

        This installs two new directives. Function 'a.b.c.d.sourcecode' is installed as directive 'sourcecode',
        function 'a.b.c.d.some_function' is installed as directive 'flash'.
    """
    from django.core import exceptions
    from docutils.parsers import rst

    TYPES = { #pylint: disable=C0103
        'directive' : rst.directives.register_directive, #@UndefinedVariable
        'role'      : rst.roles.register_local_role,
    }

    for exttype, extensions in settings.RST_EXTENSIONS.iteritems():
        if exttype not in TYPES:
            raise exceptions.ImproperlyConfigured, 'Invalid rST extension type "%s"' % exttype

        for ext in extensions:
            if isinstance(ext, (tuple, list)):
                ext_path, ext_name = ext
            else:
                ext_path = ext
                ext_name = None

            try:
                dot = ext_path.rindex('.')
            except ValueError:
                raise exceptions.ImproperlyConfigured, '%s isn\'t a reStructuredText directive' % ext_path

            ext_module, ext_fn = ext_path[:dot], ext_path[dot+1:]

            if ext_name is None:
                ext_name = ext_fn

            try:
                mod = __import__(ext_module, {}, {}, [''])
            except ImportError, e:
                raise exceptions.ImproperlyConfigured, \
                    'Error importing rST %s "%s": %s' % (exttype, ext_name, e)

            try:
                ext_function = getattr(mod, ext_fn)
            except AttributeError:
                raise exceptions.ImproperlyConfigured, \
                    'reStructuredText %s module "%s" does not define a "%s"' % (exttype, ext_module, ext_fn)

            TYPES[exttype](ext_name, ext_function)

import_extensions()
