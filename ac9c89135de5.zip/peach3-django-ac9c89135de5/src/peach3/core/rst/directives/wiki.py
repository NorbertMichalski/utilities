""" This file is part of PEACH.

    Copyright (C) 2006-2009 Eindhoven University of Technology
"""
from docutils import statemachine
from docutils.parsers.rst import Directive, directives

from peach3.models import Page, PageRevision

from peach3.utils.permissions import get_current_user

class WikiInclude(Directive):
    required_arguments = 1
    optional_arguments = 0
    final_argument_whitespace = True

    option_spec = {'ignore-errors' : directives.flag}

    def run(self):
        wiki_path = directives.path(self.arguments[0])
        settings = self.state.document.settings

        if settings.ensure_value('validating', False):
            # When validating ignore included wiki's
            return []

        quiet = self.options.has_key('ignore-errors')

        if ':' in wiki_path:
            proto, wiki_path = wiki_path.split(':', 1)
            if proto!='wiki':
                if quiet:
                    return []
                raise self.severe('Invalid protocol "%s:" for wiki-include directive '
                                  '(only "wiki:" is supported)' % proto)

        if wiki_path=='' or wiki_path[0] not in ['=','/'] and settings._source: #pylint: disable=W0212
            wiki_path = settings._source.rstrip('/')+'/'+wiki_path.lstrip('/') #pylint: disable=W0212

        # Detect recursive includes
        memo = self.state_machine.memo
        if not hasattr(memo, 'included_wikis'):
            memo.included_wikis = []
        if wiki_path==settings._source or wiki_path in memo.included_wikis: #pylint: disable=W0212
            raise self.severe('Recursive wiki-include')
        memo.included_wikis.append(wiki_path)

        try:
            page = Page.objects.get_by_path(wiki_path)
        except Page.DoesNotExist:
            if quiet:
                return []
            raise self.severe('Included wiki "%s" does not exist' % wiki_path)

        if not page.has_access(get_current_user()):
            # Fail quietly if user has no access to the included wiki
            return []

        try:
            revision = page.get_latest(settings.language)
        except PageRevision.DoesNotExist:
            if quiet:
                return []
            raise self.severe('Included wiki "%s" does not exist' % wiki_path)

        content = revision.text.content

        include_lines = statemachine.string2lines(content,
                                                  convert_whitespace=1)

        self.state_machine.insert_input(include_lines, wiki_path)

        return []
