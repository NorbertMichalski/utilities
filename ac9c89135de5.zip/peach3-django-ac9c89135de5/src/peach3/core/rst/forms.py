""" This file is part of PEACH.

    Copyright (C) 2006-2009 Eindhoven University of Technology
"""
from django import forms
from django.utils.translation import ugettext as _, ungettext

from docutils.frontend import OptionParser
from docutils.parsers.rst import Parser
from docutils.utils import new_document

from cgi import escape

def validate(source, source_name='<source>'):
    result = []

    def observer(msg):
        level = msg.get('level')
        if level>1: # Ignore DEBUG and INFO levels
            result.append({
                'line' : msg.get('line'),
                'level' : level,
                'type' : msg.get('type'),
                'msg' : escape(msg[0].astext()),
            })

    settings = OptionParser(components=(Parser,)).get_default_values()
    settings.report_level = 5
    settings.halt_level = 5
    settings.validating = True

    parser = Parser()
    document = new_document(source_name, settings)
    document.reporter.attach_observer(observer)

    try:
        parser.parse(source, document)
    except Exception, e: #pylint: disable=W0703
        result.append({
            'level' : 5,
            'type'  : 'EXCEPTION',
            'msg'   : unicode(e),
        })

    return result

class RstField(forms.CharField):
    def clean(self, value):
        errors = validate(value)
        if len(errors)>0:
            err = errors[0]
            if err.get('line'):
                msg = _("Error on line %(line)s: (%(type)s/%(level)s) %(msg)s") % err
            else:
                msg = _("Error: (%(type)s/%(level)s) %(msg)s") % err
            if len(errors)>1:
                nre = len(errors)-1
                msg += ' ('+(ungettext("and %d more error", "and %d more errors", nre) % nre)+')'

            raise forms.ValidationError(msg)
        return value

__all__=['RstField']
