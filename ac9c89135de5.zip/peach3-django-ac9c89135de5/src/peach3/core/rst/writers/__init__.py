class RstWriterWrapper(object):
    """ A wrapper to lazily instantiate an rst writer
    """
    def __init__(self, writercls):
        self._writercls = writercls
        self._instance = None

    def __call__(self):
        if self._instance is None:
            self._instance = self._writercls()
        return self._instance

