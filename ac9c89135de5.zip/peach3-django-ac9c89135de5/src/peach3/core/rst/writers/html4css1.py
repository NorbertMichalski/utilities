""" This file is part of PEACH.

    Copyright (C) 2006-2009 Eindhoven University of Technology
"""
from django.core.urlresolvers import reverse

from peach3.models import Page

from docutils.writers.html4css1 import Writer as BaseWriter, HTMLTranslator
from docutils import nodes

class Writer(BaseWriter):
    def __init__(self):
        BaseWriter.__init__(self)
        self.translator_class = WikiLinkHTMLTranslator

class WikiLinkHTMLTranslator(HTMLTranslator): #pylint: disable=R0904,W0223
    wiki_view = 'peach3-core:wiki.view'

    wiki_class = None
    wiki_atts = {}
    wiki_nonexist_class = None
    wiki_nonexist_atts = {}

    link_internal_class = None
    link_internal_atts = {}
    link_intref_class = None
    link_intref_atts = {}
    link_mailto_class = None
    link_mailto_atts = {}
    link_external_class = None
    link_external_atts = {'target':'_blank'}
    link_image_class = None
    link_image_atts = {}

    def _wiki_atts(self, atts, node, refuri):
        atts['href'] = reverse(self.wiki_view, kwargs={'path':refuri})

        if self.wiki_class:
            atts['class'] += ' '+self.wiki_class
        atts.update(self.wiki_atts)

        exists = node.get('exists')
        if exists is None:
            try:
                Page.objects.get_by_path(refuri)
            except Page.DoesNotExist:
                exists = False
            else:
                exists = True

        if not exists:
            if self.wiki_nonexist_class:
                atts['class'] += ' '+self.wiki_nonexist_class
            atts.update(self.wiki_nonexist_atts)

    def visit_reference(self, node):
        atts = {'class': 'reference'}
        if node.has_key('refuri'):
            refuri = node['refuri']

            if refuri.startswith('wiki:'):
                refuri = refuri[5:]

            if ':' not in refuri:
                # Wiki references
                if refuri=='' or refuri[0] not in ['=','/'] and self.settings._source: #pylint: disable=W0212
                    refuri = self.settings._source.rstrip('/')+'/'+refuri.lstrip('/') #pylint: disable=W0212

                if self.link_internal_class:
                    atts['class'] += ' '+self.link_internal_class
                atts.update(self.link_internal_atts)

                refuri = refuri.lstrip('/')
                self._wiki_atts(atts, node, refuri)

            else:
                if (self.settings.cloak_email_addresses and refuri.startswith('mailto:')):
                    atts['href'] = self.cloak_mailto(refuri)
                    self.in_mailto = 1

                    if self.link_mailto_class:
                        atts['class'] += ' '+self.link_mailto_class
                    atts.update(self.link_mailto_atts)
                else:
                    atts['href'] = refuri

                    if self.link_external_class:
                        atts['class'] += ' '+self.link_external_class
                    atts.update(self.link_external_atts)

        else:
            assert node.has_key('refid'), \
                   'References must have "refuri" or "refid" attribute.'
            atts['href'] = '#' + node['refid']
            if self.link_intref_class:
                atts['class'] += ' '+self.link_intref_class
            atts.update(self.link_intref_atts)

        if not isinstance(node.parent, nodes.TextElement):
            assert len(node) == 1 and isinstance(node[0], nodes.image)

            if self.link_image_class:
                atts['class'] += ' '+self.link_image_class
            atts.update(self.link_image_atts)

        self.body.append(self.starttag(node, 'a', '', **atts))

class AdminWriter(BaseWriter):
    def __init__(self):
        BaseWriter.__init__(self)
        self.translator_class = AdminWikiLinkHTMLTranslator

class AdminWikiLinkHTMLTranslator(WikiLinkHTMLTranslator): #pylint: disable=R0904,W0223
    pass
