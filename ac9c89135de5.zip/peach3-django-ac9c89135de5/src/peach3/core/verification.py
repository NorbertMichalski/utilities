from django.conf import settings
from django.contrib.auth import get_user_model
from django.utils import timezone
from django.utils.translation import ugettext_lazy as _

from peach3.utils.mail import send_template_mail

from datetime import timedelta
import urlparse

EXPIRATION = 7

VERIFY_REGISTRATION = 'R'
VERIFY_PASSWORD_RESET = 'P'
VERIFY_EMAIL_CHANGE = 'E'

VERIFY_CHOICES = (
    (VERIFY_REGISTRATION, _("Registration")),
    (VERIFY_PASSWORD_RESET, _("Password reset")),
    (VERIFY_EMAIL_CHANGE, _("Email change")),
)

def send_verification_mail(vtype, user, subject, template,
                           email=None,
                           parameters='',
                           expiration=EXPIRATION):

    from peach3.models.auth import VerificationCode

    User = get_user_model()
    code = None
    while not code:
        code = User.objects.make_random_password(length=8)
        if VerificationCode.objects.filter(code=code).exists():
            code = None

    expires = timezone.now()+timedelta(days=expiration)

    vcode, created = VerificationCode.objects.get_or_create(user=user, type=vtype, defaults={
                                                                'code': code,
                                                                'expires': expires,
                                                                'parameters': parameters,
                                                            })

    if not created:
        vcode.expires = expires
        vcode.parameters = parameters
        vcode.save(update_fields=['expires', 'parameters'])

    return send_template_mail(email or user.email, subject, template, {
        'username': user.username,
        'url': urlparse.urljoin(settings.BASE_URL, vcode.get_absolute_url()),
        'code': vcode.code,
        'expiration': expiration,
    })
