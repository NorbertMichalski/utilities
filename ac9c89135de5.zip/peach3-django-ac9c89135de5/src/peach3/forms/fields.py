from django import forms
from django.conf import settings
from django.contrib.auth import get_backends, get_user_model
from django.core.exceptions import ImproperlyConfigured
from django.utils.translation import ugettext as _, ugettext_lazy

from peach3.models import User
from peach3.utils.dates import TimeRange

import re

__all__ = ('TimeRangeField',)

class TimeRangeField(forms.MultiValueField):
    CHOICE_NEVER = 'never'
    CHOICE_ALWAYS = 'always'
    CHOICE_RANGE = 'period'
    CHOICES = (
        (CHOICE_NEVER, ugettext_lazy("Never")),
        (CHOICE_ALWAYS, ugettext_lazy("Always")),
        (CHOICE_RANGE, ugettext_lazy("During selected period")),
    )

    def __init__(self, *args, **kwargs):
        super(TimeRangeField, self).__init__(*args, **kwargs)
        self.fields = (
            forms.ChoiceField(required=True, choices=self.CHOICES, widget=self.widget.widgets[0]),
            forms.SplitDateTimeField(required=False, widget=self.widget.widgets[1]),
            forms.SplitDateTimeField(required=False, widget=self.widget.widgets[2]),
        )

    def clean(self, value):
        # Prevent validation errors when date/time fields are irrelevant
        if value[0] != self.CHOICE_RANGE:
            return super(TimeRangeField, self).clean([value[0], [u'',''], [u'','']])
        else:
            return super(TimeRangeField, self).clean(value)

    def compress(self, data_list):
        if data_list[0] == self.CHOICE_NEVER:
            return TimeRange(closed=True)

        elif data_list[0] == self.CHOICE_ALWAYS:
            return TimeRange(open=True)

        else:
            return TimeRange(begin=data_list[1], end=data_list[2])

def load_name_validator(path):
    i = path.rfind('.')
    module, attr = path[:i], path[i+1:]
    try:
        mod = __import__(module, {}, {}, [attr])
    except ImportError, e:
        raise ImproperlyConfigured, 'Error importing name validator %s: "%s"' % (module, e)
    try:
        cls = getattr(mod, attr)
    except AttributeError:
        raise ImproperlyConfigured, 'Module "%s" does not define a "%s" name validator' % (module, attr)
    return cls()

def get_name_validators():
    validators = []
    for validator_path in settings.USER_NAME_VALIDATORS:
        validators.append(load_name_validator(validator_path))
    return validators

class UsernameField(forms.RegexField):
    USERNAME_RE = re.compile(r"^\w+$")

    def __new__(cls, *arg, **kwarg):
        if not hasattr(cls, 'name_validators'):
            cls.name_validators = get_name_validators()
        return forms.RegexField.__new__(cls)

    def __init__(self, **kwarg):
        super(UsernameField, self).__init__(
            self.USERNAME_RE,
            error_message=_(u"Usernames can only contain alphanumeric characters and underscores."),
            **kwarg
        )

    def clean(self, value):
        value = super(UsernameField, self).clean(value.lower() if value is not None else None)

        # Check whether username already exists
        User = get_user_model()
        try:
            user = User.objects.get(username=value)
        except User.DoesNotExist:
            # Check if user exists on any of the auhentication backends
            for backend in get_backends():
                try:
                    user = backend.get_user(value)

                    # Some backends, most notably ModelBackend, don't use username for this test
                    if user.username.lower()!=value:
                        user = None
                except: #pylint: disable=W0702
                    user = None

                if user:
                    break

        if user and (user.is_active or user.state != User.STATE_UNVERIFIED):
            raise forms.ValidationError, _(u"An account with that login name already exists")

        # Do site specific username checking here
        for name_validator in self.name_validators:
            name_validator.validate(value)

        return value

class InitialsField(forms.RegexField):
    INITIALS_RE = re.compile(r"^[A-Z\.]*$")

    def __init__(self, **kwarg):
        super(InitialsField, self).__init__(self.INITIALS_RE,
                                            error_message=_(u"Initial can only contain letters and dots"),
                                            **kwarg)

    def clean(self, value):
        return super(InitialsField, self).clean(value.upper() if value is not None else None)

