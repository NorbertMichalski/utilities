from django import forms

from peach3.utils.dates import TimeRange

__all__ = ('TimeRangeWidget',)

class TimeRangeWidget(forms.MultiWidget):
    def __init__(self, widgets=None, attrs=None):
        if widgets is None:
            widgets = (
                forms.RadioSelect,
                forms.SplitDateTimeWidget,
                forms.SplitDateTimeWidget
            )

        super(TimeRangeWidget, self).__init__(widgets, attrs)

    def decompress(self, value):
        from peach3.forms.fields import TimeRangeField

        if not isinstance(value, TimeRange):
            return [None, None, None]

        elif value.is_open():
            return [TimeRangeField.CHOICE_ALWAYS, None, None]

        elif value.is_closed():
            return [TimeRangeField.CHOICE_NEVER, None, None]

        else:
            return [TimeRangeField.CHOICE_RANGE,
                    value.begin if value.has_begin() else None,
                    value.end if value.has_end() else None
                   ]

