# Create your views here.
# Create your views here.
from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import render, get_object_or_404
from django.core.context_processors import csrf
from datetime import datetime
from shipping.models import InputForm
from UPS_scraper import UpsScraper
from IdcUsa import IdcScraper
import json

def index(request):
    if request.method == 'POST':
        form = InputForm(request.POST)
        # return HttpResponse(form.cleaned_data)
        if form.is_valid():
            zipcode1 = form.cleaned_data['zipcode1']
            zipcode2 = form.cleaned_data['zipcode2']
            weight = form.cleaned_data['weight']
            date1 = form.cleaned_data['date1']
            carrier = form.cleaned_data['carrier']
            if carrier == 'UPS':
                scraper = UpsScraper()
                # print scraper.get_availability('AEM2238-4')
                results = scraper.get_estimate(zipcode1, zipcode2, weight, date1)
                if results == '':
                    context = {'info': 'Multiple locations for that ZIP code. Please be more specific or use the UPS website.'}
                    return render(request, 'shipping/index.html', context)

            if carrier == 'IDC':
                scraper = IdcScraper()
                results = scraper.get_estimate(zipcode1, zipcode2, weight)

            context = {'results':results, 'info':'Done. These are all the results.', 'zipcode1':zipcode1, 'zipcode2':zipcode2, 'weight':weight, 'date1':date1.strftime('%m/%d/%Y')}
            return render(request, 'shipping/index.html', context)

        else:
            context = {'info': 'The data introduced is not valid.'}
            return render(request, 'shipping/index.html', context)
    else:
        form = InputForm()
        context = {'results': ''}
        return render(request, 'shipping/index.html', context)


def estimate(request):
    today = datetime.today()
    # date = today.strftime('%m/%d/%Y')
    if request.method == 'GET':
        zipcode1 = request.GET.get('zipcode1', '')
        zipcode2 = request.GET.get('zipcode2', '')
        weight = request.GET.get('weight', '')

        scraper = UpsScraper()
        ups_result = scraper.get_ups_ground(zipcode1, zipcode2, weight, today)
        scraper = IdcScraper()
        idc_result = scraper.get_freight(zipcode1, zipcode2, weight, today)
        results = {'UPS': ups_result, 'IDC': idc_result}
        output = json.dumps(results)
        return HttpResponse(output)

