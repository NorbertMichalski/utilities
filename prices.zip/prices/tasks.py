from celery import task
from scrapers.temco import TemcoScraper
import datetime
from django.utils import timezone

def scrap_temco(product):
    scraper = TemcoScraper()
    scraper.get_price(product)

@task()
def scrape_prices():
    today = timezone.now()
    days = [today, today - datetime.timedelta(days=1), today - datetime.timedelta(days=2)]
    for day in days:
        price = scrap_temco('AEM2238-4')

